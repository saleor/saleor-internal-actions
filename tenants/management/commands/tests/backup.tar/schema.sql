--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mirumee; Type: SCHEMA; Schema: -; Owner: saleor
--

CREATE SCHEMA "mirumee";


ALTER SCHEMA "mirumee" OWNER TO "saleor";

SET default_tablespace = '';

--
-- Name: account_address; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_address" (
    "id" integer NOT NULL,
    "first_name" character varying(256) NOT NULL,
    "last_name" character varying(256) NOT NULL,
    "company_name" character varying(256) NOT NULL,
    "street_address_1" character varying(256) NOT NULL,
    "street_address_2" character varying(256) NOT NULL,
    "city" character varying(256) NOT NULL,
    "postal_code" character varying(20) NOT NULL,
    "country" character varying(2) NOT NULL,
    "country_area" character varying(128) NOT NULL,
    "phone" character varying(128) NOT NULL,
    "city_area" character varying(128) NOT NULL
);


ALTER TABLE "mirumee"."account_address" OWNER TO "saleor";

--
-- Name: account_customerevent; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_customerevent" (
    "id" integer NOT NULL,
    "date" timestamp with time zone NOT NULL,
    "type" character varying(255) NOT NULL,
    "parameters" "jsonb" NOT NULL,
    "order_id" integer,
    "user_id" integer NOT NULL
);


ALTER TABLE "mirumee"."account_customerevent" OWNER TO "saleor";

--
-- Name: account_customerevent_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."account_customerevent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."account_customerevent_id_seq" OWNER TO "saleor";

--
-- Name: account_customerevent_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."account_customerevent_id_seq" OWNED BY "mirumee"."account_customerevent"."id";


--
-- Name: account_customernote; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_customernote" (
    "id" integer NOT NULL,
    "date" timestamp with time zone NOT NULL,
    "content" "text" NOT NULL,
    "is_public" boolean NOT NULL,
    "customer_id" integer NOT NULL,
    "user_id" integer
);


ALTER TABLE "mirumee"."account_customernote" OWNER TO "saleor";

--
-- Name: account_customernote_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."account_customernote_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."account_customernote_id_seq" OWNER TO "saleor";

--
-- Name: account_customernote_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."account_customernote_id_seq" OWNED BY "mirumee"."account_customernote"."id";


--
-- Name: app_app; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."app_app" (
    "id" integer NOT NULL,
    "private_metadata" "jsonb",
    "metadata" "jsonb",
    "name" character varying(60) NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "is_active" boolean NOT NULL,
    "about_app" "text",
    "app_url" character varying(200),
    "configuration_url" character varying(200),
    "data_privacy" "text",
    "data_privacy_url" character varying(200),
    "homepage_url" character varying(200),
    "identifier" character varying(256),
    "support_url" character varying(200),
    "type" character varying(60) NOT NULL,
    "version" character varying(60)
);


ALTER TABLE "mirumee"."app_app" OWNER TO "saleor";

--
-- Name: account_serviceaccount_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."account_serviceaccount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."account_serviceaccount_id_seq" OWNER TO "saleor";

--
-- Name: account_serviceaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."account_serviceaccount_id_seq" OWNED BY "mirumee"."app_app"."id";


--
-- Name: app_app_permissions; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."app_app_permissions" (
    "id" integer NOT NULL,
    "app_id" integer NOT NULL,
    "permission_id" integer NOT NULL
);


ALTER TABLE "mirumee"."app_app_permissions" OWNER TO "saleor";

--
-- Name: account_serviceaccount_permissions_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."account_serviceaccount_permissions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."account_serviceaccount_permissions_id_seq" OWNER TO "saleor";

--
-- Name: account_serviceaccount_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."account_serviceaccount_permissions_id_seq" OWNED BY "mirumee"."app_app_permissions"."id";


--
-- Name: app_apptoken; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."app_apptoken" (
    "id" integer NOT NULL,
    "name" character varying(128) NOT NULL,
    "auth_token" character varying(30) NOT NULL,
    "app_id" integer NOT NULL
);


ALTER TABLE "mirumee"."app_apptoken" OWNER TO "saleor";

--
-- Name: account_serviceaccounttoken_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."account_serviceaccounttoken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."account_serviceaccounttoken_id_seq" OWNER TO "saleor";

--
-- Name: account_serviceaccounttoken_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."account_serviceaccounttoken_id_seq" OWNED BY "mirumee"."app_apptoken"."id";


--
-- Name: account_staffnotificationrecipient; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_staffnotificationrecipient" (
    "id" integer NOT NULL,
    "staff_email" character varying(254),
    "active" boolean NOT NULL,
    "user_id" integer
);


ALTER TABLE "mirumee"."account_staffnotificationrecipient" OWNER TO "saleor";

--
-- Name: account_staffnotificationrecipient_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."account_staffnotificationrecipient_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."account_staffnotificationrecipient_id_seq" OWNER TO "saleor";

--
-- Name: account_staffnotificationrecipient_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."account_staffnotificationrecipient_id_seq" OWNED BY "mirumee"."account_staffnotificationrecipient"."id";


--
-- Name: account_user; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_user" (
    "id" integer NOT NULL,
    "is_superuser" boolean NOT NULL,
    "email" character varying(254) NOT NULL,
    "is_staff" boolean NOT NULL,
    "is_active" boolean NOT NULL,
    "password" character varying(128) NOT NULL,
    "date_joined" timestamp with time zone NOT NULL,
    "last_login" timestamp with time zone,
    "default_billing_address_id" integer,
    "default_shipping_address_id" integer,
    "note" "text",
    "first_name" character varying(256) NOT NULL,
    "last_name" character varying(256) NOT NULL,
    "avatar" character varying(100),
    "private_metadata" "jsonb",
    "metadata" "jsonb",
    "jwt_token_key" character varying(12) NOT NULL
);


ALTER TABLE "mirumee"."account_user" OWNER TO "saleor";

--
-- Name: account_user_addresses; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_user_addresses" (
    "id" integer NOT NULL,
    "user_id" integer NOT NULL,
    "address_id" integer NOT NULL
);


ALTER TABLE "mirumee"."account_user_addresses" OWNER TO "saleor";

--
-- Name: account_user_groups; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_user_groups" (
    "id" integer NOT NULL,
    "user_id" integer NOT NULL,
    "group_id" integer NOT NULL
);


ALTER TABLE "mirumee"."account_user_groups" OWNER TO "saleor";

--
-- Name: account_user_user_permissions; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."account_user_user_permissions" (
    "id" integer NOT NULL,
    "user_id" integer NOT NULL,
    "permission_id" integer NOT NULL
);


ALTER TABLE "mirumee"."account_user_user_permissions" OWNER TO "saleor";

--
-- Name: app_appinstallation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."app_appinstallation" (
    "id" integer NOT NULL,
    "status" character varying(50) NOT NULL,
    "message" character varying(255),
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "app_name" character varying(60) NOT NULL,
    "manifest_url" character varying(200) NOT NULL
);


ALTER TABLE "mirumee"."app_appinstallation" OWNER TO "saleor";

--
-- Name: app_appinstallation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."app_appinstallation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."app_appinstallation_id_seq" OWNER TO "saleor";

--
-- Name: app_appinstallation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."app_appinstallation_id_seq" OWNED BY "mirumee"."app_appinstallation"."id";


--
-- Name: app_appinstallation_permissions; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."app_appinstallation_permissions" (
    "id" integer NOT NULL,
    "appinstallation_id" integer NOT NULL,
    "permission_id" integer NOT NULL
);


ALTER TABLE "mirumee"."app_appinstallation_permissions" OWNER TO "saleor";

--
-- Name: app_appinstallation_permissions_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."app_appinstallation_permissions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."app_appinstallation_permissions_id_seq" OWNER TO "saleor";

--
-- Name: app_appinstallation_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."app_appinstallation_permissions_id_seq" OWNED BY "mirumee"."app_appinstallation_permissions"."id";


--
-- Name: auth_group; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."auth_group" (
    "id" integer NOT NULL,
    "name" character varying(150) NOT NULL
);


ALTER TABLE "mirumee"."auth_group" OWNER TO "saleor";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."auth_group_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."auth_group_id_seq" OWNER TO "saleor";

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."auth_group_id_seq" OWNED BY "mirumee"."auth_group"."id";


--
-- Name: auth_group_permissions; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."auth_group_permissions" (
    "id" integer NOT NULL,
    "group_id" integer NOT NULL,
    "permission_id" integer NOT NULL
);


ALTER TABLE "mirumee"."auth_group_permissions" OWNER TO "saleor";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."auth_group_permissions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."auth_group_permissions_id_seq" OWNER TO "saleor";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."auth_group_permissions_id_seq" OWNED BY "mirumee"."auth_group_permissions"."id";


--
-- Name: auth_permission; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."auth_permission" (
    "id" integer NOT NULL,
    "name" character varying(255) NOT NULL,
    "content_type_id" integer NOT NULL,
    "codename" character varying(100) NOT NULL
);


ALTER TABLE "mirumee"."auth_permission" OWNER TO "saleor";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."auth_permission_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."auth_permission_id_seq" OWNER TO "saleor";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."auth_permission_id_seq" OWNED BY "mirumee"."auth_permission"."id";


--
-- Name: checkout_checkoutline; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."checkout_checkoutline" (
    "id" integer NOT NULL,
    "quantity" integer NOT NULL,
    "checkout_id" "uuid" NOT NULL,
    "variant_id" integer NOT NULL,
    "data" "jsonb" NOT NULL,
    CONSTRAINT "cart_cartline_quantity_check" CHECK (("quantity" >= 0))
);


ALTER TABLE "mirumee"."checkout_checkoutline" OWNER TO "saleor";

--
-- Name: cart_cartline_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."cart_cartline_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."cart_cartline_id_seq" OWNER TO "saleor";

--
-- Name: cart_cartline_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."cart_cartline_id_seq" OWNED BY "mirumee"."checkout_checkoutline"."id";


--
-- Name: checkout_checkout; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."checkout_checkout" (
    "created" timestamp with time zone NOT NULL,
    "last_change" timestamp with time zone NOT NULL,
    "email" character varying(254) NOT NULL,
    "token" "uuid" NOT NULL,
    "quantity" integer NOT NULL,
    "user_id" integer,
    "billing_address_id" integer,
    "discount_amount" numeric(12,3) NOT NULL,
    "discount_name" character varying(255),
    "note" "text" NOT NULL,
    "shipping_address_id" integer,
    "shipping_method_id" integer,
    "voucher_code" character varying(12),
    "translated_discount_name" character varying(255),
    "metadata" "jsonb",
    "private_metadata" "jsonb",
    "currency" character varying(3) NOT NULL,
    "country" character varying(2) NOT NULL,
    "redirect_url" character varying(200),
    "tracking_code" character varying(255),
    CONSTRAINT "cart_cart_quantity_check" CHECK (("quantity" >= 0))
);


ALTER TABLE "mirumee"."checkout_checkout" OWNER TO "saleor";

--
-- Name: checkout_checkout_gift_cards; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."checkout_checkout_gift_cards" (
    "id" integer NOT NULL,
    "checkout_id" "uuid" NOT NULL,
    "giftcard_id" integer NOT NULL
);


ALTER TABLE "mirumee"."checkout_checkout_gift_cards" OWNER TO "saleor";

--
-- Name: checkout_checkout_gift_cards_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."checkout_checkout_gift_cards_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."checkout_checkout_gift_cards_id_seq" OWNER TO "saleor";

--
-- Name: checkout_checkout_gift_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."checkout_checkout_gift_cards_id_seq" OWNED BY "mirumee"."checkout_checkout_gift_cards"."id";


--
-- Name: csv_exportevent; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."csv_exportevent" (
    "id" integer NOT NULL,
    "date" timestamp with time zone NOT NULL,
    "type" character varying(255) NOT NULL,
    "parameters" "jsonb" NOT NULL,
    "app_id" integer,
    "export_file_id" integer NOT NULL,
    "user_id" integer
);


ALTER TABLE "mirumee"."csv_exportevent" OWNER TO "saleor";

--
-- Name: csv_exportevent_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."csv_exportevent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."csv_exportevent_id_seq" OWNER TO "saleor";

--
-- Name: csv_exportevent_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."csv_exportevent_id_seq" OWNED BY "mirumee"."csv_exportevent"."id";


--
-- Name: csv_exportfile; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."csv_exportfile" (
    "id" integer NOT NULL,
    "status" character varying(50) NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "content_file" character varying(100),
    "app_id" integer,
    "user_id" integer,
    "message" character varying(255)
);


ALTER TABLE "mirumee"."csv_exportfile" OWNER TO "saleor";

--
-- Name: csv_exportfile_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."csv_exportfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."csv_exportfile_id_seq" OWNER TO "saleor";

--
-- Name: csv_exportfile_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."csv_exportfile_id_seq" OWNED BY "mirumee"."csv_exportfile"."id";


--
-- Name: discount_sale; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_sale" (
    "id" integer NOT NULL,
    "name" character varying(255) NOT NULL,
    "type" character varying(10) NOT NULL,
    "value" numeric(12,3) NOT NULL,
    "end_date" timestamp with time zone,
    "start_date" timestamp with time zone NOT NULL
);


ALTER TABLE "mirumee"."discount_sale" OWNER TO "saleor";

--
-- Name: discount_sale_categories; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_sale_categories" (
    "id" integer NOT NULL,
    "sale_id" integer NOT NULL,
    "category_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_sale_categories" OWNER TO "saleor";

--
-- Name: discount_sale_categories_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_sale_categories_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_sale_categories_id_seq" OWNER TO "saleor";

--
-- Name: discount_sale_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_sale_categories_id_seq" OWNED BY "mirumee"."discount_sale_categories"."id";


--
-- Name: discount_sale_collections; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_sale_collections" (
    "id" integer NOT NULL,
    "sale_id" integer NOT NULL,
    "collection_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_sale_collections" OWNER TO "saleor";

--
-- Name: discount_sale_collections_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_sale_collections_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_sale_collections_id_seq" OWNER TO "saleor";

--
-- Name: discount_sale_collections_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_sale_collections_id_seq" OWNED BY "mirumee"."discount_sale_collections"."id";


--
-- Name: discount_sale_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_sale_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_sale_id_seq" OWNER TO "saleor";

--
-- Name: discount_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_sale_id_seq" OWNED BY "mirumee"."discount_sale"."id";


--
-- Name: discount_sale_products; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_sale_products" (
    "id" integer NOT NULL,
    "sale_id" integer NOT NULL,
    "product_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_sale_products" OWNER TO "saleor";

--
-- Name: discount_sale_products_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_sale_products_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_sale_products_id_seq" OWNER TO "saleor";

--
-- Name: discount_sale_products_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_sale_products_id_seq" OWNED BY "mirumee"."discount_sale_products"."id";


--
-- Name: discount_saletranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_saletranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "name" character varying(255),
    "sale_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_saletranslation" OWNER TO "saleor";

--
-- Name: discount_saletranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_saletranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_saletranslation_id_seq" OWNER TO "saleor";

--
-- Name: discount_saletranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_saletranslation_id_seq" OWNED BY "mirumee"."discount_saletranslation"."id";


--
-- Name: discount_voucher; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_voucher" (
    "id" integer NOT NULL,
    "type" character varying(20) NOT NULL,
    "name" character varying(255),
    "code" character varying(12) NOT NULL,
    "usage_limit" integer,
    "used" integer NOT NULL,
    "start_date" timestamp with time zone NOT NULL,
    "end_date" timestamp with time zone,
    "discount_value_type" character varying(10) NOT NULL,
    "discount_value" numeric(12,3) NOT NULL,
    "min_spent_amount" numeric(12,3),
    "apply_once_per_order" boolean NOT NULL,
    "countries" character varying(749) NOT NULL,
    "min_checkout_items_quantity" integer,
    "apply_once_per_customer" boolean NOT NULL,
    "currency" character varying(3) NOT NULL,
    CONSTRAINT "discount_voucher_min_checkout_items_quantity_check" CHECK (("min_checkout_items_quantity" >= 0)),
    CONSTRAINT "discount_voucher_usage_limit_check" CHECK (("usage_limit" >= 0)),
    CONSTRAINT "discount_voucher_used_check" CHECK (("used" >= 0))
);


ALTER TABLE "mirumee"."discount_voucher" OWNER TO "saleor";

--
-- Name: discount_voucher_categories; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_voucher_categories" (
    "id" integer NOT NULL,
    "voucher_id" integer NOT NULL,
    "category_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_voucher_categories" OWNER TO "saleor";

--
-- Name: discount_voucher_categories_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_voucher_categories_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_voucher_categories_id_seq" OWNER TO "saleor";

--
-- Name: discount_voucher_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_voucher_categories_id_seq" OWNED BY "mirumee"."discount_voucher_categories"."id";


--
-- Name: discount_voucher_collections; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_voucher_collections" (
    "id" integer NOT NULL,
    "voucher_id" integer NOT NULL,
    "collection_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_voucher_collections" OWNER TO "saleor";

--
-- Name: discount_voucher_collections_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_voucher_collections_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_voucher_collections_id_seq" OWNER TO "saleor";

--
-- Name: discount_voucher_collections_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_voucher_collections_id_seq" OWNED BY "mirumee"."discount_voucher_collections"."id";


--
-- Name: discount_voucher_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_voucher_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_voucher_id_seq" OWNER TO "saleor";

--
-- Name: discount_voucher_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_voucher_id_seq" OWNED BY "mirumee"."discount_voucher"."id";


--
-- Name: discount_voucher_products; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_voucher_products" (
    "id" integer NOT NULL,
    "voucher_id" integer NOT NULL,
    "product_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_voucher_products" OWNER TO "saleor";

--
-- Name: discount_voucher_products_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_voucher_products_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_voucher_products_id_seq" OWNER TO "saleor";

--
-- Name: discount_voucher_products_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_voucher_products_id_seq" OWNED BY "mirumee"."discount_voucher_products"."id";


--
-- Name: discount_vouchercustomer; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_vouchercustomer" (
    "id" integer NOT NULL,
    "customer_email" character varying(254) NOT NULL,
    "voucher_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_vouchercustomer" OWNER TO "saleor";

--
-- Name: discount_vouchercustomer_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_vouchercustomer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_vouchercustomer_id_seq" OWNER TO "saleor";

--
-- Name: discount_vouchercustomer_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_vouchercustomer_id_seq" OWNED BY "mirumee"."discount_vouchercustomer"."id";


--
-- Name: discount_vouchertranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."discount_vouchertranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "name" character varying(255),
    "voucher_id" integer NOT NULL
);


ALTER TABLE "mirumee"."discount_vouchertranslation" OWNER TO "saleor";

--
-- Name: discount_vouchertranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."discount_vouchertranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."discount_vouchertranslation_id_seq" OWNER TO "saleor";

--
-- Name: discount_vouchertranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."discount_vouchertranslation_id_seq" OWNED BY "mirumee"."discount_vouchertranslation"."id";


--
-- Name: django_content_type; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."django_content_type" (
    "id" integer NOT NULL,
    "app_label" character varying(100) NOT NULL,
    "model" character varying(100) NOT NULL
);


ALTER TABLE "mirumee"."django_content_type" OWNER TO "saleor";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."django_content_type_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."django_content_type_id_seq" OWNER TO "saleor";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."django_content_type_id_seq" OWNED BY "mirumee"."django_content_type"."id";


--
-- Name: django_migrations; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."django_migrations" (
    "id" integer NOT NULL,
    "app" character varying(255) NOT NULL,
    "name" character varying(255) NOT NULL,
    "applied" timestamp with time zone NOT NULL
);


ALTER TABLE "mirumee"."django_migrations" OWNER TO "saleor";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."django_migrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."django_migrations_id_seq" OWNER TO "saleor";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."django_migrations_id_seq" OWNED BY "mirumee"."django_migrations"."id";


--
-- Name: django_prices_openexchangerates_conversionrate; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."django_prices_openexchangerates_conversionrate" (
    "id" integer NOT NULL,
    "to_currency" character varying(3) NOT NULL,
    "rate" numeric(20,12) NOT NULL,
    "modified_at" timestamp with time zone NOT NULL
);


ALTER TABLE "mirumee"."django_prices_openexchangerates_conversionrate" OWNER TO "saleor";

--
-- Name: django_prices_openexchangerates_conversionrate_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."django_prices_openexchangerates_conversionrate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."django_prices_openexchangerates_conversionrate_id_seq" OWNER TO "saleor";

--
-- Name: django_prices_openexchangerates_conversionrate_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."django_prices_openexchangerates_conversionrate_id_seq" OWNED BY "mirumee"."django_prices_openexchangerates_conversionrate"."id";


--
-- Name: django_prices_vatlayer_ratetypes; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."django_prices_vatlayer_ratetypes" (
    "id" integer NOT NULL,
    "types" "text" NOT NULL
);


ALTER TABLE "mirumee"."django_prices_vatlayer_ratetypes" OWNER TO "saleor";

--
-- Name: django_prices_vatlayer_ratetypes_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."django_prices_vatlayer_ratetypes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."django_prices_vatlayer_ratetypes_id_seq" OWNER TO "saleor";

--
-- Name: django_prices_vatlayer_ratetypes_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."django_prices_vatlayer_ratetypes_id_seq" OWNED BY "mirumee"."django_prices_vatlayer_ratetypes"."id";


--
-- Name: django_prices_vatlayer_vat; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."django_prices_vatlayer_vat" (
    "id" integer NOT NULL,
    "country_code" character varying(2) NOT NULL,
    "data" "text" NOT NULL
);


ALTER TABLE "mirumee"."django_prices_vatlayer_vat" OWNER TO "saleor";

--
-- Name: django_prices_vatlayer_vat_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."django_prices_vatlayer_vat_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."django_prices_vatlayer_vat_id_seq" OWNER TO "saleor";

--
-- Name: django_prices_vatlayer_vat_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."django_prices_vatlayer_vat_id_seq" OWNED BY "mirumee"."django_prices_vatlayer_vat"."id";


--
-- Name: django_site; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."django_site" (
    "id" integer NOT NULL,
    "domain" character varying(100) NOT NULL,
    "name" character varying(50) NOT NULL
);


ALTER TABLE "mirumee"."django_site" OWNER TO "saleor";

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."django_site_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."django_site_id_seq" OWNER TO "saleor";

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."django_site_id_seq" OWNED BY "mirumee"."django_site"."id";


--
-- Name: giftcard_giftcard; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."giftcard_giftcard" (
    "id" integer NOT NULL,
    "code" character varying(16) NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "start_date" "date" NOT NULL,
    "end_date" "date",
    "last_used_on" timestamp with time zone,
    "is_active" boolean NOT NULL,
    "initial_balance_amount" numeric(12,3) NOT NULL,
    "current_balance_amount" numeric(12,3) NOT NULL,
    "user_id" integer,
    "currency" character varying(3) NOT NULL
);


ALTER TABLE "mirumee"."giftcard_giftcard" OWNER TO "saleor";

--
-- Name: giftcard_giftcard_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."giftcard_giftcard_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."giftcard_giftcard_id_seq" OWNER TO "saleor";

--
-- Name: giftcard_giftcard_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."giftcard_giftcard_id_seq" OWNED BY "mirumee"."giftcard_giftcard"."id";


--
-- Name: invoice_invoice; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."invoice_invoice" (
    "id" integer NOT NULL,
    "private_metadata" "jsonb",
    "metadata" "jsonb",
    "status" character varying(50) NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "number" character varying(255),
    "created" timestamp with time zone,
    "external_url" character varying(2048),
    "invoice_file" character varying(100) NOT NULL,
    "order_id" integer,
    "message" character varying(255)
);


ALTER TABLE "mirumee"."invoice_invoice" OWNER TO "saleor";

--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."invoice_invoice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."invoice_invoice_id_seq" OWNER TO "saleor";

--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."invoice_invoice_id_seq" OWNED BY "mirumee"."invoice_invoice"."id";


--
-- Name: invoice_invoiceevent; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."invoice_invoiceevent" (
    "id" integer NOT NULL,
    "date" timestamp with time zone NOT NULL,
    "type" character varying(255) NOT NULL,
    "parameters" "jsonb" NOT NULL,
    "invoice_id" integer,
    "order_id" integer,
    "user_id" integer
);


ALTER TABLE "mirumee"."invoice_invoiceevent" OWNER TO "saleor";

--
-- Name: invoice_invoiceevent_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."invoice_invoiceevent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."invoice_invoiceevent_id_seq" OWNER TO "saleor";

--
-- Name: invoice_invoiceevent_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."invoice_invoiceevent_id_seq" OWNED BY "mirumee"."invoice_invoiceevent"."id";


--
-- Name: menu_menu; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."menu_menu" (
    "id" integer NOT NULL,
    "name" character varying(128) NOT NULL
);


ALTER TABLE "mirumee"."menu_menu" OWNER TO "saleor";

--
-- Name: menu_menu_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."menu_menu_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."menu_menu_id_seq" OWNER TO "saleor";

--
-- Name: menu_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."menu_menu_id_seq" OWNED BY "mirumee"."menu_menu"."id";


--
-- Name: menu_menuitem; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."menu_menuitem" (
    "id" integer NOT NULL,
    "name" character varying(128) NOT NULL,
    "sort_order" integer,
    "url" character varying(256),
    "lft" integer NOT NULL,
    "rght" integer NOT NULL,
    "tree_id" integer NOT NULL,
    "level" integer NOT NULL,
    "category_id" integer,
    "collection_id" integer,
    "menu_id" integer NOT NULL,
    "page_id" integer,
    "parent_id" integer,
    CONSTRAINT "menu_menuitem_level_check" CHECK (("level" >= 0)),
    CONSTRAINT "menu_menuitem_lft_check" CHECK (("lft" >= 0)),
    CONSTRAINT "menu_menuitem_rght_check" CHECK (("rght" >= 0)),
    CONSTRAINT "menu_menuitem_tree_id_check" CHECK (("tree_id" >= 0))
);


ALTER TABLE "mirumee"."menu_menuitem" OWNER TO "saleor";

--
-- Name: menu_menuitem_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."menu_menuitem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."menu_menuitem_id_seq" OWNER TO "saleor";

--
-- Name: menu_menuitem_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."menu_menuitem_id_seq" OWNED BY "mirumee"."menu_menuitem"."id";


--
-- Name: menu_menuitemtranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."menu_menuitemtranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "name" character varying(128) NOT NULL,
    "menu_item_id" integer NOT NULL
);


ALTER TABLE "mirumee"."menu_menuitemtranslation" OWNER TO "saleor";

--
-- Name: menu_menuitemtranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."menu_menuitemtranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."menu_menuitemtranslation_id_seq" OWNER TO "saleor";

--
-- Name: menu_menuitemtranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."menu_menuitemtranslation_id_seq" OWNED BY "mirumee"."menu_menuitemtranslation"."id";


--
-- Name: order_fulfillment; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."order_fulfillment" (
    "id" integer NOT NULL,
    "tracking_number" character varying(255) NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "order_id" integer NOT NULL,
    "fulfillment_order" integer NOT NULL,
    "status" character varying(32) NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb",
    CONSTRAINT "order_fulfillment_fulfillment_order_check" CHECK (("fulfillment_order" >= 0))
);


ALTER TABLE "mirumee"."order_fulfillment" OWNER TO "saleor";

--
-- Name: order_fulfillment_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."order_fulfillment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."order_fulfillment_id_seq" OWNER TO "saleor";

--
-- Name: order_fulfillment_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."order_fulfillment_id_seq" OWNED BY "mirumee"."order_fulfillment"."id";


--
-- Name: order_fulfillmentline; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."order_fulfillmentline" (
    "id" integer NOT NULL,
    "order_line_id" integer NOT NULL,
    "quantity" integer NOT NULL,
    "fulfillment_id" integer NOT NULL,
    "stock_id" integer,
    CONSTRAINT "order_fulfillmentline_quantity_81b787d3_check" CHECK (("quantity" >= 0))
);


ALTER TABLE "mirumee"."order_fulfillmentline" OWNER TO "saleor";

--
-- Name: order_fulfillmentline_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."order_fulfillmentline_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."order_fulfillmentline_id_seq" OWNER TO "saleor";

--
-- Name: order_fulfillmentline_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."order_fulfillmentline_id_seq" OWNED BY "mirumee"."order_fulfillmentline"."id";


--
-- Name: order_order; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."order_order" (
    "id" integer NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "tracking_client_id" character varying(36) NOT NULL,
    "user_email" character varying(254) NOT NULL,
    "token" character varying(36) NOT NULL,
    "billing_address_id" integer,
    "shipping_address_id" integer,
    "user_id" integer,
    "total_net_amount" numeric(12,3) NOT NULL,
    "discount_amount" numeric(12,3) NOT NULL,
    "discount_name" character varying(255),
    "voucher_id" integer,
    "language_code" character varying(35) NOT NULL,
    "shipping_price_gross_amount" numeric(12,3) NOT NULL,
    "total_gross_amount" numeric(12,3) NOT NULL,
    "shipping_price_net_amount" numeric(12,3) NOT NULL,
    "status" character varying(32) NOT NULL,
    "shipping_method_name" character varying(255),
    "shipping_method_id" integer,
    "display_gross_prices" boolean NOT NULL,
    "translated_discount_name" character varying(255),
    "customer_note" "text" NOT NULL,
    "weight" double precision NOT NULL,
    "checkout_token" character varying(36) NOT NULL,
    "currency" character varying(3) NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb"
);


ALTER TABLE "mirumee"."order_order" OWNER TO "saleor";

--
-- Name: order_order_gift_cards; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."order_order_gift_cards" (
    "id" integer NOT NULL,
    "order_id" integer NOT NULL,
    "giftcard_id" integer NOT NULL
);


ALTER TABLE "mirumee"."order_order_gift_cards" OWNER TO "saleor";

--
-- Name: order_order_gift_cards_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."order_order_gift_cards_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."order_order_gift_cards_id_seq" OWNER TO "saleor";

--
-- Name: order_order_gift_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."order_order_gift_cards_id_seq" OWNED BY "mirumee"."order_order_gift_cards"."id";


--
-- Name: order_order_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."order_order_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."order_order_id_seq" OWNER TO "saleor";

--
-- Name: order_order_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."order_order_id_seq" OWNED BY "mirumee"."order_order"."id";


--
-- Name: order_orderline; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."order_orderline" (
    "id" integer NOT NULL,
    "product_name" character varying(386) NOT NULL,
    "product_sku" character varying(255) NOT NULL,
    "quantity" integer NOT NULL,
    "unit_price_net_amount" numeric(12,3) NOT NULL,
    "unit_price_gross_amount" numeric(12,3) NOT NULL,
    "is_shipping_required" boolean NOT NULL,
    "order_id" integer NOT NULL,
    "quantity_fulfilled" integer NOT NULL,
    "variant_id" integer,
    "tax_rate" numeric(5,2) NOT NULL,
    "translated_product_name" character varying(386) NOT NULL,
    "currency" character varying(3) NOT NULL,
    "translated_variant_name" character varying(255) NOT NULL,
    "variant_name" character varying(255) NOT NULL
);


ALTER TABLE "mirumee"."order_orderline" OWNER TO "saleor";

--
-- Name: order_ordereditem_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."order_ordereditem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."order_ordereditem_id_seq" OWNER TO "saleor";

--
-- Name: order_ordereditem_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."order_ordereditem_id_seq" OWNED BY "mirumee"."order_orderline"."id";


--
-- Name: order_orderevent; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."order_orderevent" (
    "id" integer NOT NULL,
    "date" timestamp with time zone NOT NULL,
    "type" character varying(255) NOT NULL,
    "order_id" integer NOT NULL,
    "user_id" integer,
    "parameters" "jsonb" NOT NULL
);


ALTER TABLE "mirumee"."order_orderevent" OWNER TO "saleor";

--
-- Name: order_orderevent_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."order_orderevent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."order_orderevent_id_seq" OWNER TO "saleor";

--
-- Name: order_orderevent_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."order_orderevent_id_seq" OWNED BY "mirumee"."order_orderevent"."id";


--
-- Name: page_page; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."page_page" (
    "id" integer NOT NULL,
    "slug" character varying(255) NOT NULL,
    "title" character varying(250) NOT NULL,
    "content" "text" NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "is_published" boolean NOT NULL,
    "publication_date" "date",
    "seo_description" character varying(300),
    "seo_title" character varying(70),
    "content_json" "jsonb" NOT NULL
);


ALTER TABLE "mirumee"."page_page" OWNER TO "saleor";

--
-- Name: page_page_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."page_page_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."page_page_id_seq" OWNER TO "saleor";

--
-- Name: page_page_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."page_page_id_seq" OWNED BY "mirumee"."page_page"."id";


--
-- Name: page_pagetranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."page_pagetranslation" (
    "id" integer NOT NULL,
    "seo_title" character varying(70),
    "seo_description" character varying(300),
    "language_code" character varying(10) NOT NULL,
    "title" character varying(255) NOT NULL,
    "content" "text" NOT NULL,
    "page_id" integer NOT NULL,
    "content_json" "jsonb" NOT NULL
);


ALTER TABLE "mirumee"."page_pagetranslation" OWNER TO "saleor";

--
-- Name: page_pagetranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."page_pagetranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."page_pagetranslation_id_seq" OWNER TO "saleor";

--
-- Name: page_pagetranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."page_pagetranslation_id_seq" OWNED BY "mirumee"."page_pagetranslation"."id";


--
-- Name: payment_payment; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."payment_payment" (
    "id" integer NOT NULL,
    "gateway" character varying(255) NOT NULL,
    "is_active" boolean NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "modified" timestamp with time zone NOT NULL,
    "charge_status" character varying(20) NOT NULL,
    "billing_first_name" character varying(256) NOT NULL,
    "billing_last_name" character varying(256) NOT NULL,
    "billing_company_name" character varying(256) NOT NULL,
    "billing_address_1" character varying(256) NOT NULL,
    "billing_address_2" character varying(256) NOT NULL,
    "billing_city" character varying(256) NOT NULL,
    "billing_city_area" character varying(128) NOT NULL,
    "billing_postal_code" character varying(256) NOT NULL,
    "billing_country_code" character varying(2) NOT NULL,
    "billing_country_area" character varying(256) NOT NULL,
    "billing_email" character varying(254) NOT NULL,
    "customer_ip_address" "inet",
    "cc_brand" character varying(40) NOT NULL,
    "cc_exp_month" integer,
    "cc_exp_year" integer,
    "cc_first_digits" character varying(6) NOT NULL,
    "cc_last_digits" character varying(4) NOT NULL,
    "extra_data" "text" NOT NULL,
    "token" character varying(128) NOT NULL,
    "currency" character varying(3) NOT NULL,
    "total" numeric(12,3) NOT NULL,
    "captured_amount" numeric(12,3) NOT NULL,
    "checkout_id" "uuid",
    "order_id" integer,
    "to_confirm" boolean NOT NULL,
    "payment_method_type" character varying(256) NOT NULL,
    "return_url" character varying(200),
    CONSTRAINT "payment_paymentmethod_cc_exp_month_check" CHECK (("cc_exp_month" >= 0)),
    CONSTRAINT "payment_paymentmethod_cc_exp_year_check" CHECK (("cc_exp_year" >= 0))
);


ALTER TABLE "mirumee"."payment_payment" OWNER TO "saleor";

--
-- Name: payment_paymentmethod_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."payment_paymentmethod_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."payment_paymentmethod_id_seq" OWNER TO "saleor";

--
-- Name: payment_paymentmethod_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."payment_paymentmethod_id_seq" OWNED BY "mirumee"."payment_payment"."id";


--
-- Name: payment_transaction; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."payment_transaction" (
    "id" integer NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "token" character varying(128) NOT NULL,
    "kind" character varying(25) NOT NULL,
    "is_success" boolean NOT NULL,
    "error" character varying(256),
    "currency" character varying(3) NOT NULL,
    "amount" numeric(12,3) NOT NULL,
    "gateway_response" "jsonb" NOT NULL,
    "payment_id" integer NOT NULL,
    "customer_id" character varying(256),
    "action_required" boolean NOT NULL,
    "action_required_data" "jsonb" NOT NULL,
    "already_processed" boolean NOT NULL,
    "searchable_key" character varying(256)
);


ALTER TABLE "mirumee"."payment_transaction" OWNER TO "saleor";

--
-- Name: payment_transaction_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."payment_transaction_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."payment_transaction_id_seq" OWNER TO "saleor";

--
-- Name: payment_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."payment_transaction_id_seq" OWNED BY "mirumee"."payment_transaction"."id";


--
-- Name: plugins_pluginconfiguration; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."plugins_pluginconfiguration" (
    "id" integer NOT NULL,
    "name" character varying(128) NOT NULL,
    "description" "text" NOT NULL,
    "active" boolean NOT NULL,
    "configuration" "jsonb",
    "identifier" character varying(128) NOT NULL
);


ALTER TABLE "mirumee"."plugins_pluginconfiguration" OWNER TO "saleor";

--
-- Name: plugins_pluginconfiguration_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."plugins_pluginconfiguration_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."plugins_pluginconfiguration_id_seq" OWNER TO "saleor";

--
-- Name: plugins_pluginconfiguration_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."plugins_pluginconfiguration_id_seq" OWNED BY "mirumee"."plugins_pluginconfiguration"."id";


--
-- Name: product_assignedproductattribute; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_assignedproductattribute" (
    "id" integer NOT NULL,
    "product_id" integer NOT NULL,
    "assignment_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_assignedproductattribute" OWNER TO "saleor";

--
-- Name: product_assignedproductattribute_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_assignedproductattribute_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_assignedproductattribute_id_seq" OWNER TO "saleor";

--
-- Name: product_assignedproductattribute_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_assignedproductattribute_id_seq" OWNED BY "mirumee"."product_assignedproductattribute"."id";


--
-- Name: product_assignedproductattribute_values; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_assignedproductattribute_values" (
    "id" integer NOT NULL,
    "assignedproductattribute_id" integer NOT NULL,
    "attributevalue_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_assignedproductattribute_values" OWNER TO "saleor";

--
-- Name: product_assignedproductattribute_values_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_assignedproductattribute_values_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_assignedproductattribute_values_id_seq" OWNER TO "saleor";

--
-- Name: product_assignedproductattribute_values_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_assignedproductattribute_values_id_seq" OWNED BY "mirumee"."product_assignedproductattribute_values"."id";


--
-- Name: product_assignedvariantattribute; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_assignedvariantattribute" (
    "id" integer NOT NULL,
    "variant_id" integer NOT NULL,
    "assignment_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_assignedvariantattribute" OWNER TO "saleor";

--
-- Name: product_assignedvariantattribute_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_assignedvariantattribute_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_assignedvariantattribute_id_seq" OWNER TO "saleor";

--
-- Name: product_assignedvariantattribute_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_assignedvariantattribute_id_seq" OWNED BY "mirumee"."product_assignedvariantattribute"."id";


--
-- Name: product_assignedvariantattribute_values; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_assignedvariantattribute_values" (
    "id" integer NOT NULL,
    "assignedvariantattribute_id" integer NOT NULL,
    "attributevalue_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_assignedvariantattribute_values" OWNER TO "saleor";

--
-- Name: product_assignedvariantattribute_values_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_assignedvariantattribute_values_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_assignedvariantattribute_values_id_seq" OWNER TO "saleor";

--
-- Name: product_assignedvariantattribute_values_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_assignedvariantattribute_values_id_seq" OWNED BY "mirumee"."product_assignedvariantattribute_values"."id";


--
-- Name: product_attribute; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_attribute" (
    "id" integer NOT NULL,
    "slug" character varying(250) NOT NULL,
    "name" character varying(255) NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb",
    "input_type" character varying(50) NOT NULL,
    "available_in_grid" boolean NOT NULL,
    "visible_in_storefront" boolean NOT NULL,
    "filterable_in_dashboard" boolean NOT NULL,
    "filterable_in_storefront" boolean NOT NULL,
    "value_required" boolean NOT NULL,
    "storefront_search_position" integer NOT NULL,
    "is_variant_only" boolean NOT NULL
);


ALTER TABLE "mirumee"."product_attribute" OWNER TO "saleor";

--
-- Name: product_attributevalue; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_attributevalue" (
    "id" integer NOT NULL,
    "name" character varying(250) NOT NULL,
    "attribute_id" integer NOT NULL,
    "slug" character varying(255) NOT NULL,
    "sort_order" integer,
    "value" character varying(100) NOT NULL
);


ALTER TABLE "mirumee"."product_attributevalue" OWNER TO "saleor";

--
-- Name: product_attributechoicevalue_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_attributechoicevalue_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_attributechoicevalue_id_seq" OWNER TO "saleor";

--
-- Name: product_attributechoicevalue_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_attributechoicevalue_id_seq" OWNED BY "mirumee"."product_attributevalue"."id";


--
-- Name: product_attributevaluetranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_attributevaluetranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "name" character varying(100) NOT NULL,
    "attribute_value_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_attributevaluetranslation" OWNER TO "saleor";

--
-- Name: product_attributechoicevaluetranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_attributechoicevaluetranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_attributechoicevaluetranslation_id_seq" OWNER TO "saleor";

--
-- Name: product_attributechoicevaluetranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_attributechoicevaluetranslation_id_seq" OWNED BY "mirumee"."product_attributevaluetranslation"."id";


--
-- Name: product_attributeproduct; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_attributeproduct" (
    "id" integer NOT NULL,
    "attribute_id" integer NOT NULL,
    "product_type_id" integer NOT NULL,
    "sort_order" integer
);


ALTER TABLE "mirumee"."product_attributeproduct" OWNER TO "saleor";

--
-- Name: product_attributeproduct_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_attributeproduct_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_attributeproduct_id_seq" OWNER TO "saleor";

--
-- Name: product_attributeproduct_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_attributeproduct_id_seq" OWNED BY "mirumee"."product_attributeproduct"."id";


--
-- Name: product_attributetranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_attributetranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "name" character varying(100) NOT NULL,
    "attribute_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_attributetranslation" OWNER TO "saleor";

--
-- Name: product_attributevariant; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_attributevariant" (
    "id" integer NOT NULL,
    "attribute_id" integer NOT NULL,
    "product_type_id" integer NOT NULL,
    "sort_order" integer
);


ALTER TABLE "mirumee"."product_attributevariant" OWNER TO "saleor";

--
-- Name: product_attributevariant_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_attributevariant_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_attributevariant_id_seq" OWNER TO "saleor";

--
-- Name: product_attributevariant_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_attributevariant_id_seq" OWNED BY "mirumee"."product_attributevariant"."id";


--
-- Name: product_category; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_category" (
    "id" integer NOT NULL,
    "name" character varying(250) NOT NULL,
    "slug" character varying(255) NOT NULL,
    "description" "text" NOT NULL,
    "lft" integer NOT NULL,
    "rght" integer NOT NULL,
    "tree_id" integer NOT NULL,
    "level" integer NOT NULL,
    "parent_id" integer,
    "background_image" character varying(100),
    "seo_description" character varying(300),
    "seo_title" character varying(70),
    "background_image_alt" character varying(128) NOT NULL,
    "description_json" "jsonb" NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb",
    CONSTRAINT "product_category_level_check" CHECK (("level" >= 0)),
    CONSTRAINT "product_category_lft_check" CHECK (("lft" >= 0)),
    CONSTRAINT "product_category_rght_check" CHECK (("rght" >= 0)),
    CONSTRAINT "product_category_tree_id_check" CHECK (("tree_id" >= 0))
);


ALTER TABLE "mirumee"."product_category" OWNER TO "saleor";

--
-- Name: product_category_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_category_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_category_id_seq" OWNER TO "saleor";

--
-- Name: product_category_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_category_id_seq" OWNED BY "mirumee"."product_category"."id";


--
-- Name: product_categorytranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_categorytranslation" (
    "id" integer NOT NULL,
    "seo_title" character varying(70),
    "seo_description" character varying(300),
    "language_code" character varying(10) NOT NULL,
    "name" character varying(128) NOT NULL,
    "description" "text" NOT NULL,
    "category_id" integer NOT NULL,
    "description_json" "jsonb" NOT NULL
);


ALTER TABLE "mirumee"."product_categorytranslation" OWNER TO "saleor";

--
-- Name: product_categorytranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_categorytranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_categorytranslation_id_seq" OWNER TO "saleor";

--
-- Name: product_categorytranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_categorytranslation_id_seq" OWNED BY "mirumee"."product_categorytranslation"."id";


--
-- Name: product_collection; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_collection" (
    "id" integer NOT NULL,
    "name" character varying(250) NOT NULL,
    "slug" character varying(255) NOT NULL,
    "background_image" character varying(100),
    "seo_description" character varying(300),
    "seo_title" character varying(70),
    "is_published" boolean NOT NULL,
    "description" "text" NOT NULL,
    "publication_date" "date",
    "background_image_alt" character varying(128) NOT NULL,
    "description_json" "jsonb" NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb"
);


ALTER TABLE "mirumee"."product_collection" OWNER TO "saleor";

--
-- Name: product_collection_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_collection_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_collection_id_seq" OWNER TO "saleor";

--
-- Name: product_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_collection_id_seq" OWNED BY "mirumee"."product_collection"."id";


--
-- Name: product_collectionproduct; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_collectionproduct" (
    "id" integer NOT NULL,
    "collection_id" integer NOT NULL,
    "product_id" integer NOT NULL,
    "sort_order" integer
);


ALTER TABLE "mirumee"."product_collectionproduct" OWNER TO "saleor";

--
-- Name: product_collection_products_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_collection_products_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_collection_products_id_seq" OWNER TO "saleor";

--
-- Name: product_collection_products_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_collection_products_id_seq" OWNED BY "mirumee"."product_collectionproduct"."id";


--
-- Name: product_collectiontranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_collectiontranslation" (
    "id" integer NOT NULL,
    "seo_title" character varying(70),
    "seo_description" character varying(300),
    "language_code" character varying(10) NOT NULL,
    "name" character varying(128) NOT NULL,
    "collection_id" integer NOT NULL,
    "description" "text" NOT NULL,
    "description_json" "jsonb" NOT NULL
);


ALTER TABLE "mirumee"."product_collectiontranslation" OWNER TO "saleor";

--
-- Name: product_collectiontranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_collectiontranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_collectiontranslation_id_seq" OWNER TO "saleor";

--
-- Name: product_collectiontranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_collectiontranslation_id_seq" OWNED BY "mirumee"."product_collectiontranslation"."id";


--
-- Name: product_digitalcontent; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_digitalcontent" (
    "id" integer NOT NULL,
    "use_default_settings" boolean NOT NULL,
    "automatic_fulfillment" boolean NOT NULL,
    "content_type" character varying(128) NOT NULL,
    "content_file" character varying(100) NOT NULL,
    "max_downloads" integer,
    "url_valid_days" integer,
    "product_variant_id" integer NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb"
);


ALTER TABLE "mirumee"."product_digitalcontent" OWNER TO "saleor";

--
-- Name: product_digitalcontent_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_digitalcontent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_digitalcontent_id_seq" OWNER TO "saleor";

--
-- Name: product_digitalcontent_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_digitalcontent_id_seq" OWNED BY "mirumee"."product_digitalcontent"."id";


--
-- Name: product_digitalcontenturl; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_digitalcontenturl" (
    "id" integer NOT NULL,
    "token" "uuid" NOT NULL,
    "created" timestamp with time zone NOT NULL,
    "download_num" integer NOT NULL,
    "content_id" integer NOT NULL,
    "line_id" integer
);


ALTER TABLE "mirumee"."product_digitalcontenturl" OWNER TO "saleor";

--
-- Name: product_digitalcontenturl_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_digitalcontenturl_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_digitalcontenturl_id_seq" OWNER TO "saleor";

--
-- Name: product_digitalcontenturl_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_digitalcontenturl_id_seq" OWNED BY "mirumee"."product_digitalcontenturl"."id";


--
-- Name: product_product; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_product" (
    "id" integer NOT NULL,
    "name" character varying(250) NOT NULL,
    "description" "text" NOT NULL,
    "publication_date" "date",
    "updated_at" timestamp with time zone,
    "product_type_id" integer NOT NULL,
    "is_published" boolean NOT NULL,
    "category_id" integer,
    "seo_description" character varying(300),
    "seo_title" character varying(70),
    "charge_taxes" boolean NOT NULL,
    "weight" double precision,
    "description_json" "jsonb" NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb",
    "minimal_variant_price_amount" numeric(12,3),
    "currency" character varying(3) NOT NULL,
    "slug" character varying(255) NOT NULL,
    "available_for_purchase" "date",
    "visible_in_listings" boolean NOT NULL,
    "default_variant_id" integer
);


ALTER TABLE "mirumee"."product_product" OWNER TO "saleor";

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_product_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_product_id_seq" OWNER TO "saleor";

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_product_id_seq" OWNED BY "mirumee"."product_product"."id";


--
-- Name: product_productattribute_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_productattribute_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_productattribute_id_seq" OWNER TO "saleor";

--
-- Name: product_productattribute_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_productattribute_id_seq" OWNED BY "mirumee"."product_attribute"."id";


--
-- Name: product_productattributetranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_productattributetranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_productattributetranslation_id_seq" OWNER TO "saleor";

--
-- Name: product_productattributetranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_productattributetranslation_id_seq" OWNED BY "mirumee"."product_attributetranslation"."id";


--
-- Name: product_producttype; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_producttype" (
    "id" integer NOT NULL,
    "name" character varying(250) NOT NULL,
    "has_variants" boolean NOT NULL,
    "is_shipping_required" boolean NOT NULL,
    "weight" double precision NOT NULL,
    "is_digital" boolean NOT NULL,
    "metadata" "jsonb",
    "private_metadata" "jsonb",
    "slug" character varying(255) NOT NULL
);


ALTER TABLE "mirumee"."product_producttype" OWNER TO "saleor";

--
-- Name: product_productclass_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_productclass_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_productclass_id_seq" OWNER TO "saleor";

--
-- Name: product_productclass_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_productclass_id_seq" OWNED BY "mirumee"."product_producttype"."id";


--
-- Name: product_productimage; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_productimage" (
    "id" integer NOT NULL,
    "image" character varying(100) NOT NULL,
    "ppoi" character varying(20) NOT NULL,
    "alt" character varying(128) NOT NULL,
    "sort_order" integer,
    "product_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_productimage" OWNER TO "saleor";

--
-- Name: product_productimage_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_productimage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_productimage_id_seq" OWNER TO "saleor";

--
-- Name: product_productimage_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_productimage_id_seq" OWNED BY "mirumee"."product_productimage"."id";


--
-- Name: product_producttranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_producttranslation" (
    "id" integer NOT NULL,
    "seo_title" character varying(70),
    "seo_description" character varying(300),
    "language_code" character varying(10) NOT NULL,
    "name" character varying(250) NOT NULL,
    "description" "text" NOT NULL,
    "product_id" integer NOT NULL,
    "description_json" "jsonb" NOT NULL
);


ALTER TABLE "mirumee"."product_producttranslation" OWNER TO "saleor";

--
-- Name: product_producttranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_producttranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_producttranslation_id_seq" OWNER TO "saleor";

--
-- Name: product_producttranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_producttranslation_id_seq" OWNED BY "mirumee"."product_producttranslation"."id";


--
-- Name: product_productvariant; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_productvariant" (
    "id" integer NOT NULL,
    "sku" character varying(255) NOT NULL,
    "name" character varying(255) NOT NULL,
    "product_id" integer NOT NULL,
    "cost_price_amount" numeric(12,3),
    "track_inventory" boolean NOT NULL,
    "weight" double precision,
    "metadata" "jsonb",
    "private_metadata" "jsonb",
    "currency" character varying(3),
    "price_amount" numeric(12,3) NOT NULL,
    "sort_order" integer
);


ALTER TABLE "mirumee"."product_productvariant" OWNER TO "saleor";

--
-- Name: product_productvariant_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_productvariant_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_productvariant_id_seq" OWNER TO "saleor";

--
-- Name: product_productvariant_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_productvariant_id_seq" OWNED BY "mirumee"."product_productvariant"."id";


--
-- Name: product_productvarianttranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_productvarianttranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "name" character varying(255) NOT NULL,
    "product_variant_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_productvarianttranslation" OWNER TO "saleor";

--
-- Name: product_productvarianttranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_productvarianttranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_productvarianttranslation_id_seq" OWNER TO "saleor";

--
-- Name: product_productvarianttranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_productvarianttranslation_id_seq" OWNED BY "mirumee"."product_productvarianttranslation"."id";


--
-- Name: product_variantimage; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."product_variantimage" (
    "id" integer NOT NULL,
    "image_id" integer NOT NULL,
    "variant_id" integer NOT NULL
);


ALTER TABLE "mirumee"."product_variantimage" OWNER TO "saleor";

--
-- Name: product_variantimage_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."product_variantimage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."product_variantimage_id_seq" OWNER TO "saleor";

--
-- Name: product_variantimage_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."product_variantimage_id_seq" OWNED BY "mirumee"."product_variantimage"."id";


--
-- Name: shipping_shippingmethod; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."shipping_shippingmethod" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "maximum_order_price_amount" numeric(12,3),
    "maximum_order_weight" double precision,
    "minimum_order_price_amount" numeric(12,3),
    "minimum_order_weight" double precision,
    "price_amount" numeric(12,3) NOT NULL,
    "type" character varying(30) NOT NULL,
    "shipping_zone_id" integer NOT NULL,
    "currency" character varying(3) NOT NULL
);


ALTER TABLE "mirumee"."shipping_shippingmethod" OWNER TO "saleor";

--
-- Name: shipping_shippingmethod_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."shipping_shippingmethod_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."shipping_shippingmethod_id_seq" OWNER TO "saleor";

--
-- Name: shipping_shippingmethod_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."shipping_shippingmethod_id_seq" OWNED BY "mirumee"."shipping_shippingmethod"."id";


--
-- Name: shipping_shippingmethodtranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."shipping_shippingmethodtranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "name" character varying(255),
    "shipping_method_id" integer NOT NULL
);


ALTER TABLE "mirumee"."shipping_shippingmethodtranslation" OWNER TO "saleor";

--
-- Name: shipping_shippingmethodtranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."shipping_shippingmethodtranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."shipping_shippingmethodtranslation_id_seq" OWNER TO "saleor";

--
-- Name: shipping_shippingmethodtranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."shipping_shippingmethodtranslation_id_seq" OWNED BY "mirumee"."shipping_shippingmethodtranslation"."id";


--
-- Name: shipping_shippingzone; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."shipping_shippingzone" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "countries" character varying(749) NOT NULL,
    "default" boolean NOT NULL
);


ALTER TABLE "mirumee"."shipping_shippingzone" OWNER TO "saleor";

--
-- Name: shipping_shippingzone_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."shipping_shippingzone_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."shipping_shippingzone_id_seq" OWNER TO "saleor";

--
-- Name: shipping_shippingzone_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."shipping_shippingzone_id_seq" OWNED BY "mirumee"."shipping_shippingzone"."id";


--
-- Name: site_authorizationkey; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."site_authorizationkey" (
    "id" integer NOT NULL,
    "name" character varying(20) NOT NULL,
    "key" "text" NOT NULL,
    "password" "text" NOT NULL,
    "site_settings_id" integer NOT NULL
);


ALTER TABLE "mirumee"."site_authorizationkey" OWNER TO "saleor";

--
-- Name: site_authorizationkey_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."site_authorizationkey_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."site_authorizationkey_id_seq" OWNER TO "saleor";

--
-- Name: site_authorizationkey_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."site_authorizationkey_id_seq" OWNED BY "mirumee"."site_authorizationkey"."id";


--
-- Name: site_sitesettings; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."site_sitesettings" (
    "id" integer NOT NULL,
    "header_text" character varying(200) NOT NULL,
    "description" character varying(500) NOT NULL,
    "site_id" integer NOT NULL,
    "bottom_menu_id" integer,
    "top_menu_id" integer,
    "display_gross_prices" boolean NOT NULL,
    "include_taxes_in_prices" boolean NOT NULL,
    "charge_taxes_on_shipping" boolean NOT NULL,
    "track_inventory_by_default" boolean NOT NULL,
    "homepage_collection_id" integer,
    "default_weight_unit" character varying(10) NOT NULL,
    "automatic_fulfillment_digital_products" boolean NOT NULL,
    "default_digital_max_downloads" integer,
    "default_digital_url_valid_days" integer,
    "company_address_id" integer,
    "default_mail_sender_address" character varying(254),
    "default_mail_sender_name" character varying(78) NOT NULL,
    "customer_set_password_url" character varying(255)
);


ALTER TABLE "mirumee"."site_sitesettings" OWNER TO "saleor";

--
-- Name: site_sitesettings_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."site_sitesettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."site_sitesettings_id_seq" OWNER TO "saleor";

--
-- Name: site_sitesettings_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."site_sitesettings_id_seq" OWNED BY "mirumee"."site_sitesettings"."id";


--
-- Name: site_sitesettingstranslation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."site_sitesettingstranslation" (
    "id" integer NOT NULL,
    "language_code" character varying(10) NOT NULL,
    "header_text" character varying(200) NOT NULL,
    "description" character varying(500) NOT NULL,
    "site_settings_id" integer NOT NULL
);


ALTER TABLE "mirumee"."site_sitesettingstranslation" OWNER TO "saleor";

--
-- Name: site_sitesettingstranslation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."site_sitesettingstranslation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."site_sitesettingstranslation_id_seq" OWNER TO "saleor";

--
-- Name: site_sitesettingstranslation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."site_sitesettingstranslation_id_seq" OWNED BY "mirumee"."site_sitesettingstranslation"."id";


--
-- Name: tests_book; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."tests_book" (
    "id" integer NOT NULL,
    "name" character varying(30) NOT NULL
);


ALTER TABLE "mirumee"."tests_book" OWNER TO "saleor";

--
-- Name: tests_book_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."tests_book_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."tests_book_id_seq" OWNER TO "saleor";

--
-- Name: tests_book_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."tests_book_id_seq" OWNED BY "mirumee"."tests_book"."id";


--
-- Name: userprofile_address_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."userprofile_address_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."userprofile_address_id_seq" OWNER TO "saleor";

--
-- Name: userprofile_address_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."userprofile_address_id_seq" OWNED BY "mirumee"."account_address"."id";


--
-- Name: userprofile_user_addresses_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."userprofile_user_addresses_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."userprofile_user_addresses_id_seq" OWNER TO "saleor";

--
-- Name: userprofile_user_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."userprofile_user_addresses_id_seq" OWNED BY "mirumee"."account_user_addresses"."id";


--
-- Name: userprofile_user_groups_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."userprofile_user_groups_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."userprofile_user_groups_id_seq" OWNER TO "saleor";

--
-- Name: userprofile_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."userprofile_user_groups_id_seq" OWNED BY "mirumee"."account_user_groups"."id";


--
-- Name: userprofile_user_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."userprofile_user_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."userprofile_user_id_seq" OWNER TO "saleor";

--
-- Name: userprofile_user_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."userprofile_user_id_seq" OWNED BY "mirumee"."account_user"."id";


--
-- Name: userprofile_user_user_permissions_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."userprofile_user_user_permissions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."userprofile_user_user_permissions_id_seq" OWNER TO "saleor";

--
-- Name: userprofile_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."userprofile_user_user_permissions_id_seq" OWNED BY "mirumee"."account_user_user_permissions"."id";


--
-- Name: warehouse_allocation; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."warehouse_allocation" (
    "id" integer NOT NULL,
    "quantity_allocated" integer NOT NULL,
    "order_line_id" integer NOT NULL,
    "stock_id" integer NOT NULL,
    CONSTRAINT "warehouse_allocation_quantity_allocated_check" CHECK (("quantity_allocated" >= 0))
);


ALTER TABLE "mirumee"."warehouse_allocation" OWNER TO "saleor";

--
-- Name: warehouse_allocation_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."warehouse_allocation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."warehouse_allocation_id_seq" OWNER TO "saleor";

--
-- Name: warehouse_allocation_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."warehouse_allocation_id_seq" OWNED BY "mirumee"."warehouse_allocation"."id";


--
-- Name: warehouse_stock; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."warehouse_stock" (
    "id" integer NOT NULL,
    "quantity" integer NOT NULL,
    "product_variant_id" integer NOT NULL,
    "warehouse_id" "uuid" NOT NULL,
    CONSTRAINT "warehouse_stock_quantity_check" CHECK (("quantity" >= 0))
);


ALTER TABLE "mirumee"."warehouse_stock" OWNER TO "saleor";

--
-- Name: warehouse_stock_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."warehouse_stock_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."warehouse_stock_id_seq" OWNER TO "saleor";

--
-- Name: warehouse_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."warehouse_stock_id_seq" OWNED BY "mirumee"."warehouse_stock"."id";


--
-- Name: warehouse_warehouse; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."warehouse_warehouse" (
    "id" "uuid" NOT NULL,
    "name" character varying(250) NOT NULL,
    "company_name" character varying(255) NOT NULL,
    "email" character varying(254) NOT NULL,
    "address_id" integer NOT NULL,
    "slug" character varying(255) NOT NULL
);


ALTER TABLE "mirumee"."warehouse_warehouse" OWNER TO "saleor";

--
-- Name: warehouse_warehouse_shipping_zones; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."warehouse_warehouse_shipping_zones" (
    "id" integer NOT NULL,
    "warehouse_id" "uuid" NOT NULL,
    "shippingzone_id" integer NOT NULL
);


ALTER TABLE "mirumee"."warehouse_warehouse_shipping_zones" OWNER TO "saleor";

--
-- Name: warehouse_warehouse_shipping_zones_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."warehouse_warehouse_shipping_zones_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."warehouse_warehouse_shipping_zones_id_seq" OWNER TO "saleor";

--
-- Name: warehouse_warehouse_shipping_zones_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."warehouse_warehouse_shipping_zones_id_seq" OWNED BY "mirumee"."warehouse_warehouse_shipping_zones"."id";


--
-- Name: webhook_webhook; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."webhook_webhook" (
    "id" integer NOT NULL,
    "target_url" character varying(255) NOT NULL,
    "is_active" boolean NOT NULL,
    "secret_key" character varying(255),
    "app_id" integer NOT NULL,
    "name" character varying(255)
);


ALTER TABLE "mirumee"."webhook_webhook" OWNER TO "saleor";

--
-- Name: webhook_webhook_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."webhook_webhook_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."webhook_webhook_id_seq" OWNER TO "saleor";

--
-- Name: webhook_webhook_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."webhook_webhook_id_seq" OWNED BY "mirumee"."webhook_webhook"."id";


--
-- Name: webhook_webhookevent; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."webhook_webhookevent" (
    "id" integer NOT NULL,
    "event_type" character varying(128) NOT NULL,
    "webhook_id" integer NOT NULL
);


ALTER TABLE "mirumee"."webhook_webhookevent" OWNER TO "saleor";

--
-- Name: webhook_webhookevent_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."webhook_webhookevent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."webhook_webhookevent_id_seq" OWNER TO "saleor";

--
-- Name: webhook_webhookevent_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."webhook_webhookevent_id_seq" OWNED BY "mirumee"."webhook_webhookevent"."id";


--
-- Name: wishlist_wishlist; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."wishlist_wishlist" (
    "id" integer NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "token" "uuid" NOT NULL,
    "user_id" integer
);


ALTER TABLE "mirumee"."wishlist_wishlist" OWNER TO "saleor";

--
-- Name: wishlist_wishlist_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."wishlist_wishlist_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."wishlist_wishlist_id_seq" OWNER TO "saleor";

--
-- Name: wishlist_wishlist_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."wishlist_wishlist_id_seq" OWNED BY "mirumee"."wishlist_wishlist"."id";


--
-- Name: wishlist_wishlistitem; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."wishlist_wishlistitem" (
    "id" integer NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "product_id" integer NOT NULL,
    "wishlist_id" integer NOT NULL
);


ALTER TABLE "mirumee"."wishlist_wishlistitem" OWNER TO "saleor";

--
-- Name: wishlist_wishlistitem_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."wishlist_wishlistitem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."wishlist_wishlistitem_id_seq" OWNER TO "saleor";

--
-- Name: wishlist_wishlistitem_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."wishlist_wishlistitem_id_seq" OWNED BY "mirumee"."wishlist_wishlistitem"."id";


--
-- Name: wishlist_wishlistitem_variants; Type: TABLE; Schema: mirumee; Owner: saleor
--

CREATE TABLE "mirumee"."wishlist_wishlistitem_variants" (
    "id" integer NOT NULL,
    "wishlistitem_id" integer NOT NULL,
    "productvariant_id" integer NOT NULL
);


ALTER TABLE "mirumee"."wishlist_wishlistitem_variants" OWNER TO "saleor";

--
-- Name: wishlist_wishlistitem_variants_id_seq; Type: SEQUENCE; Schema: mirumee; Owner: saleor
--

CREATE SEQUENCE "mirumee"."wishlist_wishlistitem_variants_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "mirumee"."wishlist_wishlistitem_variants_id_seq" OWNER TO "saleor";

--
-- Name: wishlist_wishlistitem_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: mirumee; Owner: saleor
--

ALTER SEQUENCE "mirumee"."wishlist_wishlistitem_variants_id_seq" OWNED BY "mirumee"."wishlist_wishlistitem_variants"."id";


--
-- Name: account_address id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_address" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."userprofile_address_id_seq"'::"regclass");


--
-- Name: account_customerevent id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customerevent" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."account_customerevent_id_seq"'::"regclass");


--
-- Name: account_customernote id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customernote" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."account_customernote_id_seq"'::"regclass");


--
-- Name: account_staffnotificationrecipient id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_staffnotificationrecipient" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."account_staffnotificationrecipient_id_seq"'::"regclass");


--
-- Name: account_user id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."userprofile_user_id_seq"'::"regclass");


--
-- Name: account_user_addresses id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_addresses" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."userprofile_user_addresses_id_seq"'::"regclass");


--
-- Name: account_user_groups id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_groups" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."userprofile_user_groups_id_seq"'::"regclass");


--
-- Name: account_user_user_permissions id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_user_permissions" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."userprofile_user_user_permissions_id_seq"'::"regclass");


--
-- Name: app_app id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_app" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."account_serviceaccount_id_seq"'::"regclass");


--
-- Name: app_app_permissions id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_app_permissions" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."account_serviceaccount_permissions_id_seq"'::"regclass");


--
-- Name: app_appinstallation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_appinstallation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."app_appinstallation_id_seq"'::"regclass");


--
-- Name: app_appinstallation_permissions id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_appinstallation_permissions" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."app_appinstallation_permissions_id_seq"'::"regclass");


--
-- Name: app_apptoken id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_apptoken" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."account_serviceaccounttoken_id_seq"'::"regclass");


--
-- Name: auth_group id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."auth_group_id_seq"'::"regclass");


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group_permissions" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."auth_group_permissions_id_seq"'::"regclass");


--
-- Name: auth_permission id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_permission" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."auth_permission_id_seq"'::"regclass");


--
-- Name: checkout_checkout_gift_cards id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout_gift_cards" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."checkout_checkout_gift_cards_id_seq"'::"regclass");


--
-- Name: checkout_checkoutline id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkoutline" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."cart_cartline_id_seq"'::"regclass");


--
-- Name: csv_exportevent id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportevent" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."csv_exportevent_id_seq"'::"regclass");


--
-- Name: csv_exportfile id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportfile" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."csv_exportfile_id_seq"'::"regclass");


--
-- Name: discount_sale id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_sale_id_seq"'::"regclass");


--
-- Name: discount_sale_categories id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_categories" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_sale_categories_id_seq"'::"regclass");


--
-- Name: discount_sale_collections id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_collections" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_sale_collections_id_seq"'::"regclass");


--
-- Name: discount_sale_products id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_products" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_sale_products_id_seq"'::"regclass");


--
-- Name: discount_saletranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_saletranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_saletranslation_id_seq"'::"regclass");


--
-- Name: discount_voucher id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_voucher_id_seq"'::"regclass");


--
-- Name: discount_voucher_categories id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_categories" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_voucher_categories_id_seq"'::"regclass");


--
-- Name: discount_voucher_collections id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_collections" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_voucher_collections_id_seq"'::"regclass");


--
-- Name: discount_voucher_products id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_products" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_voucher_products_id_seq"'::"regclass");


--
-- Name: discount_vouchercustomer id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchercustomer" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_vouchercustomer_id_seq"'::"regclass");


--
-- Name: discount_vouchertranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchertranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."discount_vouchertranslation_id_seq"'::"regclass");


--
-- Name: django_content_type id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_content_type" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."django_content_type_id_seq"'::"regclass");


--
-- Name: django_migrations id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_migrations" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."django_migrations_id_seq"'::"regclass");


--
-- Name: django_prices_openexchangerates_conversionrate id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_prices_openexchangerates_conversionrate" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."django_prices_openexchangerates_conversionrate_id_seq"'::"regclass");


--
-- Name: django_prices_vatlayer_ratetypes id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_prices_vatlayer_ratetypes" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."django_prices_vatlayer_ratetypes_id_seq"'::"regclass");


--
-- Name: django_prices_vatlayer_vat id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_prices_vatlayer_vat" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."django_prices_vatlayer_vat_id_seq"'::"regclass");


--
-- Name: django_site id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_site" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."django_site_id_seq"'::"regclass");


--
-- Name: giftcard_giftcard id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."giftcard_giftcard" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."giftcard_giftcard_id_seq"'::"regclass");


--
-- Name: invoice_invoice id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoice" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."invoice_invoice_id_seq"'::"regclass");


--
-- Name: invoice_invoiceevent id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoiceevent" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."invoice_invoiceevent_id_seq"'::"regclass");


--
-- Name: menu_menu id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menu" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."menu_menu_id_seq"'::"regclass");


--
-- Name: menu_menuitem id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitem" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."menu_menuitem_id_seq"'::"regclass");


--
-- Name: menu_menuitemtranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitemtranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."menu_menuitemtranslation_id_seq"'::"regclass");


--
-- Name: order_fulfillment id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillment" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."order_fulfillment_id_seq"'::"regclass");


--
-- Name: order_fulfillmentline id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillmentline" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."order_fulfillmentline_id_seq"'::"regclass");


--
-- Name: order_order id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."order_order_id_seq"'::"regclass");


--
-- Name: order_order_gift_cards id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order_gift_cards" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."order_order_gift_cards_id_seq"'::"regclass");


--
-- Name: order_orderevent id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderevent" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."order_orderevent_id_seq"'::"regclass");


--
-- Name: order_orderline id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderline" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."order_ordereditem_id_seq"'::"regclass");


--
-- Name: page_page id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."page_page" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."page_page_id_seq"'::"regclass");


--
-- Name: page_pagetranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."page_pagetranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."page_pagetranslation_id_seq"'::"regclass");


--
-- Name: payment_payment id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."payment_payment" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."payment_paymentmethod_id_seq"'::"regclass");


--
-- Name: payment_transaction id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."payment_transaction" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."payment_transaction_id_seq"'::"regclass");


--
-- Name: plugins_pluginconfiguration id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."plugins_pluginconfiguration" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."plugins_pluginconfiguration_id_seq"'::"regclass");


--
-- Name: product_assignedproductattribute id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_assignedproductattribute_id_seq"'::"regclass");


--
-- Name: product_assignedproductattribute_values id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute_values" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_assignedproductattribute_values_id_seq"'::"regclass");


--
-- Name: product_assignedvariantattribute id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_assignedvariantattribute_id_seq"'::"regclass");


--
-- Name: product_assignedvariantattribute_values id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute_values" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_assignedvariantattribute_values_id_seq"'::"regclass");


--
-- Name: product_attribute id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attribute" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_productattribute_id_seq"'::"regclass");


--
-- Name: product_attributeproduct id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributeproduct" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_attributeproduct_id_seq"'::"regclass");


--
-- Name: product_attributetranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributetranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_productattributetranslation_id_seq"'::"regclass");


--
-- Name: product_attributevalue id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevalue" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_attributechoicevalue_id_seq"'::"regclass");


--
-- Name: product_attributevaluetranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevaluetranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_attributechoicevaluetranslation_id_seq"'::"regclass");


--
-- Name: product_attributevariant id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevariant" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_attributevariant_id_seq"'::"regclass");


--
-- Name: product_category id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_category" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_category_id_seq"'::"regclass");


--
-- Name: product_categorytranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_categorytranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_categorytranslation_id_seq"'::"regclass");


--
-- Name: product_collection id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collection" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_collection_id_seq"'::"regclass");


--
-- Name: product_collectionproduct id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectionproduct" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_collection_products_id_seq"'::"regclass");


--
-- Name: product_collectiontranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectiontranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_collectiontranslation_id_seq"'::"regclass");


--
-- Name: product_digitalcontent id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontent" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_digitalcontent_id_seq"'::"regclass");


--
-- Name: product_digitalcontenturl id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontenturl" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_digitalcontenturl_id_seq"'::"regclass");


--
-- Name: product_product id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_product" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_product_id_seq"'::"regclass");


--
-- Name: product_productimage id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productimage" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_productimage_id_seq"'::"regclass");


--
-- Name: product_producttranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_producttranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_producttranslation_id_seq"'::"regclass");


--
-- Name: product_producttype id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_producttype" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_productclass_id_seq"'::"regclass");


--
-- Name: product_productvariant id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvariant" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_productvariant_id_seq"'::"regclass");


--
-- Name: product_productvarianttranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvarianttranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_productvarianttranslation_id_seq"'::"regclass");


--
-- Name: product_variantimage id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_variantimage" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."product_variantimage_id_seq"'::"regclass");


--
-- Name: shipping_shippingmethod id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingmethod" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."shipping_shippingmethod_id_seq"'::"regclass");


--
-- Name: shipping_shippingmethodtranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingmethodtranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."shipping_shippingmethodtranslation_id_seq"'::"regclass");


--
-- Name: shipping_shippingzone id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingzone" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."shipping_shippingzone_id_seq"'::"regclass");


--
-- Name: site_authorizationkey id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_authorizationkey" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."site_authorizationkey_id_seq"'::"regclass");


--
-- Name: site_sitesettings id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."site_sitesettings_id_seq"'::"regclass");


--
-- Name: site_sitesettingstranslation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettingstranslation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."site_sitesettingstranslation_id_seq"'::"regclass");


--
-- Name: tests_book id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."tests_book" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."tests_book_id_seq"'::"regclass");


--
-- Name: warehouse_allocation id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_allocation" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."warehouse_allocation_id_seq"'::"regclass");


--
-- Name: warehouse_stock id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_stock" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."warehouse_stock_id_seq"'::"regclass");


--
-- Name: warehouse_warehouse_shipping_zones id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse_shipping_zones" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."warehouse_warehouse_shipping_zones_id_seq"'::"regclass");


--
-- Name: webhook_webhook id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."webhook_webhook" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."webhook_webhook_id_seq"'::"regclass");


--
-- Name: webhook_webhookevent id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."webhook_webhookevent" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."webhook_webhookevent_id_seq"'::"regclass");


--
-- Name: wishlist_wishlist id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlist" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."wishlist_wishlist_id_seq"'::"regclass");


--
-- Name: wishlist_wishlistitem id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."wishlist_wishlistitem_id_seq"'::"regclass");


--
-- Name: wishlist_wishlistitem_variants id; Type: DEFAULT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem_variants" ALTER COLUMN "id" SET DEFAULT "nextval"('"mirumee"."wishlist_wishlistitem_variants_id_seq"'::"regclass");


--
-- Data for Name: account_address; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_address" ("id", "first_name", "last_name", "company_name", "street_address_1", "street_address_2", "city", "postal_code", "country", "country_area", "phone", "city_area") FROM stdin;
\.


--
-- Data for Name: account_customerevent; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_customerevent" ("id", "date", "type", "parameters", "order_id", "user_id") FROM stdin;
\.


--
-- Data for Name: account_customernote; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_customernote" ("id", "date", "content", "is_public", "customer_id", "user_id") FROM stdin;
\.


--
-- Data for Name: account_staffnotificationrecipient; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_staffnotificationrecipient" ("id", "staff_email", "active", "user_id") FROM stdin;
\.


--
-- Data for Name: account_user; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_user" ("id", "is_superuser", "email", "is_staff", "is_active", "password", "date_joined", "last_login", "default_billing_address_id", "default_shipping_address_id", "note", "first_name", "last_name", "avatar", "private_metadata", "metadata", "jwt_token_key") FROM stdin;
\.


--
-- Data for Name: account_user_addresses; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_user_addresses" ("id", "user_id", "address_id") FROM stdin;
\.


--
-- Data for Name: account_user_groups; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_user_groups" ("id", "user_id", "group_id") FROM stdin;
\.


--
-- Data for Name: account_user_user_permissions; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."account_user_user_permissions" ("id", "user_id", "permission_id") FROM stdin;
\.


--
-- Data for Name: app_app; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."app_app" ("id", "private_metadata", "metadata", "name", "created", "is_active", "about_app", "app_url", "configuration_url", "data_privacy", "data_privacy_url", "homepage_url", "identifier", "support_url", "type", "version") FROM stdin;
\.


--
-- Data for Name: app_app_permissions; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."app_app_permissions" ("id", "app_id", "permission_id") FROM stdin;
\.


--
-- Data for Name: app_appinstallation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."app_appinstallation" ("id", "status", "message", "created_at", "updated_at", "app_name", "manifest_url") FROM stdin;
\.


--
-- Data for Name: app_appinstallation_permissions; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."app_appinstallation_permissions" ("id", "appinstallation_id", "permission_id") FROM stdin;
\.


--
-- Data for Name: app_apptoken; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."app_apptoken" ("id", "name", "auth_token", "app_id") FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."auth_group" ("id", "name") FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."auth_group_permissions" ("id", "group_id", "permission_id") FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."auth_permission" ("id", "name", "content_type_id", "codename") FROM stdin;
1	Can add plugin configuration	1	add_pluginconfiguration
2	Can change plugin configuration	1	change_pluginconfiguration
3	Can delete plugin configuration	1	delete_pluginconfiguration
4	Can view plugin configuration	1	view_pluginconfiguration
5	Manage plugins	1	manage_plugins
6	Can add tenant	2	add_tenant
7	Can change tenant	2	change_tenant
8	Can delete tenant	2	delete_tenant
9	Can view tenant	2	view_tenant
10	Can add SES Stat	3	add_sesstat
11	Can change SES Stat	3	change_sesstat
12	Can delete SES Stat	3	delete_sesstat
13	Can view SES Stat	3	view_sesstat
14	Can add content type	4	add_contenttype
15	Can change content type	4	change_contenttype
16	Can delete content type	4	delete_contenttype
17	Can view content type	4	view_contenttype
18	Can add site	5	add_site
19	Can change site	5	change_site
20	Can delete site	5	delete_site
21	Can view site	5	view_site
22	Can add permission	6	add_permission
23	Can change permission	6	change_permission
24	Can delete permission	6	delete_permission
25	Can view permission	6	view_permission
26	Can add group	7	add_group
27	Can change group	7	change_group
28	Can delete group	7	delete_group
29	Can view group	7	view_group
30	Can add user	8	add_user
31	Can change user	8	change_user
32	Can delete user	8	delete_user
33	Can view user	8	view_user
34	Manage customers.	8	manage_users
35	Manage staff.	8	manage_staff
36	Can add address	9	add_address
37	Can change address	9	change_address
38	Can delete address	9	delete_address
39	Can view address	9	view_address
40	Can add customer note	10	add_customernote
41	Can change customer note	10	change_customernote
42	Can delete customer note	10	delete_customernote
43	Can view customer note	10	view_customernote
44	Can add customer event	11	add_customerevent
45	Can change customer event	11	change_customerevent
46	Can delete customer event	11	delete_customerevent
47	Can view customer event	11	view_customerevent
48	Can add staff notification recipient	12	add_staffnotificationrecipient
49	Can change staff notification recipient	12	change_staffnotificationrecipient
50	Can delete staff notification recipient	12	delete_staffnotificationrecipient
51	Can view staff notification recipient	12	view_staffnotificationrecipient
52	Can add sale	13	add_sale
53	Can change sale	13	change_sale
54	Can delete sale	13	delete_sale
55	Can view sale	13	view_sale
56	Manage sales and vouchers.	13	manage_discounts
57	Can add voucher	14	add_voucher
58	Can change voucher	14	change_voucher
59	Can delete voucher	14	delete_voucher
60	Can view voucher	14	view_voucher
61	Can add voucher translation	15	add_vouchertranslation
62	Can change voucher translation	15	change_vouchertranslation
63	Can delete voucher translation	15	delete_vouchertranslation
64	Can view voucher translation	15	view_vouchertranslation
65	Can add sale translation	16	add_saletranslation
66	Can change sale translation	16	change_saletranslation
67	Can delete sale translation	16	delete_saletranslation
68	Can view sale translation	16	view_saletranslation
69	Can add voucher customer	17	add_vouchercustomer
70	Can change voucher customer	17	change_vouchercustomer
71	Can delete voucher customer	17	delete_vouchercustomer
72	Can view voucher customer	17	view_vouchercustomer
73	Can add gift card	18	add_giftcard
74	Can change gift card	18	change_giftcard
75	Can delete gift card	18	delete_giftcard
76	Can view gift card	18	view_giftcard
77	Manage gift cards.	18	manage_gift_card
78	Can add category	19	add_category
79	Can change category	19	change_category
80	Can delete category	19	delete_category
81	Can view category	19	view_category
82	Can add product	20	add_product
83	Can change product	20	change_product
84	Can delete product	20	delete_product
85	Can view product	20	view_product
86	Manage products.	20	manage_products
87	Can add product image	21	add_productimage
88	Can change product image	21	change_productimage
89	Can delete product image	21	delete_productimage
90	Can view product image	21	view_productimage
91	Can add product variant	22	add_productvariant
92	Can change product variant	22	change_productvariant
93	Can delete product variant	22	delete_productvariant
94	Can view product variant	22	view_productvariant
95	Can add variant image	23	add_variantimage
96	Can change variant image	23	change_variantimage
97	Can delete variant image	23	delete_variantimage
98	Can view variant image	23	view_variantimage
99	Can add product type	24	add_producttype
100	Can change product type	24	change_producttype
101	Can delete product type	24	delete_producttype
102	Can view product type	24	view_producttype
103	Can add collection product	25	add_collectionproduct
104	Can change collection product	25	change_collectionproduct
105	Can delete collection product	25	delete_collectionproduct
106	Can view collection product	25	view_collectionproduct
107	Can add collection	26	add_collection
108	Can change collection	26	change_collection
109	Can delete collection	26	delete_collection
110	Can view collection	26	view_collection
111	Can add category translation	27	add_categorytranslation
112	Can change category translation	27	change_categorytranslation
113	Can delete category translation	27	delete_categorytranslation
114	Can view category translation	27	view_categorytranslation
115	Can add collection translation	28	add_collectiontranslation
116	Can change collection translation	28	change_collectiontranslation
117	Can delete collection translation	28	delete_collectiontranslation
118	Can view collection translation	28	view_collectiontranslation
119	Can add product translation	29	add_producttranslation
120	Can change product translation	29	change_producttranslation
121	Can delete product translation	29	delete_producttranslation
122	Can view product translation	29	view_producttranslation
123	Can add product variant translation	30	add_productvarianttranslation
124	Can change product variant translation	30	change_productvarianttranslation
125	Can delete product variant translation	30	delete_productvarianttranslation
126	Can view product variant translation	30	view_productvarianttranslation
127	Can add attribute	31	add_attribute
128	Can change attribute	31	change_attribute
129	Can delete attribute	31	delete_attribute
130	Can view attribute	31	view_attribute
131	Can add attribute value translation	32	add_attributevaluetranslation
132	Can change attribute value translation	32	change_attributevaluetranslation
133	Can delete attribute value translation	32	delete_attributevaluetranslation
134	Can view attribute value translation	32	view_attributevaluetranslation
135	Can add attribute value	33	add_attributevalue
136	Can change attribute value	33	change_attributevalue
137	Can delete attribute value	33	delete_attributevalue
138	Can view attribute value	33	view_attributevalue
139	Can add attribute translation	34	add_attributetranslation
140	Can change attribute translation	34	change_attributetranslation
141	Can delete attribute translation	34	delete_attributetranslation
142	Can view attribute translation	34	view_attributetranslation
143	Can add digital content	35	add_digitalcontent
144	Can change digital content	35	change_digitalcontent
145	Can delete digital content	35	delete_digitalcontent
146	Can view digital content	35	view_digitalcontent
147	Can add digital content url	36	add_digitalcontenturl
148	Can change digital content url	36	change_digitalcontenturl
149	Can delete digital content url	36	delete_digitalcontenturl
150	Can view digital content url	36	view_digitalcontenturl
151	Can add attribute product	37	add_attributeproduct
152	Can change attribute product	37	change_attributeproduct
153	Can delete attribute product	37	delete_attributeproduct
154	Can view attribute product	37	view_attributeproduct
155	Can add attribute variant	38	add_attributevariant
156	Can change attribute variant	38	change_attributevariant
157	Can delete attribute variant	38	delete_attributevariant
158	Can view attribute variant	38	view_attributevariant
159	Can add assigned product attribute	39	add_assignedproductattribute
160	Can change assigned product attribute	39	change_assignedproductattribute
161	Can delete assigned product attribute	39	delete_assignedproductattribute
162	Can view assigned product attribute	39	view_assignedproductattribute
163	Can add assigned variant attribute	40	add_assignedvariantattribute
164	Can change assigned variant attribute	40	change_assignedvariantattribute
165	Can delete assigned variant attribute	40	delete_assignedvariantattribute
166	Can view assigned variant attribute	40	view_assignedvariantattribute
167	Can add checkout	41	add_checkout
168	Can change checkout	41	change_checkout
169	Can delete checkout	41	delete_checkout
170	Can view checkout	41	view_checkout
171	Manage checkouts	41	manage_checkouts
172	Can add checkout line	42	add_checkoutline
173	Can change checkout line	42	change_checkoutline
174	Can delete checkout line	42	delete_checkoutline
175	Can view checkout line	42	view_checkoutline
176	Can add export file	43	add_exportfile
177	Can change export file	43	change_exportfile
178	Can delete export file	43	delete_exportfile
179	Can view export file	43	view_exportfile
180	Can add export event	44	add_exportevent
181	Can change export event	44	change_exportevent
182	Can delete export event	44	delete_exportevent
183	Can view export event	44	view_exportevent
184	Can add menu	45	add_menu
185	Can change menu	45	change_menu
186	Can delete menu	45	delete_menu
187	Can view menu	45	view_menu
188	Manage navigation.	45	manage_menus
189	Can add menu item	46	add_menuitem
190	Can change menu item	46	change_menuitem
191	Can delete menu item	46	delete_menuitem
192	Can view menu item	46	view_menuitem
193	Can add menu item translation	47	add_menuitemtranslation
194	Can change menu item translation	47	change_menuitemtranslation
195	Can delete menu item translation	47	delete_menuitemtranslation
196	Can view menu item translation	47	view_menuitemtranslation
197	Can add order	48	add_order
198	Can change order	48	change_order
199	Can delete order	48	delete_order
200	Can view order	48	view_order
201	Manage orders.	48	manage_orders
202	Can add order line	49	add_orderline
203	Can change order line	49	change_orderline
204	Can delete order line	49	delete_orderline
205	Can view order line	49	view_orderline
206	Can add fulfillment	50	add_fulfillment
207	Can change fulfillment	50	change_fulfillment
208	Can delete fulfillment	50	delete_fulfillment
209	Can view fulfillment	50	view_fulfillment
210	Can add fulfillment line	51	add_fulfillmentline
211	Can change fulfillment line	51	change_fulfillmentline
212	Can delete fulfillment line	51	delete_fulfillmentline
213	Can view fulfillment line	51	view_fulfillmentline
214	Can add order event	52	add_orderevent
215	Can change order event	52	change_orderevent
216	Can delete order event	52	delete_orderevent
217	Can view order event	52	view_orderevent
218	Can add invoice	53	add_invoice
219	Can change invoice	53	change_invoice
220	Can delete invoice	53	delete_invoice
221	Can view invoice	53	view_invoice
222	Can add invoice event	54	add_invoiceevent
223	Can change invoice event	54	change_invoiceevent
224	Can delete invoice event	54	delete_invoiceevent
225	Can view invoice event	54	view_invoiceevent
226	Can add shipping method	55	add_shippingmethod
227	Can change shipping method	55	change_shippingmethod
228	Can delete shipping method	55	delete_shippingmethod
229	Can view shipping method	55	view_shippingmethod
230	Can add shipping method translation	56	add_shippingmethodtranslation
231	Can change shipping method translation	56	change_shippingmethodtranslation
232	Can delete shipping method translation	56	delete_shippingmethodtranslation
233	Can view shipping method translation	56	view_shippingmethodtranslation
234	Can add shipping zone	57	add_shippingzone
235	Can change shipping zone	57	change_shippingzone
236	Can delete shipping zone	57	delete_shippingzone
237	Can view shipping zone	57	view_shippingzone
238	Manage shipping.	57	manage_shipping
239	Can add site settings	58	add_sitesettings
240	Can change site settings	58	change_sitesettings
241	Can delete site settings	58	delete_sitesettings
242	Can view site settings	58	view_sitesettings
243	Manage settings.	58	manage_settings
244	Manage translations.	58	manage_translations
245	Can add authorization key	59	add_authorizationkey
246	Can change authorization key	59	change_authorizationkey
247	Can delete authorization key	59	delete_authorizationkey
248	Can view authorization key	59	view_authorizationkey
249	Can add site settings translation	60	add_sitesettingstranslation
250	Can change site settings translation	60	change_sitesettingstranslation
251	Can delete site settings translation	60	delete_sitesettingstranslation
252	Can view site settings translation	60	view_sitesettingstranslation
253	Can add page	61	add_page
254	Can change page	61	change_page
255	Can delete page	61	delete_page
256	Can view page	61	view_page
257	Manage pages.	61	manage_pages
258	Can add page translation	62	add_pagetranslation
259	Can change page translation	62	change_pagetranslation
260	Can delete page translation	62	delete_pagetranslation
261	Can view page translation	62	view_pagetranslation
262	Can add transaction	63	add_transaction
263	Can change transaction	63	change_transaction
264	Can delete transaction	63	delete_transaction
265	Can view transaction	63	view_transaction
266	Can add payment	64	add_payment
267	Can change payment	64	change_payment
268	Can delete payment	64	delete_payment
269	Can view payment	64	view_payment
270	Can add warehouse	65	add_warehouse
271	Can change warehouse	65	change_warehouse
272	Can delete warehouse	65	delete_warehouse
273	Can view warehouse	65	view_warehouse
274	Can add stock	66	add_stock
275	Can change stock	66	change_stock
276	Can delete stock	66	delete_stock
277	Can view stock	66	view_stock
278	Can add allocation	67	add_allocation
279	Can change allocation	67	change_allocation
280	Can delete allocation	67	delete_allocation
281	Can view allocation	67	view_allocation
282	Can add webhook	68	add_webhook
283	Can change webhook	68	change_webhook
284	Can delete webhook	68	delete_webhook
285	Can view webhook	68	view_webhook
286	Can add webhook event	69	add_webhookevent
287	Can change webhook event	69	change_webhookevent
288	Can delete webhook event	69	delete_webhookevent
289	Can view webhook event	69	view_webhookevent
290	Can add wishlist	70	add_wishlist
291	Can change wishlist	70	change_wishlist
292	Can delete wishlist	70	delete_wishlist
293	Can view wishlist	70	view_wishlist
294	Can add wishlist item	71	add_wishlistitem
295	Can change wishlist item	71	change_wishlistitem
296	Can delete wishlist item	71	delete_wishlistitem
297	Can view wishlist item	71	view_wishlistitem
298	Can add app	72	add_app
299	Can change app	72	change_app
300	Can delete app	72	delete_app
301	Can view app	72	view_app
302	Manage apps	72	manage_apps
303	Can add app token	73	add_apptoken
304	Can change app token	73	change_apptoken
305	Can delete app token	73	delete_apptoken
306	Can view app token	73	view_apptoken
307	Can add app installation	74	add_appinstallation
308	Can change app installation	74	change_appinstallation
309	Can delete app installation	74	delete_appinstallation
310	Can view app installation	74	view_appinstallation
311	Can add conversion rate	75	add_conversionrate
312	Can change conversion rate	75	change_conversionrate
313	Can delete conversion rate	75	delete_conversionrate
314	Can view conversion rate	75	view_conversionrate
315	Can add vat	76	add_vat
316	Can change vat	76	change_vat
317	Can delete vat	76	delete_vat
318	Can view vat	76	view_vat
319	Can add rate types	77	add_ratetypes
320	Can change rate types	77	change_ratetypes
321	Can delete rate types	77	delete_ratetypes
322	Can view rate types	77	view_ratetypes
323	Can add book	78	add_book
324	Can change book	78	change_book
325	Can delete book	78	delete_book
326	Can view book	78	view_book
\.


--
-- Data for Name: checkout_checkout; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."checkout_checkout" ("created", "last_change", "email", "token", "quantity", "user_id", "billing_address_id", "discount_amount", "discount_name", "note", "shipping_address_id", "shipping_method_id", "voucher_code", "translated_discount_name", "metadata", "private_metadata", "currency", "country", "redirect_url", "tracking_code") FROM stdin;
\.


--
-- Data for Name: checkout_checkout_gift_cards; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."checkout_checkout_gift_cards" ("id", "checkout_id", "giftcard_id") FROM stdin;
\.


--
-- Data for Name: checkout_checkoutline; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."checkout_checkoutline" ("id", "quantity", "checkout_id", "variant_id", "data") FROM stdin;
\.


--
-- Data for Name: csv_exportevent; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."csv_exportevent" ("id", "date", "type", "parameters", "app_id", "export_file_id", "user_id") FROM stdin;
\.


--
-- Data for Name: csv_exportfile; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."csv_exportfile" ("id", "status", "created_at", "updated_at", "content_file", "app_id", "user_id", "message") FROM stdin;
\.


--
-- Data for Name: discount_sale; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_sale" ("id", "name", "type", "value", "end_date", "start_date") FROM stdin;
\.


--
-- Data for Name: discount_sale_categories; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_sale_categories" ("id", "sale_id", "category_id") FROM stdin;
\.


--
-- Data for Name: discount_sale_collections; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_sale_collections" ("id", "sale_id", "collection_id") FROM stdin;
\.


--
-- Data for Name: discount_sale_products; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_sale_products" ("id", "sale_id", "product_id") FROM stdin;
\.


--
-- Data for Name: discount_saletranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_saletranslation" ("id", "language_code", "name", "sale_id") FROM stdin;
\.


--
-- Data for Name: discount_voucher; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_voucher" ("id", "type", "name", "code", "usage_limit", "used", "start_date", "end_date", "discount_value_type", "discount_value", "min_spent_amount", "apply_once_per_order", "countries", "min_checkout_items_quantity", "apply_once_per_customer", "currency") FROM stdin;
\.


--
-- Data for Name: discount_voucher_categories; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_voucher_categories" ("id", "voucher_id", "category_id") FROM stdin;
\.


--
-- Data for Name: discount_voucher_collections; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_voucher_collections" ("id", "voucher_id", "collection_id") FROM stdin;
\.


--
-- Data for Name: discount_voucher_products; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_voucher_products" ("id", "voucher_id", "product_id") FROM stdin;
\.


--
-- Data for Name: discount_vouchercustomer; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_vouchercustomer" ("id", "customer_email", "voucher_id") FROM stdin;
\.


--
-- Data for Name: discount_vouchertranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."discount_vouchertranslation" ("id", "language_code", "name", "voucher_id") FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."django_content_type" ("id", "app_label", "model") FROM stdin;
1	plugins	pluginconfiguration
2	tenants	tenant
3	django_ses	sesstat
4	contenttypes	contenttype
5	sites	site
6	auth	permission
7	auth	group
8	account	user
9	account	address
10	account	customernote
11	account	customerevent
12	account	staffnotificationrecipient
13	discount	sale
14	discount	voucher
15	discount	vouchertranslation
16	discount	saletranslation
17	discount	vouchercustomer
18	giftcard	giftcard
19	product	category
20	product	product
21	product	productimage
22	product	productvariant
23	product	variantimage
24	product	producttype
25	product	collectionproduct
26	product	collection
27	product	categorytranslation
28	product	collectiontranslation
29	product	producttranslation
30	product	productvarianttranslation
31	product	attribute
32	product	attributevaluetranslation
33	product	attributevalue
34	product	attributetranslation
35	product	digitalcontent
36	product	digitalcontenturl
37	product	attributeproduct
38	product	attributevariant
39	product	assignedproductattribute
40	product	assignedvariantattribute
41	checkout	checkout
42	checkout	checkoutline
43	csv	exportfile
44	csv	exportevent
45	menu	menu
46	menu	menuitem
47	menu	menuitemtranslation
48	order	order
49	order	orderline
50	order	fulfillment
51	order	fulfillmentline
52	order	orderevent
53	invoice	invoice
54	invoice	invoiceevent
55	shipping	shippingmethod
56	shipping	shippingmethodtranslation
57	shipping	shippingzone
58	site	sitesettings
59	site	authorizationkey
60	site	sitesettingstranslation
61	page	page
62	page	pagetranslation
63	payment	transaction
64	payment	payment
65	warehouse	warehouse
66	warehouse	stock
67	warehouse	allocation
68	webhook	webhook
69	webhook	webhookevent
70	wishlist	wishlist
71	wishlist	wishlistitem
72	app	app
73	app	apptoken
74	app	appinstallation
75	django_prices_openexchangerates	conversionrate
76	django_prices_vatlayer	vat
77	django_prices_vatlayer	ratetypes
78	tests	book
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."django_migrations" ("id", "app", "name", "applied") FROM stdin;
1	plugins	0001_initial	2020-10-16 07:06:41.924719+00
2	plugins	0002_auto_20200417_0335	2020-10-16 07:06:41.989125+00
3	contenttypes	0001_initial	2020-10-16 07:06:42.014745+00
4	contenttypes	0002_remove_content_type_name	2020-10-16 07:06:42.039452+00
5	auth	0001_initial	2020-10-16 07:06:42.079322+00
6	auth	0002_alter_permission_name_max_length	2020-10-16 07:06:42.126626+00
7	auth	0003_alter_user_email_max_length	2020-10-16 07:06:42.138802+00
8	auth	0004_alter_user_username_opts	2020-10-16 07:06:42.15219+00
9	auth	0005_alter_user_last_login_null	2020-10-16 07:06:42.16458+00
10	auth	0006_require_contenttypes_0002	2020-10-16 07:06:42.171837+00
11	auth	0007_alter_validators_add_error_messages	2020-10-16 07:06:42.183562+00
12	auth	0008_alter_user_username_max_length	2020-10-16 07:06:42.197434+00
13	auth	0009_alter_user_last_name_max_length	2020-10-16 07:06:42.20941+00
14	auth	0010_alter_group_name_max_length	2020-10-16 07:06:42.227635+00
15	auth	0011_update_proxy_permissions	2020-10-16 07:06:42.244138+00
16	product	0001_initial	2020-10-16 07:06:42.389342+00
17	product	0002_auto_20150722_0545	2020-10-16 07:06:42.521339+00
18	product	0003_auto_20150820_2016	2020-10-16 07:06:42.569189+00
19	product	0003_auto_20150820_1955	2020-10-16 07:06:42.588799+00
20	product	0004_merge	2020-10-16 07:06:42.598774+00
21	product	0005_auto_20150825_1433	2020-10-16 07:06:42.655622+00
22	product	0006_product_updated_at	2020-10-16 07:06:42.683722+00
23	product	0007_auto_20160112_1025	2020-10-16 07:06:42.739065+00
24	product	0008_auto_20160114_0733	2020-10-16 07:06:42.786398+00
25	product	0009_discount_categories	2020-10-16 07:06:42.810442+00
26	product	0010_auto_20160129_0826	2020-10-16 07:06:42.863331+00
27	product	0011_stock_quantity_allocated	2020-10-16 07:06:42.883625+00
28	product	0012_auto_20160218_0812	2020-10-16 07:06:42.915254+00
29	product	0013_auto_20161207_0555	2020-10-16 07:06:42.958009+00
30	product	0014_auto_20161207_0840	2020-10-16 07:06:42.982995+00
31	product	0015_transfer_locations	2020-10-16 07:06:43.011992+00
32	product	0016_auto_20161207_0843	2020-10-16 07:06:43.047999+00
33	product	0017_remove_stock_location	2020-10-16 07:06:43.068699+00
34	product	0018_auto_20161207_0844	2020-10-16 07:06:43.114468+00
35	product	0019_auto_20161212_0230	2020-10-16 07:06:43.171669+00
36	product	0020_attribute_data_to_class	2020-10-16 07:06:43.245856+00
37	product	0021_add_hstore_extension	2020-10-16 07:06:43.268602+00
38	product	0022_auto_20161212_0301	2020-10-16 07:06:43.343974+00
39	product	0023_auto_20161211_1912	2020-10-16 07:06:43.370087+00
40	product	0024_migrate_json_data	2020-10-16 07:06:43.419592+00
41	product	0025_auto_20161219_0517	2020-10-16 07:06:43.437654+00
42	product	0026_auto_20161230_0347	2020-10-16 07:06:43.458436+00
43	product	0027_auto_20170113_0435	2020-10-16 07:06:43.551605+00
44	product	0013_auto_20161130_0608	2020-10-16 07:06:43.571917+00
45	product	0014_remove_productvariant_attributes	2020-10-16 07:06:43.596357+00
46	product	0015_productvariant_attributes	2020-10-16 07:06:43.622946+00
47	product	0016_auto_20161204_0311	2020-10-16 07:06:43.641085+00
48	product	0017_attributechoicevalue_slug	2020-10-16 07:06:43.660998+00
49	product	0018_auto_20161212_0725	2020-10-16 07:06:43.694891+00
50	product	0026_merge_20161221_0845	2020-10-16 07:06:43.703051+00
51	product	0028_merge_20170116_1016	2020-10-16 07:06:43.711037+00
52	product	0029_product_is_featured	2020-10-16 07:06:43.737928+00
53	product	0030_auto_20170206_0407	2020-10-16 07:06:43.928807+00
54	product	0031_auto_20170206_0601	2020-10-16 07:06:43.968221+00
55	product	0032_auto_20170216_0438	2020-10-16 07:06:43.987452+00
56	product	0033_auto_20170227_0757	2020-10-16 07:06:44.041352+00
57	product	0034_product_is_published	2020-10-16 07:06:44.065987+00
58	product	0035_auto_20170919_0846	2020-10-16 07:06:44.087985+00
59	product	0036_auto_20171115_0608	2020-10-16 07:06:44.103975+00
60	product	0037_auto_20171124_0847	2020-10-16 07:06:44.119268+00
61	product	0038_auto_20171129_0616	2020-10-16 07:06:44.134418+00
62	product	0037_auto_20171129_1004	2020-10-16 07:06:44.184125+00
63	product	0039_merge_20171130_0727	2020-10-16 07:06:44.195674+00
64	product	0040_auto_20171205_0428	2020-10-16 07:06:44.21996+00
65	product	0041_auto_20171205_0546	2020-10-16 07:06:44.242325+00
66	product	0042_auto_20171206_0501	2020-10-16 07:06:44.262444+00
67	product	0043_auto_20171207_0839	2020-10-16 07:06:44.282454+00
68	product	0044_auto_20180108_0814	2020-10-16 07:06:44.851933+00
69	product	0045_md_to_html	2020-10-16 07:06:44.880146+00
70	product	0046_product_category	2020-10-16 07:06:44.925955+00
71	product	0047_auto_20180117_0359	2020-10-16 07:06:44.993699+00
72	product	0048_product_class_to_type	2020-10-16 07:06:45.217292+00
73	product	0049_collection	2020-10-16 07:06:45.293769+00
74	product	0050_auto_20180131_0746	2020-10-16 07:06:45.345059+00
75	product	0051_auto_20180202_1106	2020-10-16 07:06:45.364156+00
76	product	0052_slug_field_length	2020-10-16 07:06:45.416301+00
77	product	0053_product_seo_description	2020-10-16 07:06:45.444519+00
78	product	0053_auto_20180305_1002	2020-10-16 07:06:45.475153+00
79	product	0054_merge_20180320_1108	2020-10-16 07:06:45.484946+00
80	shipping	0001_initial	2020-10-16 07:06:45.522206+00
81	shipping	0002_auto_20160906_0741	2020-10-16 07:06:45.548769+00
82	shipping	0003_auto_20170116_0700	2020-10-16 07:06:45.561006+00
83	shipping	0004_auto_20170206_0407	2020-10-16 07:06:45.603094+00
84	shipping	0005_auto_20170906_0556	2020-10-16 07:06:45.618364+00
85	shipping	0006_auto_20171109_0908	2020-10-16 07:06:45.630573+00
86	shipping	0007_auto_20171129_1004	2020-10-16 07:06:45.645367+00
87	shipping	0008_auto_20180108_0814	2020-10-16 07:06:45.68727+00
88	userprofile	0001_initial	2020-10-16 07:06:45.775442+00
89	order	0001_initial	2020-10-16 07:06:45.99841+00
90	order	0002_auto_20150820_1955	2020-10-16 07:06:46.111219+00
91	order	0003_auto_20150825_1433	2020-10-16 07:06:46.147582+00
92	order	0004_order_total	2020-10-16 07:06:46.173335+00
93	order	0005_deliverygroup_last_updated	2020-10-16 07:06:46.201327+00
94	order	0006_deliverygroup_shipping_method	2020-10-16 07:06:46.232009+00
95	order	0007_deliverygroup_tracking_number	2020-10-16 07:06:46.273008+00
96	order	0008_auto_20151026_0820	2020-10-16 07:06:46.32588+00
97	order	0009_auto_20151201_0820	2020-10-16 07:06:46.396494+00
98	order	0010_auto_20160119_0541	2020-10-16 07:06:46.734017+00
99	discount	0001_initial	2020-10-16 07:06:46.794743+00
100	discount	0002_voucher	2020-10-16 07:06:46.881617+00
101	discount	0003_auto_20160207_0534	2020-10-16 07:06:47.027148+00
102	order	0011_auto_20160207_0534	2020-10-16 07:06:47.110113+00
103	order	0012_auto_20160216_1032	2020-10-16 07:06:47.169607+00
104	order	0013_auto_20160906_0741	2020-10-16 07:06:47.254141+00
105	order	0014_auto_20161028_0955	2020-10-16 07:06:47.286387+00
106	order	0015_auto_20170206_0407	2020-10-16 07:06:47.866164+00
107	order	0016_order_language_code	2020-10-16 07:06:47.898188+00
108	order	0017_auto_20170906_0556	2020-10-16 07:06:47.922208+00
109	order	0018_auto_20170919_0839	2020-10-16 07:06:47.948748+00
110	order	0019_auto_20171109_1423	2020-10-16 07:06:48.170079+00
111	order	0020_auto_20171123_0609	2020-10-16 07:06:48.233657+00
112	order	0021_auto_20171129_1004	2020-10-16 07:06:48.575981+00
113	order	0022_auto_20171205_0428	2020-10-16 07:06:48.632767+00
114	order	0023_auto_20171206_0506	2020-10-16 07:06:48.697475+00
115	order	0024_remove_order_status	2020-10-16 07:06:48.727033+00
116	order	0025_auto_20171214_1015	2020-10-16 07:06:48.761337+00
117	order	0026_auto_20171218_0428	2020-10-16 07:06:48.835025+00
118	order	0027_auto_20180108_0814	2020-10-16 07:06:49.570036+00
119	order	0028_status_fsm	2020-10-16 07:06:49.595211+00
120	order	0029_auto_20180111_0845	2020-10-16 07:06:49.656397+00
121	order	0030_auto_20180118_0605	2020-10-16 07:06:49.718042+00
122	order	0031_auto_20180119_0405	2020-10-16 07:06:49.800066+00
123	order	0032_orderline_is_shipping_required	2020-10-16 07:06:49.864047+00
124	order	0033_auto_20180123_0832	2020-10-16 07:06:49.891347+00
125	order	0034_auto_20180221_1056	2020-10-16 07:06:49.952103+00
126	order	0035_auto_20180221_1057	2020-10-16 07:06:50.001734+00
127	order	0036_remove_order_total_tax	2020-10-16 07:06:50.032426+00
128	order	0037_auto_20180228_0450	2020-10-16 07:06:50.376684+00
129	order	0038_auto_20180228_0451	2020-10-16 07:06:50.421984+00
130	order	0039_auto_20180312_1203	2020-10-16 07:06:50.49119+00
131	order	0040_auto_20180210_0422	2020-10-16 07:06:50.756805+00
132	order	0041_auto_20180222_0458	2020-10-16 07:06:50.834554+00
133	order	0042_auto_20180227_0436	2020-10-16 07:06:51.001536+00
134	order	0043_auto_20180322_0655	2020-10-16 07:06:51.049471+00
135	order	0044_auto_20180326_1055	2020-10-16 07:06:51.247827+00
136	order	0045_auto_20180329_0142	2020-10-16 07:06:51.468854+00
137	order	0046_order_line_taxes	2020-10-16 07:06:51.53476+00
138	order	0047_order_line_name_length	2020-10-16 07:06:51.569697+00
139	order	0048_auto_20180629_1055	2020-10-16 07:06:51.635557+00
140	order	0049_auto_20180719_0520	2020-10-16 07:06:51.660911+00
141	order	0050_auto_20180803_0528	2020-10-16 07:06:51.720414+00
142	order	0050_auto_20180803_0337	2020-10-16 07:06:51.771442+00
143	order	0051_merge_20180807_0704	2020-10-16 07:06:51.78177+00
144	order	0052_auto_20180822_0720	2020-10-16 07:06:51.857652+00
145	order	0053_orderevent	2020-10-16 07:06:51.903172+00
146	order	0054_move_data_to_order_events	2020-10-16 07:06:52.277638+00
147	order	0055_remove_order_note_order_history_entry	2020-10-16 07:06:52.49614+00
148	order	0056_auto_20180911_1541	2020-10-16 07:06:52.531229+00
149	order	0057_orderevent_parameters_new	2020-10-16 07:06:52.598376+00
150	order	0058_remove_orderevent_parameters	2020-10-16 07:06:52.631555+00
151	order	0059_auto_20180913_0841	2020-10-16 07:06:52.669874+00
152	order	0060_auto_20180919_0731	2020-10-16 07:06:52.706652+00
153	order	0061_auto_20180920_0859	2020-10-16 07:06:52.741746+00
154	order	0062_auto_20180921_0949	2020-10-16 07:06:52.805807+00
155	order	0063_auto_20180926_0446	2020-10-16 07:06:52.837981+00
156	order	0064_auto_20181016_0819	2020-10-16 07:06:52.902743+00
157	cart	0001_initial	2020-10-16 07:06:53.018577+00
158	cart	0002_auto_20161014_1221	2020-10-16 07:06:53.104761+00
159	cart	fix_empty_data_in_lines	2020-10-16 07:06:53.151609+00
160	cart	0001_auto_20170113_0435	2020-10-16 07:06:53.218316+00
161	cart	0002_auto_20170206_0407	2020-10-16 07:06:53.415682+00
162	cart	0003_auto_20170906_0556	2020-10-16 07:06:53.44249+00
163	cart	0004_auto_20171129_1004	2020-10-16 07:06:53.482966+00
164	cart	0005_auto_20180108_0814	2020-10-16 07:06:53.824685+00
165	cart	0006_auto_20180221_0825	2020-10-16 07:06:53.852009+00
166	userprofile	0002_auto_20150907_0602	2020-10-16 07:06:54.190164+00
167	userprofile	0003_auto_20151104_1102	2020-10-16 07:06:54.241553+00
168	userprofile	0004_auto_20160114_0419	2020-10-16 07:06:54.282183+00
169	userprofile	0005_auto_20160205_0651	2020-10-16 07:06:54.352624+00
170	userprofile	0006_auto_20160829_0819	2020-10-16 07:06:54.398827+00
171	userprofile	0007_auto_20161115_0940	2020-10-16 07:06:54.470019+00
172	userprofile	0008_auto_20161115_1011	2020-10-16 07:06:54.497146+00
173	userprofile	0009_auto_20170206_0407	2020-10-16 07:06:54.599788+00
174	userprofile	0010_auto_20170919_0839	2020-10-16 07:06:54.623954+00
175	userprofile	0011_auto_20171110_0552	2020-10-16 07:06:54.648597+00
176	userprofile	0012_auto_20171117_0846	2020-10-16 07:06:54.67081+00
177	userprofile	0013_auto_20171120_0521	2020-10-16 07:06:54.751091+00
178	userprofile	0014_auto_20171129_1004	2020-10-16 07:06:54.788637+00
179	userprofile	0015_auto_20171213_0734	2020-10-16 07:06:54.82976+00
180	userprofile	0016_auto_20180108_0814	2020-10-16 07:06:55.406542+00
181	account	0017_auto_20180206_0957	2020-10-16 07:06:55.46168+00
182	account	0018_auto_20180426_0641	2020-10-16 07:06:55.584372+00
183	account	0019_auto_20180528_1205	2020-10-16 07:06:55.676114+00
184	checkout	0007_merge_cart_with_checkout	2020-10-16 07:06:56.37075+00
185	checkout	0008_rename_tables	2020-10-16 07:06:56.436588+00
186	checkout	0009_cart_translated_discount_name	2020-10-16 07:06:56.470399+00
187	checkout	0010_auto_20180822_0720	2020-10-16 07:06:56.527695+00
188	checkout	0011_auto_20180913_0817	2020-10-16 07:06:56.63297+00
189	checkout	0012_remove_cartline_data	2020-10-16 07:06:56.666997+00
190	checkout	0013_auto_20180913_0841	2020-10-16 07:06:56.711707+00
191	checkout	0014_auto_20180921_0751	2020-10-16 07:06:56.739647+00
192	checkout	0015_auto_20181017_1346	2020-10-16 07:06:56.768105+00
193	payment	0001_initial	2020-10-16 07:06:56.868774+00
194	payment	0002_transfer_payment_to_payment_method	2020-10-16 07:06:56.942849+00
195	order	0065_auto_20181017_1346	2020-10-16 07:06:57.125701+00
196	order	0066_auto_20181023_0319	2020-10-16 07:06:57.183668+00
197	order	0067_auto_20181102_1054	2020-10-16 07:06:57.216755+00
198	order	0068_order_checkout_token	2020-10-16 07:06:57.257211+00
199	order	0069_auto_20190225_2305	2020-10-16 07:06:57.280278+00
200	order	0070_drop_update_event_and_rename_events	2020-10-16 07:06:57.446614+00
201	account	0020_user_token	2020-10-16 07:06:57.486701+00
202	account	0021_unique_token	2020-10-16 07:06:57.563025+00
203	account	0022_auto_20180718_0956	2020-10-16 07:06:57.59158+00
204	account	0023_auto_20180719_0520	2020-10-16 07:06:57.62186+00
205	account	0024_auto_20181011_0737	2020-10-16 07:06:57.682337+00
206	account	0025_auto_20190314_0550	2020-10-16 07:06:57.705422+00
207	account	0026_user_avatar	2020-10-16 07:06:57.739726+00
208	account	0027_customerevent	2020-10-16 07:06:57.794234+00
209	account	0028_user_private_meta	2020-10-16 07:06:57.848754+00
210	account	0029_user_meta	2020-10-16 07:06:57.885386+00
211	account	0030_auto_20190719_0733	2020-10-16 07:06:57.916616+00
212	account	0031_auto_20190719_0745	2020-10-16 07:06:57.950267+00
213	account	0032_remove_user_token	2020-10-16 07:06:57.981553+00
214	account	0033_serviceaccount	2020-10-16 07:06:58.29171+00
215	webhook	0001_initial	2020-10-16 07:06:58.416186+00
216	webhook	0002_webhook_name	2020-10-16 07:06:58.465425+00
217	sites	0001_initial	2020-10-16 07:06:58.48553+00
218	sites	0002_alter_domain_unique	2020-10-16 07:06:58.508569+00
219	site	0001_initial	2020-10-16 07:06:58.529094+00
220	site	0002_add_default_data	2020-10-16 07:06:58.597938+00
221	site	0003_sitesettings_description	2020-10-16 07:06:58.622386+00
222	site	0004_auto_20170221_0426	2020-10-16 07:06:58.654328+00
223	site	0005_auto_20170906_0556	2020-10-16 07:06:58.677453+00
224	site	0006_auto_20171025_0454	2020-10-16 07:06:58.700248+00
225	site	0007_auto_20171027_0856	2020-10-16 07:06:58.774769+00
226	site	0008_auto_20171027_0856	2020-10-16 07:06:58.828487+00
227	site	0009_auto_20171109_0849	2020-10-16 07:06:58.848808+00
228	site	0010_auto_20171113_0958	2020-10-16 07:06:58.863985+00
229	site	0011_auto_20180108_0814	2020-10-16 07:06:58.900948+00
230	page	0001_initial	2020-10-16 07:06:58.925765+00
231	menu	0001_initial	2020-10-16 07:06:59.005559+00
232	menu	0002_auto_20180319_0412	2020-10-16 07:06:59.154553+00
233	site	0012_auto_20180405_0757	2020-10-16 07:06:59.260669+00
234	menu	0003_auto_20180405_0854	2020-10-16 07:06:59.358982+00
235	site	0013_assign_default_menus	2020-10-16 07:06:59.429178+00
236	site	0014_handle_taxes	2020-10-16 07:06:59.478006+00
237	site	0015_sitesettings_handle_stock_by_default	2020-10-16 07:06:59.502633+00
238	site	0016_auto_20180719_0520	2020-10-16 07:06:59.518102+00
239	site	0017_auto_20180803_0528	2020-10-16 07:06:59.59177+00
240	product	0055_auto_20180321_0417	2020-10-16 07:06:59.688453+00
241	product	0056_auto_20180330_0321	2020-10-16 07:06:59.758248+00
242	product	0057_auto_20180403_0852	2020-10-16 07:06:59.7856+00
243	product	0058_auto_20180329_0142	2020-10-16 07:06:59.985581+00
244	product	0059_generate_variant_name_from_attrs	2020-10-16 07:07:00.043324+00
245	product	0060_collection_is_published	2020-10-16 07:07:00.072416+00
246	product	0061_product_taxes	2020-10-16 07:07:00.131523+00
247	product	0062_sortable_models	2020-10-16 07:07:00.326919+00
248	product	0063_required_attr_value_order	2020-10-16 07:07:00.352424+00
249	product	0064_productvariant_handle_stock	2020-10-16 07:07:00.380419+00
250	product	0065_auto_20180719_0520	2020-10-16 07:07:00.410348+00
251	product	0066_auto_20180803_0528	2020-10-16 07:07:01.074191+00
252	site	0018_sitesettings_homepage_collection	2020-10-16 07:07:01.2235+00
253	site	0019_sitesettings_default_weight_unit	2020-10-16 07:07:01.258972+00
254	site	0020_auto_20190301_0336	2020-10-16 07:07:01.276491+00
255	site	0021_auto_20190326_0521	2020-10-16 07:07:01.326528+00
256	site	0022_sitesettings_company_address	2020-10-16 07:07:01.386838+00
257	site	0023_auto_20191007_0835	2020-10-16 07:07:01.452121+00
258	site	0024_sitesettings_customer_set_password_url	2020-10-16 07:07:01.490587+00
259	site	0025_auto_20191024_0552	2020-10-16 07:07:01.562646+00
260	shipping	0009_auto_20180629_1055	2020-10-16 07:07:01.581843+00
261	shipping	0010_auto_20180719_0520	2020-10-16 07:07:01.599093+00
262	shipping	0011_auto_20180802_1238	2020-10-16 07:07:01.616503+00
263	shipping	0012_remove_legacy_shipping_methods	2020-10-16 07:07:01.674648+00
264	shipping	0013_auto_20180822_0721	2020-10-16 07:07:01.99085+00
265	shipping	0014_auto_20180920_0956	2020-10-16 07:07:02.036676+00
266	shipping	0015_auto_20190305_0640	2020-10-16 07:07:02.05903+00
267	shipping	0016_shippingmethod_meta	2020-10-16 07:07:02.086052+00
268	shipping	0017_django_price_2	2020-10-16 07:07:02.161022+00
269	product	0067_remove_product_is_featured	2020-10-16 07:07:02.192308+00
270	product	0068_auto_20180822_0720	2020-10-16 07:07:02.256498+00
271	product	0069_auto_20180912_0326	2020-10-16 07:07:02.27687+00
272	product	0070_auto_20180912_0329	2020-10-16 07:07:02.352956+00
273	product	0071_attributechoicevalue_value	2020-10-16 07:07:02.376854+00
274	product	0072_auto_20180925_1048	2020-10-16 07:07:03.06969+00
275	product	0073_auto_20181010_0729	2020-10-16 07:07:03.333836+00
276	product	0074_auto_20181010_0730	2020-10-16 07:07:03.524706+00
277	product	0075_auto_20181010_0842	2020-10-16 07:07:03.782176+00
278	product	0076_auto_20181012_1146	2020-10-16 07:07:03.802216+00
279	product	0077_generate_versatile_background_images	2020-10-16 07:07:03.811062+00
280	product	0078_auto_20181120_0437	2020-10-16 07:07:03.855413+00
281	product	0079_default_tax_rate_instead_of_empty_field	2020-10-16 07:07:03.923721+00
282	product	0080_collection_published_date	2020-10-16 07:07:03.954074+00
283	product	0080_auto_20181214_0440	2020-10-16 07:07:04.002546+00
284	product	0081_merge_20181215_1659	2020-10-16 07:07:04.014237+00
285	product	0081_auto_20181218_0024	2020-10-16 07:07:04.074746+00
286	product	0082_merge_20181219_1440	2020-10-16 07:07:04.0862+00
287	product	0083_auto_20190104_0443	2020-10-16 07:07:04.128003+00
288	product	0084_auto_20190122_0113	2020-10-16 07:07:04.198695+00
289	product	0085_auto_20190125_0025	2020-10-16 07:07:04.218158+00
290	product	0086_product_publication_date	2020-10-16 07:07:04.283811+00
291	product	0087_auto_20190208_0326	2020-10-16 07:07:04.314969+00
292	product	0088_auto_20190220_1928	2020-10-16 07:07:04.342729+00
293	product	0089_auto_20190225_0252	2020-10-16 07:07:04.758595+00
294	product	0090_auto_20190328_0608	2020-10-16 07:07:04.831853+00
295	product	0091_auto_20190402_0853	2020-10-16 07:07:04.978467+00
296	product	0092_auto_20190507_0309	2020-10-16 07:07:05.195469+00
297	product	0093_auto_20190521_0124	2020-10-16 07:07:05.451501+00
298	product	0094_auto_20190618_0430	2020-10-16 07:07:05.509263+00
299	product	0095_auto_20190618_0842	2020-10-16 07:07:05.606023+00
300	product	0096_auto_20190719_0339	2020-10-16 07:07:05.640457+00
301	product	0097_auto_20190719_0458	2020-10-16 07:07:05.731616+00
302	product	0098_auto_20190719_0733	2020-10-16 07:07:05.807853+00
303	product	0099_auto_20190719_0745	2020-10-16 07:07:05.884235+00
304	product	0096_raw_html_to_json	2020-10-16 07:07:06.076744+00
305	product	0100_merge_20190719_0803	2020-10-16 07:07:06.092095+00
306	product	0101_auto_20190719_0839	2020-10-16 07:07:06.542248+00
307	product	0102_migrate_data_enterprise_grade_attributes	2020-10-16 07:07:06.840545+00
308	product	0103_schema_data_enterprise_grade_attributes	2020-10-16 07:07:08.25904+00
309	product	0104_fix_invalid_attributes_map	2020-10-16 07:07:08.431196+00
310	product	0105_product_minimal_variant_price	2020-10-16 07:07:08.584318+00
311	product	0106_django_prices_2	2020-10-16 07:07:08.744723+00
312	product	0107_attributes_map_to_m2m	2020-10-16 07:07:09.298855+00
313	product	0108_auto_20191003_0422	2020-10-16 07:07:09.497846+00
314	product	0109_auto_20191006_1433	2020-10-16 07:07:09.788446+00
315	product	0110_auto_20191108_0340	2020-10-16 07:07:09.952191+00
316	account	0034_service_account_token	2020-10-16 07:07:10.114963+00
317	account	0035_staffnotificationrecipient	2020-10-16 07:07:10.209383+00
318	account	0036_auto_20191209_0407	2020-10-16 07:07:10.250699+00
319	account	0037_auto_20191219_0944	2020-10-16 07:07:10.284914+00
320	warehouse	0001_initial	2020-10-16 07:07:10.503415+00
321	product	0111_auto_20191209_0437	2020-10-16 07:07:10.620592+00
322	product	0112_auto_20200129_0050	2020-10-16 07:07:10.97688+00
323	product	0113_auto_20200129_0717	2020-10-16 07:07:11.710555+00
324	product	0114_auto_20200129_0815	2020-10-16 07:07:11.947943+00
325	product	0115_auto_20200221_0257	2020-10-16 07:07:12.826605+00
326	giftcard	0001_initial	2020-10-16 07:07:12.913851+00
327	order	0071_order_gift_cards	2020-10-16 07:07:13.008752+00
328	order	0072_django_price_2	2020-10-16 07:07:13.349568+00
329	order	0073_auto_20190829_0249	2020-10-16 07:07:13.505616+00
330	order	0074_auto_20190930_0731	2020-10-16 07:07:13.602859+00
331	order	0075_auto_20191006_1433	2020-10-16 07:07:13.650055+00
332	order	0076_auto_20191018_0554	2020-10-16 07:07:13.72264+00
333	order	0077_auto_20191118_0606	2020-10-16 07:07:13.784305+00
334	order	0078_auto_20200221_0257	2020-10-16 07:07:13.927704+00
335	payment	0003_rename_payment_method_to_payment	2020-10-16 07:07:14.239883+00
336	payment	0004_auto_20181206_0031	2020-10-16 07:07:14.275216+00
337	payment	0005_auto_20190104_0443	2020-10-16 07:07:14.307079+00
338	payment	0006_auto_20190109_0358	2020-10-16 07:07:14.327099+00
339	payment	0007_auto_20190206_0938	2020-10-16 07:07:14.348475+00
340	payment	0007_auto_20190125_0242	2020-10-16 07:07:14.627174+00
341	payment	0008_merge_20190214_0447	2020-10-16 07:07:14.642814+00
342	payment	0009_convert_to_partially_charged_and_partially_refunded	2020-10-16 07:07:14.716288+00
343	payment	0010_auto_20190220_2001	2020-10-16 07:07:14.752924+00
344	checkout	0016_auto_20190112_0506	2020-10-16 07:07:14.790205+00
345	checkout	0017_auto_20190130_0207	2020-10-16 07:07:14.832181+00
346	checkout	0018_auto_20190410_0132	2020-10-16 07:07:15.323519+00
347	checkout	0019_checkout_gift_cards	2020-10-16 07:07:15.406725+00
348	checkout	0020_auto_20190723_0722	2020-10-16 07:07:15.516602+00
349	checkout	0021_django_price_2	2020-10-16 07:07:15.565735+00
350	checkout	0022_auto_20191219_1137	2020-10-16 07:07:15.60655+00
351	checkout	0023_checkout_country	2020-10-16 07:07:15.660039+00
352	checkout	0024_auto_20200120_0154	2020-10-16 07:07:15.707529+00
353	checkout	0025_auto_20200221_0257	2020-10-16 07:07:15.79846+00
354	account	0038_auto_20200123_0034	2020-10-16 07:07:15.908142+00
355	account	0039_auto_20200221_0257	2020-10-16 07:07:16.024392+00
356	core	0001_migrate_metadata	2020-10-16 07:07:17.109059+00
357	account	0040_auto_20200415_0443	2020-10-16 07:07:17.215481+00
358	account	0041_permissions_to_groups	2020-10-16 07:07:17.307723+00
359	account	0040_auto_20200225_0237	2020-10-16 07:07:17.378083+00
360	account	0041_merge_20200421_0529	2020-10-16 07:07:17.387685+00
361	account	0042_merge_20200422_0555	2020-10-16 07:07:17.394949+00
362	account	0043_rename_service_account_to_app	2020-10-16 07:07:18.238678+00
363	webhook	0003_unmount_service_account	2020-10-16 07:07:18.351319+00
364	account	0044_unmount_app_and_app_token	2020-10-16 07:07:18.434399+00
365	account	0045_auto_20200427_0425	2020-10-16 07:07:18.5164+00
366	account	0046_user_jwt_token_key	2020-10-16 07:07:18.561208+00
367	account	0047_auto_20200810_1415	2020-10-16 07:07:18.65297+00
368	app	0001_initial	2020-10-16 07:07:18.930834+00
369	app	0002_auto_20200702_0945	2020-10-16 07:07:19.187536+00
370	app	0003_auto_20200810_1415	2020-10-16 07:07:19.243029+00
371	auth	0012_alter_user_first_name_max_length	2020-10-16 07:07:19.265083+00
372	checkout	0026_auto_20200709_1102	2020-10-16 07:07:19.308139+00
373	checkout	0027_auto_20200810_1415	2020-10-16 07:07:19.416075+00
374	checkout	0028_auto_20200824_1019	2020-10-16 07:07:19.507578+00
375	checkout	0029_auto_20200904_0529	2020-10-16 07:07:19.573212+00
376	csv	0001_initial	2020-10-16 07:07:19.986728+00
377	csv	0002_exportfile_message	2020-10-16 07:07:20.071592+00
378	csv	0003_auto_20200810_1415	2020-10-16 07:07:20.115298+00
379	discount	0004_auto_20170206_0407	2020-10-16 07:07:20.620505+00
380	discount	0005_auto_20170919_0839	2020-10-16 07:07:20.673849+00
381	discount	0006_auto_20171129_1004	2020-10-16 07:07:20.72085+00
382	discount	0007_auto_20180108_0814	2020-10-16 07:07:21.60053+00
383	discount	0008_sale_collections	2020-10-16 07:07:21.695341+00
384	discount	0009_auto_20180719_0520	2020-10-16 07:07:21.770817+00
385	discount	0010_auto_20180724_1251	2020-10-16 07:07:22.358655+00
386	discount	0011_auto_20180803_0528	2020-10-16 07:07:22.526212+00
387	discount	0012_auto_20190329_0836	2020-10-16 07:07:22.637122+00
388	discount	0013_auto_20190618_0733	2020-10-16 07:07:22.797278+00
389	discount	0014_auto_20190701_0402	2020-10-16 07:07:22.911779+00
390	discount	0015_voucher_min_quantity_of_products	2020-10-16 07:07:22.953805+00
391	discount	0016_auto_20190716_0330	2020-10-16 07:07:23.386444+00
392	discount	0017_django_price_2	2020-10-16 07:07:23.479089+00
393	discount	0018_auto_20190827_0315	2020-10-16 07:07:23.603717+00
394	discount	0019_auto_20200217_0350	2020-10-16 07:07:23.713553+00
395	discount	0020_auto_20200709_1102	2020-10-16 07:07:23.765508+00
396	discount	0021_auto_20200902_1249	2020-10-16 07:07:23.896181+00
397	django_prices_openexchangerates	0001_initial	2020-10-16 07:07:23.919434+00
398	django_prices_openexchangerates	0002_auto_20160329_0702	2020-10-16 07:07:23.949839+00
399	django_prices_openexchangerates	0003_auto_20161018_0707	2020-10-16 07:07:23.980264+00
400	django_prices_openexchangerates	0004_auto_20170316_0944	2020-10-16 07:07:23.998583+00
401	django_prices_openexchangerates	0005_auto_20190124_1008	2020-10-16 07:07:24.014919+00
402	django_prices_vatlayer	0001_initial	2020-10-16 07:07:24.037057+00
403	django_prices_vatlayer	0002_ratetypes	2020-10-16 07:07:24.058957+00
404	django_prices_vatlayer	0003_auto_20180316_1053	2020-10-16 07:07:24.088037+00
405	django_ses	0001_initial	2020-10-16 07:07:24.102675+00
406	giftcard	0002_auto_20190814_0413	2020-10-16 07:07:24.307359+00
407	giftcard	0003_auto_20200217_0350	2020-10-16 07:07:24.35068+00
408	giftcard	0004_auto_20200902_1249	2020-10-16 07:07:24.536343+00
409	warehouse	0002_auto_20200123_0036	2020-10-16 07:07:24.632573+00
410	warehouse	0003_warehouse_slug	2020-10-16 07:07:24.800626+00
411	warehouse	0004_auto_20200129_0717	2020-10-16 07:07:24.864599+00
412	warehouse	0005_auto_20200204_0722	2020-10-16 07:07:24.97815+00
413	warehouse	0006_auto_20200228_0519	2020-10-16 07:07:25.362178+00
414	order	0079_auto_20200304_0752	2020-10-16 07:07:25.476204+00
415	order	0080_invoice	2020-10-16 07:07:25.570794+00
416	order	0081_auto_20200406_0456	2020-10-16 07:07:25.666841+00
417	warehouse	0007_auto_20200406_0341	2020-10-16 07:07:25.890716+00
418	order	0082_fulfillmentline_stock	2020-10-16 07:07:26.004976+00
419	order	0079_auto_20200225_0237	2020-10-16 07:07:26.051395+00
420	order	0081_merge_20200309_0952	2020-10-16 07:07:26.06085+00
421	order	0083_merge_20200421_0529	2020-10-16 07:07:26.068597+00
422	order	0084_auto_20200522_0522	2020-10-16 07:07:26.116088+00
423	order	0085_delete_invoice	2020-10-16 07:07:26.135496+00
424	invoice	0001_initial	2020-10-16 07:07:26.322505+00
425	invoice	0002_invoice_message	2020-10-16 07:07:26.398477+00
426	invoice	0003_auto_20200713_1311	2020-10-16 07:07:26.447321+00
427	invoice	0004_auto_20200810_1415	2020-10-16 07:07:26.556586+00
428	menu	0004_sort_order_index	2020-10-16 07:07:26.59789+00
429	menu	0005_auto_20180719_0520	2020-10-16 07:07:26.612665+00
430	menu	0006_auto_20180803_0528	2020-10-16 07:07:26.733902+00
431	menu	0007_auto_20180807_0547	2020-10-16 07:07:26.857769+00
432	menu	0008_menu_json_content_new	2020-10-16 07:07:27.259377+00
433	menu	0009_remove_menu_json_content	2020-10-16 07:07:27.285354+00
434	menu	0010_auto_20180913_0841	2020-10-16 07:07:27.305008+00
435	menu	0011_auto_20181204_0004	2020-10-16 07:07:27.320008+00
436	menu	0012_auto_20190104_0443	2020-10-16 07:07:27.334408+00
437	menu	0013_auto_20190507_0309	2020-10-16 07:07:27.443301+00
438	menu	0014_auto_20190523_0759	2020-10-16 07:07:27.48648+00
439	menu	0015_auto_20190725_0811	2020-10-16 07:07:27.530474+00
440	menu	0016_auto_20200217_0350	2020-10-16 07:07:27.551519+00
441	menu	0017_remove_menu_json_content	2020-10-16 07:07:27.574403+00
442	menu	0018_auto_20200709_1102	2020-10-16 07:07:27.621168+00
443	multitenancy	0001_initial	2020-10-16 07:07:27.718768+00
444	order	0086_auto_20200716_1226	2020-10-16 07:07:27.767619+00
445	order	0087_auto_20200810_1415	2020-10-16 07:07:27.968536+00
446	order	0088_auto_20200812_1101	2020-10-16 07:07:28.021554+00
447	order	0089_auto_20200902_1249	2020-10-16 07:07:28.480037+00
448	page	0002_auto_20180321_0417	2020-10-16 07:07:28.510997+00
449	page	0003_auto_20180719_0520	2020-10-16 07:07:28.524252+00
450	page	0004_auto_20180803_0528	2020-10-16 07:07:28.628332+00
451	page	0005_auto_20190208_0456	2020-10-16 07:07:28.668493+00
452	page	0006_auto_20190220_1928	2020-10-16 07:07:28.688787+00
453	page	0007_auto_20190225_0252	2020-10-16 07:07:28.742306+00
454	page	0008_raw_html_to_json	2020-10-16 07:07:28.950219+00
455	page	0009_auto_20191108_0402	2020-10-16 07:07:28.972405+00
456	page	0010_auto_20200129_0717	2020-10-16 07:07:29.005098+00
457	page	0011_auto_20200217_0350	2020-10-16 07:07:29.023681+00
458	page	0012_auto_20200709_1102	2020-10-16 07:07:29.040377+00
459	payment	0011_auto_20190516_0901	2020-10-16 07:07:29.066749+00
460	payment	0012_transaction_customer_id	2020-10-16 07:07:29.096131+00
461	payment	0013_auto_20190813_0735	2020-10-16 07:07:29.382566+00
462	payment	0014_django_price_2	2020-10-16 07:07:29.471887+00
463	payment	0015_auto_20200203_1116	2020-10-16 07:07:29.549142+00
464	payment	0016_auto_20200423_0314	2020-10-16 07:07:29.654194+00
465	payment	0017_payment_payment_method_type	2020-10-16 07:07:29.715832+00
466	payment	0018_auto_20200810_1415	2020-10-16 07:07:29.746704+00
467	payment	0019_auto_20200812_1101	2020-10-16 07:07:29.900522+00
468	payment	0020_auto_20200902_1249	2020-10-16 07:07:30.041143+00
469	payment	0021_transaction_searchable_key	2020-10-16 07:07:30.072301+00
470	plugins	0003_auto_20200429_0142	2020-10-16 07:07:30.181195+00
471	plugins	0004_drop_support_for_env_vatlayer_access_key	2020-10-16 07:07:30.281987+00
472	plugins	0005_auto_20200810_1415	2020-10-16 07:07:30.299113+00
473	plugins	0006_auto_20200909_1253	2020-10-16 07:07:30.314947+00
474	product	0116_auto_20200225_0237	2020-10-16 07:07:30.362682+00
475	product	0117_auto_20200423_0737	2020-10-16 07:07:30.402041+00
476	product	0118_populate_product_variant_price	2020-10-16 07:07:30.768305+00
477	product	0119_auto_20200709_1102	2020-10-16 07:07:30.882502+00
478	product	0120_auto_20200714_0539	2020-10-16 07:07:31.569373+00
479	product	0121_auto_20200810_1415	2020-10-16 07:07:32.891907+00
480	product	0122_auto_20200828_1135	2020-10-16 07:07:33.061278+00
481	product	0123_auto_20200904_1251	2020-10-16 07:07:33.192863+00
482	product	0124_auto_20200909_0904	2020-10-16 07:07:33.497205+00
483	product	0125_auto_20200916_1511	2020-10-16 07:07:33.573391+00
484	product	0126_product_default_variant	2020-10-16 07:07:33.768478+00
485	product	0127_auto_20201001_0933	2020-10-16 07:07:33.875497+00
486	shipping	0018_default_zones_countries	2020-10-16 07:07:33.978007+00
487	shipping	0019_remove_shippingmethod_meta	2020-10-16 07:07:34.278462+00
488	shipping	0020_auto_20200902_1249	2020-10-16 07:07:34.379124+00
489	tenants	0001_initial	2020-10-16 07:07:34.398029+00
490	tenants	0002_remove_tenant_name	2020-10-16 07:07:34.415043+00
491	tenants	0003_tenant_jwt_secret_key	2020-10-16 07:07:34.434579+00
492	tests	0001_initial	2020-10-16 07:07:34.45716+00
493	warehouse	0008_auto_20200430_0239	2020-10-16 07:07:34.566599+00
494	warehouse	0009_remove_invalid_allocation	2020-10-16 07:07:34.672787+00
495	warehouse	0010_auto_20200709_1102	2020-10-16 07:07:34.718206+00
496	warehouse	0011_auto_20200714_0539	2020-10-16 07:07:34.760041+00
497	webhook	0004_mount_app	2020-10-16 07:07:34.857655+00
498	webhook	0005_drop_manage_webhooks_permission	2020-10-16 07:07:34.972297+00
499	webhook	0006_auto_20200731_1440	2020-10-16 07:07:35.000294+00
500	wishlist	0001_initial	2020-10-16 07:07:35.20072+00
501	account	0008_auto_20161115_1011	2020-10-16 07:07:35.275778+00
502	account	0010_auto_20170919_0839	2020-10-16 07:07:35.284868+00
503	account	0006_auto_20160829_0819	2020-10-16 07:07:35.292099+00
504	account	0013_auto_20171120_0521	2020-10-16 07:07:35.299973+00
505	account	0004_auto_20160114_0419	2020-10-16 07:07:35.308254+00
506	account	0002_auto_20150907_0602	2020-10-16 07:07:35.316877+00
507	account	0016_auto_20180108_0814	2020-10-16 07:07:35.324133+00
508	account	0001_initial	2020-10-16 07:07:35.331442+00
509	account	0014_auto_20171129_1004	2020-10-16 07:07:35.338322+00
510	account	0015_auto_20171213_0734	2020-10-16 07:07:35.347008+00
511	account	0009_auto_20170206_0407	2020-10-16 07:07:35.35532+00
512	account	0011_auto_20171110_0552	2020-10-16 07:07:35.36316+00
513	account	0012_auto_20171117_0846	2020-10-16 07:07:35.371035+00
514	account	0007_auto_20161115_0940	2020-10-16 07:07:35.378998+00
515	account	0003_auto_20151104_1102	2020-10-16 07:07:35.38768+00
516	account	0005_auto_20160205_0651	2020-10-16 07:07:35.396456+00
517	checkout	0001_auto_20170113_0435	2020-10-16 07:07:35.404464+00
518	checkout	0002_auto_20170206_0407	2020-10-16 07:07:35.411405+00
519	checkout	0002_auto_20161014_1221	2020-10-16 07:07:35.419734+00
520	checkout	0001_initial	2020-10-16 07:07:35.426659+00
521	checkout	0003_auto_20170906_0556	2020-10-16 07:07:35.434759+00
522	checkout	0005_auto_20180108_0814	2020-10-16 07:07:35.442121+00
523	checkout	fix_empty_data_in_lines	2020-10-16 07:07:35.450265+00
524	checkout	0004_auto_20171129_1004	2020-10-16 07:07:35.45781+00
525	checkout	0006_auto_20180221_0825	2020-10-16 07:07:35.465329+00
\.


--
-- Data for Name: django_prices_openexchangerates_conversionrate; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."django_prices_openexchangerates_conversionrate" ("id", "to_currency", "rate", "modified_at") FROM stdin;
\.


--
-- Data for Name: django_prices_vatlayer_ratetypes; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."django_prices_vatlayer_ratetypes" ("id", "types") FROM stdin;
\.


--
-- Data for Name: django_prices_vatlayer_vat; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."django_prices_vatlayer_vat" ("id", "country_code", "data") FROM stdin;
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."django_site" ("id", "domain", "name") FROM stdin;
1	mirumee.com	Saleor e-commerce
\.


--
-- Data for Name: giftcard_giftcard; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."giftcard_giftcard" ("id", "code", "created", "start_date", "end_date", "last_used_on", "is_active", "initial_balance_amount", "current_balance_amount", "user_id", "currency") FROM stdin;
\.


--
-- Data for Name: invoice_invoice; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."invoice_invoice" ("id", "private_metadata", "metadata", "status", "created_at", "updated_at", "number", "created", "external_url", "invoice_file", "order_id", "message") FROM stdin;
\.


--
-- Data for Name: invoice_invoiceevent; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."invoice_invoiceevent" ("id", "date", "type", "parameters", "invoice_id", "order_id", "user_id") FROM stdin;
\.


--
-- Data for Name: menu_menu; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."menu_menu" ("id", "name") FROM stdin;
1	navbar
2	footer
\.


--
-- Data for Name: menu_menuitem; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."menu_menuitem" ("id", "name", "sort_order", "url", "lft", "rght", "tree_id", "level", "category_id", "collection_id", "menu_id", "page_id", "parent_id") FROM stdin;
\.


--
-- Data for Name: menu_menuitemtranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."menu_menuitemtranslation" ("id", "language_code", "name", "menu_item_id") FROM stdin;
\.


--
-- Data for Name: order_fulfillment; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."order_fulfillment" ("id", "tracking_number", "created", "order_id", "fulfillment_order", "status", "metadata", "private_metadata") FROM stdin;
\.


--
-- Data for Name: order_fulfillmentline; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."order_fulfillmentline" ("id", "order_line_id", "quantity", "fulfillment_id", "stock_id") FROM stdin;
\.


--
-- Data for Name: order_order; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."order_order" ("id", "created", "tracking_client_id", "user_email", "token", "billing_address_id", "shipping_address_id", "user_id", "total_net_amount", "discount_amount", "discount_name", "voucher_id", "language_code", "shipping_price_gross_amount", "total_gross_amount", "shipping_price_net_amount", "status", "shipping_method_name", "shipping_method_id", "display_gross_prices", "translated_discount_name", "customer_note", "weight", "checkout_token", "currency", "metadata", "private_metadata") FROM stdin;
\.


--
-- Data for Name: order_order_gift_cards; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."order_order_gift_cards" ("id", "order_id", "giftcard_id") FROM stdin;
\.


--
-- Data for Name: order_orderevent; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."order_orderevent" ("id", "date", "type", "order_id", "user_id", "parameters") FROM stdin;
\.


--
-- Data for Name: order_orderline; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."order_orderline" ("id", "product_name", "product_sku", "quantity", "unit_price_net_amount", "unit_price_gross_amount", "is_shipping_required", "order_id", "quantity_fulfilled", "variant_id", "tax_rate", "translated_product_name", "currency", "translated_variant_name", "variant_name") FROM stdin;
\.


--
-- Data for Name: page_page; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."page_page" ("id", "slug", "title", "content", "created", "is_published", "publication_date", "seo_description", "seo_title", "content_json") FROM stdin;
\.


--
-- Data for Name: page_pagetranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."page_pagetranslation" ("id", "seo_title", "seo_description", "language_code", "title", "content", "page_id", "content_json") FROM stdin;
\.


--
-- Data for Name: payment_payment; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."payment_payment" ("id", "gateway", "is_active", "created", "modified", "charge_status", "billing_first_name", "billing_last_name", "billing_company_name", "billing_address_1", "billing_address_2", "billing_city", "billing_city_area", "billing_postal_code", "billing_country_code", "billing_country_area", "billing_email", "customer_ip_address", "cc_brand", "cc_exp_month", "cc_exp_year", "cc_first_digits", "cc_last_digits", "extra_data", "token", "currency", "total", "captured_amount", "checkout_id", "order_id", "to_confirm", "payment_method_type", "return_url") FROM stdin;
\.


--
-- Data for Name: payment_transaction; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."payment_transaction" ("id", "created", "token", "kind", "is_success", "error", "currency", "amount", "gateway_response", "payment_id", "customer_id", "action_required", "action_required_data", "already_processed", "searchable_key") FROM stdin;
\.


--
-- Data for Name: plugins_pluginconfiguration; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."plugins_pluginconfiguration" ("id", "name", "description", "active", "configuration", "identifier") FROM stdin;
\.


--
-- Data for Name: product_assignedproductattribute; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_assignedproductattribute" ("id", "product_id", "assignment_id") FROM stdin;
\.


--
-- Data for Name: product_assignedproductattribute_values; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_assignedproductattribute_values" ("id", "assignedproductattribute_id", "attributevalue_id") FROM stdin;
\.


--
-- Data for Name: product_assignedvariantattribute; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_assignedvariantattribute" ("id", "variant_id", "assignment_id") FROM stdin;
\.


--
-- Data for Name: product_assignedvariantattribute_values; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_assignedvariantattribute_values" ("id", "assignedvariantattribute_id", "attributevalue_id") FROM stdin;
\.


--
-- Data for Name: product_attribute; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_attribute" ("id", "slug", "name", "metadata", "private_metadata", "input_type", "available_in_grid", "visible_in_storefront", "filterable_in_dashboard", "filterable_in_storefront", "value_required", "storefront_search_position", "is_variant_only") FROM stdin;
\.


--
-- Data for Name: product_attributeproduct; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_attributeproduct" ("id", "attribute_id", "product_type_id", "sort_order") FROM stdin;
\.


--
-- Data for Name: product_attributetranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_attributetranslation" ("id", "language_code", "name", "attribute_id") FROM stdin;
\.


--
-- Data for Name: product_attributevalue; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_attributevalue" ("id", "name", "attribute_id", "slug", "sort_order", "value") FROM stdin;
\.


--
-- Data for Name: product_attributevaluetranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_attributevaluetranslation" ("id", "language_code", "name", "attribute_value_id") FROM stdin;
\.


--
-- Data for Name: product_attributevariant; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_attributevariant" ("id", "attribute_id", "product_type_id", "sort_order") FROM stdin;
\.


--
-- Data for Name: product_category; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_category" ("id", "name", "slug", "description", "lft", "rght", "tree_id", "level", "parent_id", "background_image", "seo_description", "seo_title", "background_image_alt", "description_json", "metadata", "private_metadata") FROM stdin;
\.


--
-- Data for Name: product_categorytranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_categorytranslation" ("id", "seo_title", "seo_description", "language_code", "name", "description", "category_id", "description_json") FROM stdin;
\.


--
-- Data for Name: product_collection; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_collection" ("id", "name", "slug", "background_image", "seo_description", "seo_title", "is_published", "description", "publication_date", "background_image_alt", "description_json", "metadata", "private_metadata") FROM stdin;
\.


--
-- Data for Name: product_collectionproduct; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_collectionproduct" ("id", "collection_id", "product_id", "sort_order") FROM stdin;
\.


--
-- Data for Name: product_collectiontranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_collectiontranslation" ("id", "seo_title", "seo_description", "language_code", "name", "collection_id", "description", "description_json") FROM stdin;
\.


--
-- Data for Name: product_digitalcontent; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_digitalcontent" ("id", "use_default_settings", "automatic_fulfillment", "content_type", "content_file", "max_downloads", "url_valid_days", "product_variant_id", "metadata", "private_metadata") FROM stdin;
\.


--
-- Data for Name: product_digitalcontenturl; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_digitalcontenturl" ("id", "token", "created", "download_num", "content_id", "line_id") FROM stdin;
\.


--
-- Data for Name: product_product; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_product" ("id", "name", "description", "publication_date", "updated_at", "product_type_id", "is_published", "category_id", "seo_description", "seo_title", "charge_taxes", "weight", "description_json", "metadata", "private_metadata", "minimal_variant_price_amount", "currency", "slug", "available_for_purchase", "visible_in_listings", "default_variant_id") FROM stdin;
\.


--
-- Data for Name: product_productimage; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_productimage" ("id", "image", "ppoi", "alt", "sort_order", "product_id") FROM stdin;
\.


--
-- Data for Name: product_producttranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_producttranslation" ("id", "seo_title", "seo_description", "language_code", "name", "description", "product_id", "description_json") FROM stdin;
\.


--
-- Data for Name: product_producttype; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_producttype" ("id", "name", "has_variants", "is_shipping_required", "weight", "is_digital", "metadata", "private_metadata", "slug") FROM stdin;
\.


--
-- Data for Name: product_productvariant; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_productvariant" ("id", "sku", "name", "product_id", "cost_price_amount", "track_inventory", "weight", "metadata", "private_metadata", "currency", "price_amount", "sort_order") FROM stdin;
\.


--
-- Data for Name: product_productvarianttranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_productvarianttranslation" ("id", "language_code", "name", "product_variant_id") FROM stdin;
\.


--
-- Data for Name: product_variantimage; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."product_variantimage" ("id", "image_id", "variant_id") FROM stdin;
\.


--
-- Data for Name: shipping_shippingmethod; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."shipping_shippingmethod" ("id", "name", "maximum_order_price_amount", "maximum_order_weight", "minimum_order_price_amount", "minimum_order_weight", "price_amount", "type", "shipping_zone_id", "currency") FROM stdin;
\.


--
-- Data for Name: shipping_shippingmethodtranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."shipping_shippingmethodtranslation" ("id", "language_code", "name", "shipping_method_id") FROM stdin;
\.


--
-- Data for Name: shipping_shippingzone; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."shipping_shippingzone" ("id", "name", "countries", "default") FROM stdin;
\.


--
-- Data for Name: site_authorizationkey; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."site_authorizationkey" ("id", "name", "key", "password", "site_settings_id") FROM stdin;
\.


--
-- Data for Name: site_sitesettings; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."site_sitesettings" ("id", "header_text", "description", "site_id", "bottom_menu_id", "top_menu_id", "display_gross_prices", "include_taxes_in_prices", "charge_taxes_on_shipping", "track_inventory_by_default", "homepage_collection_id", "default_weight_unit", "automatic_fulfillment_digital_products", "default_digital_max_downloads", "default_digital_url_valid_days", "company_address_id", "default_mail_sender_address", "default_mail_sender_name", "customer_set_password_url") FROM stdin;
1	Test Saleor - a sample shop!		1	2	1	t	t	t	t	\N	kg	f	\N	\N	\N	\N		\N
\.


--
-- Data for Name: site_sitesettingstranslation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."site_sitesettingstranslation" ("id", "language_code", "header_text", "description", "site_settings_id") FROM stdin;
\.


--
-- Data for Name: tests_book; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."tests_book" ("id", "name") FROM stdin;
\.


--
-- Data for Name: warehouse_allocation; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."warehouse_allocation" ("id", "quantity_allocated", "order_line_id", "stock_id") FROM stdin;
\.


--
-- Data for Name: warehouse_stock; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."warehouse_stock" ("id", "quantity", "product_variant_id", "warehouse_id") FROM stdin;
\.


--
-- Data for Name: warehouse_warehouse; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."warehouse_warehouse" ("id", "name", "company_name", "email", "address_id", "slug") FROM stdin;
\.


--
-- Data for Name: warehouse_warehouse_shipping_zones; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."warehouse_warehouse_shipping_zones" ("id", "warehouse_id", "shippingzone_id") FROM stdin;
\.


--
-- Data for Name: webhook_webhook; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."webhook_webhook" ("id", "target_url", "is_active", "secret_key", "app_id", "name") FROM stdin;
\.


--
-- Data for Name: webhook_webhookevent; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."webhook_webhookevent" ("id", "event_type", "webhook_id") FROM stdin;
\.


--
-- Data for Name: wishlist_wishlist; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."wishlist_wishlist" ("id", "created_at", "token", "user_id") FROM stdin;
\.


--
-- Data for Name: wishlist_wishlistitem; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."wishlist_wishlistitem" ("id", "created_at", "product_id", "wishlist_id") FROM stdin;
\.


--
-- Data for Name: wishlist_wishlistitem_variants; Type: TABLE DATA; Schema: mirumee; Owner: saleor
--

COPY "mirumee"."wishlist_wishlistitem_variants" ("id", "wishlistitem_id", "productvariant_id") FROM stdin;
\.


--
-- Name: account_customerevent_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."account_customerevent_id_seq"', 1, false);


--
-- Name: account_customernote_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."account_customernote_id_seq"', 1, false);


--
-- Name: account_serviceaccount_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."account_serviceaccount_id_seq"', 1, false);


--
-- Name: account_serviceaccount_permissions_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."account_serviceaccount_permissions_id_seq"', 1, false);


--
-- Name: account_serviceaccounttoken_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."account_serviceaccounttoken_id_seq"', 1, false);


--
-- Name: account_staffnotificationrecipient_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."account_staffnotificationrecipient_id_seq"', 1, false);


--
-- Name: app_appinstallation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."app_appinstallation_id_seq"', 1, false);


--
-- Name: app_appinstallation_permissions_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."app_appinstallation_permissions_id_seq"', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."auth_group_id_seq"', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."auth_group_permissions_id_seq"', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."auth_permission_id_seq"', 326, true);


--
-- Name: cart_cartline_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."cart_cartline_id_seq"', 1, false);


--
-- Name: checkout_checkout_gift_cards_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."checkout_checkout_gift_cards_id_seq"', 1, false);


--
-- Name: csv_exportevent_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."csv_exportevent_id_seq"', 1, false);


--
-- Name: csv_exportfile_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."csv_exportfile_id_seq"', 1, false);


--
-- Name: discount_sale_categories_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_sale_categories_id_seq"', 1, false);


--
-- Name: discount_sale_collections_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_sale_collections_id_seq"', 1, false);


--
-- Name: discount_sale_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_sale_id_seq"', 1, false);


--
-- Name: discount_sale_products_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_sale_products_id_seq"', 1, false);


--
-- Name: discount_saletranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_saletranslation_id_seq"', 1, false);


--
-- Name: discount_voucher_categories_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_voucher_categories_id_seq"', 1, false);


--
-- Name: discount_voucher_collections_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_voucher_collections_id_seq"', 1, false);


--
-- Name: discount_voucher_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_voucher_id_seq"', 1, false);


--
-- Name: discount_voucher_products_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_voucher_products_id_seq"', 1, false);


--
-- Name: discount_vouchercustomer_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_vouchercustomer_id_seq"', 1, false);


--
-- Name: discount_vouchertranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."discount_vouchertranslation_id_seq"', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."django_content_type_id_seq"', 78, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."django_migrations_id_seq"', 525, true);


--
-- Name: django_prices_openexchangerates_conversionrate_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."django_prices_openexchangerates_conversionrate_id_seq"', 1, false);


--
-- Name: django_prices_vatlayer_ratetypes_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."django_prices_vatlayer_ratetypes_id_seq"', 1, false);


--
-- Name: django_prices_vatlayer_vat_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."django_prices_vatlayer_vat_id_seq"', 1, false);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."django_site_id_seq"', 1, true);


--
-- Name: giftcard_giftcard_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."giftcard_giftcard_id_seq"', 1, false);


--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."invoice_invoice_id_seq"', 1, false);


--
-- Name: invoice_invoiceevent_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."invoice_invoiceevent_id_seq"', 1, false);


--
-- Name: menu_menu_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."menu_menu_id_seq"', 2, true);


--
-- Name: menu_menuitem_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."menu_menuitem_id_seq"', 1, false);


--
-- Name: menu_menuitemtranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."menu_menuitemtranslation_id_seq"', 1, false);


--
-- Name: order_fulfillment_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."order_fulfillment_id_seq"', 1, false);


--
-- Name: order_fulfillmentline_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."order_fulfillmentline_id_seq"', 1, false);


--
-- Name: order_order_gift_cards_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."order_order_gift_cards_id_seq"', 1, false);


--
-- Name: order_order_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."order_order_id_seq"', 1, false);


--
-- Name: order_ordereditem_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."order_ordereditem_id_seq"', 1, false);


--
-- Name: order_orderevent_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."order_orderevent_id_seq"', 1, false);


--
-- Name: page_page_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."page_page_id_seq"', 1, false);


--
-- Name: page_pagetranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."page_pagetranslation_id_seq"', 1, false);


--
-- Name: payment_paymentmethod_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."payment_paymentmethod_id_seq"', 1, false);


--
-- Name: payment_transaction_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."payment_transaction_id_seq"', 1, false);


--
-- Name: plugins_pluginconfiguration_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."plugins_pluginconfiguration_id_seq"', 1, false);


--
-- Name: product_assignedproductattribute_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_assignedproductattribute_id_seq"', 1, false);


--
-- Name: product_assignedproductattribute_values_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_assignedproductattribute_values_id_seq"', 1, false);


--
-- Name: product_assignedvariantattribute_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_assignedvariantattribute_id_seq"', 1, false);


--
-- Name: product_assignedvariantattribute_values_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_assignedvariantattribute_values_id_seq"', 1, false);


--
-- Name: product_attributechoicevalue_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_attributechoicevalue_id_seq"', 1, false);


--
-- Name: product_attributechoicevaluetranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_attributechoicevaluetranslation_id_seq"', 1, false);


--
-- Name: product_attributeproduct_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_attributeproduct_id_seq"', 1, false);


--
-- Name: product_attributevariant_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_attributevariant_id_seq"', 1, false);


--
-- Name: product_category_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_category_id_seq"', 1, false);


--
-- Name: product_categorytranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_categorytranslation_id_seq"', 1, false);


--
-- Name: product_collection_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_collection_id_seq"', 1, false);


--
-- Name: product_collection_products_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_collection_products_id_seq"', 1, false);


--
-- Name: product_collectiontranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_collectiontranslation_id_seq"', 1, false);


--
-- Name: product_digitalcontent_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_digitalcontent_id_seq"', 1, false);


--
-- Name: product_digitalcontenturl_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_digitalcontenturl_id_seq"', 1, false);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_product_id_seq"', 1, false);


--
-- Name: product_productattribute_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_productattribute_id_seq"', 1, false);


--
-- Name: product_productattributetranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_productattributetranslation_id_seq"', 1, false);


--
-- Name: product_productclass_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_productclass_id_seq"', 1, false);


--
-- Name: product_productimage_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_productimage_id_seq"', 1, false);


--
-- Name: product_producttranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_producttranslation_id_seq"', 1, false);


--
-- Name: product_productvariant_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_productvariant_id_seq"', 1, false);


--
-- Name: product_productvarianttranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_productvarianttranslation_id_seq"', 1, false);


--
-- Name: product_variantimage_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."product_variantimage_id_seq"', 1, false);


--
-- Name: shipping_shippingmethod_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."shipping_shippingmethod_id_seq"', 1, false);


--
-- Name: shipping_shippingmethodtranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."shipping_shippingmethodtranslation_id_seq"', 1, false);


--
-- Name: shipping_shippingzone_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."shipping_shippingzone_id_seq"', 1, false);


--
-- Name: site_authorizationkey_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."site_authorizationkey_id_seq"', 1, false);


--
-- Name: site_sitesettings_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."site_sitesettings_id_seq"', 1, true);


--
-- Name: site_sitesettingstranslation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."site_sitesettingstranslation_id_seq"', 1, false);


--
-- Name: tests_book_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."tests_book_id_seq"', 1, false);


--
-- Name: userprofile_address_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."userprofile_address_id_seq"', 1, false);


--
-- Name: userprofile_user_addresses_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."userprofile_user_addresses_id_seq"', 1, false);


--
-- Name: userprofile_user_groups_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."userprofile_user_groups_id_seq"', 1, false);


--
-- Name: userprofile_user_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."userprofile_user_id_seq"', 1, false);


--
-- Name: userprofile_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."userprofile_user_user_permissions_id_seq"', 1, false);


--
-- Name: warehouse_allocation_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."warehouse_allocation_id_seq"', 1, false);


--
-- Name: warehouse_stock_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."warehouse_stock_id_seq"', 1, false);


--
-- Name: warehouse_warehouse_shipping_zones_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."warehouse_warehouse_shipping_zones_id_seq"', 1, false);


--
-- Name: webhook_webhook_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."webhook_webhook_id_seq"', 1, false);


--
-- Name: webhook_webhookevent_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."webhook_webhookevent_id_seq"', 1, false);


--
-- Name: wishlist_wishlist_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."wishlist_wishlist_id_seq"', 1, false);


--
-- Name: wishlist_wishlistitem_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."wishlist_wishlistitem_id_seq"', 1, false);


--
-- Name: wishlist_wishlistitem_variants_id_seq; Type: SEQUENCE SET; Schema: mirumee; Owner: saleor
--

SELECT pg_catalog.setval('"mirumee"."wishlist_wishlistitem_variants_id_seq"', 1, false);


--
-- Name: account_customerevent account_customerevent_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customerevent"
    ADD CONSTRAINT "account_customerevent_pkey" PRIMARY KEY ("id");


--
-- Name: account_customernote account_customernote_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customernote"
    ADD CONSTRAINT "account_customernote_pkey" PRIMARY KEY ("id");


--
-- Name: app_app_permissions account_serviceaccount_p_serviceaccount_id_permis_1686b2ab_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_app_permissions"
    ADD CONSTRAINT "account_serviceaccount_p_serviceaccount_id_permis_1686b2ab_uniq" UNIQUE ("app_id", "permission_id");


--
-- Name: app_app_permissions account_serviceaccount_permissions_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_app_permissions"
    ADD CONSTRAINT "account_serviceaccount_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: app_app account_serviceaccount_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_app"
    ADD CONSTRAINT "account_serviceaccount_pkey" PRIMARY KEY ("id");


--
-- Name: app_apptoken account_serviceaccounttoken_auth_token_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_apptoken"
    ADD CONSTRAINT "account_serviceaccounttoken_auth_token_key" UNIQUE ("auth_token");


--
-- Name: app_apptoken account_serviceaccounttoken_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_apptoken"
    ADD CONSTRAINT "account_serviceaccounttoken_pkey" PRIMARY KEY ("id");


--
-- Name: account_staffnotificationrecipient account_staffnotificationrecipient_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_staffnotificationrecipient"
    ADD CONSTRAINT "account_staffnotificationrecipient_pkey" PRIMARY KEY ("id");


--
-- Name: account_staffnotificationrecipient account_staffnotificationrecipient_staff_email_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_staffnotificationrecipient"
    ADD CONSTRAINT "account_staffnotificationrecipient_staff_email_key" UNIQUE ("staff_email");


--
-- Name: account_staffnotificationrecipient account_staffnotificationrecipient_user_id_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_staffnotificationrecipient"
    ADD CONSTRAINT "account_staffnotificationrecipient_user_id_key" UNIQUE ("user_id");


--
-- Name: app_appinstallation_permissions app_appinstallation_perm_appinstallation_id_permi_7b7e0448_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_appinstallation_permissions"
    ADD CONSTRAINT "app_appinstallation_perm_appinstallation_id_permi_7b7e0448_uniq" UNIQUE ("appinstallation_id", "permission_id");


--
-- Name: app_appinstallation_permissions app_appinstallation_permissions_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_appinstallation_permissions"
    ADD CONSTRAINT "app_appinstallation_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: app_appinstallation app_appinstallation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_appinstallation"
    ADD CONSTRAINT "app_appinstallation_pkey" PRIMARY KEY ("id");


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group"
    ADD CONSTRAINT "auth_group_name_key" UNIQUE ("name");


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissions_group_id_permission_id_0cd325b0_uniq" UNIQUE ("group_id", "permission_id");


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group"
    ADD CONSTRAINT "auth_group_pkey" PRIMARY KEY ("id");


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_permission"
    ADD CONSTRAINT "auth_permission_content_type_id_codename_01ab375a_uniq" UNIQUE ("content_type_id", "codename");


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_permission"
    ADD CONSTRAINT "auth_permission_pkey" PRIMARY KEY ("id");


--
-- Name: checkout_checkout cart_cart_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout"
    ADD CONSTRAINT "cart_cart_pkey" PRIMARY KEY ("token");


--
-- Name: checkout_checkoutline cart_cartline_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkoutline"
    ADD CONSTRAINT "cart_cartline_pkey" PRIMARY KEY ("id");


--
-- Name: checkout_checkoutline checkout_cartline_cart_id_variant_id_data_new_de3d8fca_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkoutline"
    ADD CONSTRAINT "checkout_cartline_cart_id_variant_id_data_new_de3d8fca_uniq" UNIQUE ("checkout_id", "variant_id", "data");


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gift_c_checkout_id_giftcard_id_401ba79e_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout_gift_cards"
    ADD CONSTRAINT "checkout_checkout_gift_c_checkout_id_giftcard_id_401ba79e_uniq" UNIQUE ("checkout_id", "giftcard_id");


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gift_cards_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout_gift_cards"
    ADD CONSTRAINT "checkout_checkout_gift_cards_pkey" PRIMARY KEY ("id");


--
-- Name: csv_exportevent csv_exportevent_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportevent"
    ADD CONSTRAINT "csv_exportevent_pkey" PRIMARY KEY ("id");


--
-- Name: csv_exportfile csv_exportfile_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportfile"
    ADD CONSTRAINT "csv_exportfile_pkey" PRIMARY KEY ("id");


--
-- Name: discount_sale_categories discount_sale_categories_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_categories"
    ADD CONSTRAINT "discount_sale_categories_pkey" PRIMARY KEY ("id");


--
-- Name: discount_sale_categories discount_sale_categories_sale_id_category_id_be438401_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_categories"
    ADD CONSTRAINT "discount_sale_categories_sale_id_category_id_be438401_uniq" UNIQUE ("sale_id", "category_id");


--
-- Name: discount_sale_collections discount_sale_collections_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_collections"
    ADD CONSTRAINT "discount_sale_collections_pkey" PRIMARY KEY ("id");


--
-- Name: discount_sale_collections discount_sale_collections_sale_id_collection_id_01b57fc3_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_collections"
    ADD CONSTRAINT "discount_sale_collections_sale_id_collection_id_01b57fc3_uniq" UNIQUE ("sale_id", "collection_id");


--
-- Name: discount_sale discount_sale_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale"
    ADD CONSTRAINT "discount_sale_pkey" PRIMARY KEY ("id");


--
-- Name: discount_sale_products discount_sale_products_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_products"
    ADD CONSTRAINT "discount_sale_products_pkey" PRIMARY KEY ("id");


--
-- Name: discount_sale_products discount_sale_products_sale_id_product_id_1c2df1f8_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_products"
    ADD CONSTRAINT "discount_sale_products_sale_id_product_id_1c2df1f8_uniq" UNIQUE ("sale_id", "product_id");


--
-- Name: discount_saletranslation discount_saletranslation_language_code_sale_id_e956163f_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_saletranslation"
    ADD CONSTRAINT "discount_saletranslation_language_code_sale_id_e956163f_uniq" UNIQUE ("language_code", "sale_id");


--
-- Name: discount_saletranslation discount_saletranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_saletranslation"
    ADD CONSTRAINT "discount_saletranslation_pkey" PRIMARY KEY ("id");


--
-- Name: discount_voucher_categories discount_voucher_categor_voucher_id_category_id_bb5f8954_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_categories"
    ADD CONSTRAINT "discount_voucher_categor_voucher_id_category_id_bb5f8954_uniq" UNIQUE ("voucher_id", "category_id");


--
-- Name: discount_voucher_categories discount_voucher_categories_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_categories"
    ADD CONSTRAINT "discount_voucher_categories_pkey" PRIMARY KEY ("id");


--
-- Name: discount_voucher discount_voucher_code_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher"
    ADD CONSTRAINT "discount_voucher_code_key" UNIQUE ("code");


--
-- Name: discount_voucher_collections discount_voucher_collect_voucher_id_collection_id_736b8f24_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_collections"
    ADD CONSTRAINT "discount_voucher_collect_voucher_id_collection_id_736b8f24_uniq" UNIQUE ("voucher_id", "collection_id");


--
-- Name: discount_voucher_collections discount_voucher_collections_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_collections"
    ADD CONSTRAINT "discount_voucher_collections_pkey" PRIMARY KEY ("id");


--
-- Name: discount_voucher discount_voucher_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher"
    ADD CONSTRAINT "discount_voucher_pkey" PRIMARY KEY ("id");


--
-- Name: discount_voucher_products discount_voucher_products_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_products"
    ADD CONSTRAINT "discount_voucher_products_pkey" PRIMARY KEY ("id");


--
-- Name: discount_voucher_products discount_voucher_products_voucher_id_product_id_2b092ec4_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_products"
    ADD CONSTRAINT "discount_voucher_products_voucher_id_product_id_2b092ec4_uniq" UNIQUE ("voucher_id", "product_id");


--
-- Name: discount_vouchercustomer discount_vouchercustomer_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchercustomer"
    ADD CONSTRAINT "discount_vouchercustomer_pkey" PRIMARY KEY ("id");


--
-- Name: discount_vouchercustomer discount_vouchercustomer_voucher_id_customer_emai_b7b1d6a1_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchercustomer"
    ADD CONSTRAINT "discount_vouchercustomer_voucher_id_customer_emai_b7b1d6a1_uniq" UNIQUE ("voucher_id", "customer_email");


--
-- Name: discount_vouchertranslation discount_vouchertranslat_language_code_voucher_id_af4428b5_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchertranslation"
    ADD CONSTRAINT "discount_vouchertranslat_language_code_voucher_id_af4428b5_uniq" UNIQUE ("language_code", "voucher_id");


--
-- Name: discount_vouchertranslation discount_vouchertranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchertranslation"
    ADD CONSTRAINT "discount_vouchertranslation_pkey" PRIMARY KEY ("id");


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_content_type"
    ADD CONSTRAINT "django_content_type_app_label_model_76bd3d3b_uniq" UNIQUE ("app_label", "model");


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_content_type"
    ADD CONSTRAINT "django_content_type_pkey" PRIMARY KEY ("id");


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_migrations"
    ADD CONSTRAINT "django_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: django_prices_openexchangerates_conversionrate django_prices_openexchangerates_conversionrate_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_prices_openexchangerates_conversionrate"
    ADD CONSTRAINT "django_prices_openexchangerates_conversionrate_pkey" PRIMARY KEY ("id");


--
-- Name: django_prices_openexchangerates_conversionrate django_prices_openexchangerates_conversionrate_to_currency_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_prices_openexchangerates_conversionrate"
    ADD CONSTRAINT "django_prices_openexchangerates_conversionrate_to_currency_key" UNIQUE ("to_currency");


--
-- Name: django_prices_vatlayer_ratetypes django_prices_vatlayer_ratetypes_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_prices_vatlayer_ratetypes"
    ADD CONSTRAINT "django_prices_vatlayer_ratetypes_pkey" PRIMARY KEY ("id");


--
-- Name: django_prices_vatlayer_vat django_prices_vatlayer_vat_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_prices_vatlayer_vat"
    ADD CONSTRAINT "django_prices_vatlayer_vat_pkey" PRIMARY KEY ("id");


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_site"
    ADD CONSTRAINT "django_site_domain_a2e37b91_uniq" UNIQUE ("domain");


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."django_site"
    ADD CONSTRAINT "django_site_pkey" PRIMARY KEY ("id");


--
-- Name: giftcard_giftcard giftcard_giftcard_code_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."giftcard_giftcard"
    ADD CONSTRAINT "giftcard_giftcard_code_key" UNIQUE ("code");


--
-- Name: giftcard_giftcard giftcard_giftcard_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."giftcard_giftcard"
    ADD CONSTRAINT "giftcard_giftcard_pkey" PRIMARY KEY ("id");


--
-- Name: invoice_invoice invoice_invoice_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoice"
    ADD CONSTRAINT "invoice_invoice_pkey" PRIMARY KEY ("id");


--
-- Name: invoice_invoiceevent invoice_invoiceevent_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoiceevent"
    ADD CONSTRAINT "invoice_invoiceevent_pkey" PRIMARY KEY ("id");


--
-- Name: menu_menu menu_menu_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menu"
    ADD CONSTRAINT "menu_menu_pkey" PRIMARY KEY ("id");


--
-- Name: menu_menuitem menu_menuitem_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitem"
    ADD CONSTRAINT "menu_menuitem_pkey" PRIMARY KEY ("id");


--
-- Name: menu_menuitemtranslation menu_menuitemtranslation_language_code_menu_item__508dcdd8_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitemtranslation"
    ADD CONSTRAINT "menu_menuitemtranslation_language_code_menu_item__508dcdd8_uniq" UNIQUE ("language_code", "menu_item_id");


--
-- Name: menu_menuitemtranslation menu_menuitemtranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitemtranslation"
    ADD CONSTRAINT "menu_menuitemtranslation_pkey" PRIMARY KEY ("id");


--
-- Name: order_fulfillment order_fulfillment_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillment"
    ADD CONSTRAINT "order_fulfillment_pkey" PRIMARY KEY ("id");


--
-- Name: order_fulfillmentline order_fulfillmentline_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillmentline"
    ADD CONSTRAINT "order_fulfillmentline_pkey" PRIMARY KEY ("id");


--
-- Name: order_order_gift_cards order_order_gift_cards_order_id_giftcard_id_f58e7356_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order_gift_cards"
    ADD CONSTRAINT "order_order_gift_cards_order_id_giftcard_id_f58e7356_uniq" UNIQUE ("order_id", "giftcard_id");


--
-- Name: order_order_gift_cards order_order_gift_cards_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order_gift_cards"
    ADD CONSTRAINT "order_order_gift_cards_pkey" PRIMARY KEY ("id");


--
-- Name: order_order order_order_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order"
    ADD CONSTRAINT "order_order_pkey" PRIMARY KEY ("id");


--
-- Name: order_order order_order_token_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order"
    ADD CONSTRAINT "order_order_token_key" UNIQUE ("token");


--
-- Name: order_orderline order_ordereditem_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderline"
    ADD CONSTRAINT "order_ordereditem_pkey" PRIMARY KEY ("id");


--
-- Name: order_orderevent order_orderevent_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderevent"
    ADD CONSTRAINT "order_orderevent_pkey" PRIMARY KEY ("id");


--
-- Name: page_page page_page_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."page_page"
    ADD CONSTRAINT "page_page_pkey" PRIMARY KEY ("id");


--
-- Name: page_page page_page_slug_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."page_page"
    ADD CONSTRAINT "page_page_slug_key" UNIQUE ("slug");


--
-- Name: page_pagetranslation page_pagetranslation_language_code_page_id_35685962_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."page_pagetranslation"
    ADD CONSTRAINT "page_pagetranslation_language_code_page_id_35685962_uniq" UNIQUE ("language_code", "page_id");


--
-- Name: page_pagetranslation page_pagetranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."page_pagetranslation"
    ADD CONSTRAINT "page_pagetranslation_pkey" PRIMARY KEY ("id");


--
-- Name: payment_payment payment_paymentmethod_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."payment_payment"
    ADD CONSTRAINT "payment_paymentmethod_pkey" PRIMARY KEY ("id");


--
-- Name: payment_transaction payment_transaction_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."payment_transaction"
    ADD CONSTRAINT "payment_transaction_pkey" PRIMARY KEY ("id");


--
-- Name: plugins_pluginconfiguration plugins_pluginconfiguration_identifier_3d7349fe_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."plugins_pluginconfiguration"
    ADD CONSTRAINT "plugins_pluginconfiguration_identifier_3d7349fe_uniq" UNIQUE ("identifier");


--
-- Name: plugins_pluginconfiguration plugins_pluginconfiguration_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."plugins_pluginconfiguration"
    ADD CONSTRAINT "plugins_pluginconfiguration_pkey" PRIMARY KEY ("id");


--
-- Name: product_assignedproductattribute_values product_assignedproducta_assignedproductattribute_ee1fc0ab_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute_values"
    ADD CONSTRAINT "product_assignedproducta_assignedproductattribute_ee1fc0ab_uniq" UNIQUE ("assignedproductattribute_id", "attributevalue_id");


--
-- Name: product_assignedproductattribute product_assignedproducta_product_id_assignment_id_d7f5aab5_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute"
    ADD CONSTRAINT "product_assignedproducta_product_id_assignment_id_d7f5aab5_uniq" UNIQUE ("product_id", "assignment_id");


--
-- Name: product_assignedproductattribute product_assignedproductattribute_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute"
    ADD CONSTRAINT "product_assignedproductattribute_pkey" PRIMARY KEY ("id");


--
-- Name: product_assignedproductattribute_values product_assignedproductattribute_values_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute_values"
    ADD CONSTRAINT "product_assignedproductattribute_values_pkey" PRIMARY KEY ("id");


--
-- Name: product_assignedvariantattribute_values product_assignedvarianta_assignedvariantattribute_8ffaee19_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute_values"
    ADD CONSTRAINT "product_assignedvarianta_assignedvariantattribute_8ffaee19_uniq" UNIQUE ("assignedvariantattribute_id", "attributevalue_id");


--
-- Name: product_assignedvariantattribute product_assignedvarianta_variant_id_assignment_id_16584418_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute"
    ADD CONSTRAINT "product_assignedvarianta_variant_id_assignment_id_16584418_uniq" UNIQUE ("variant_id", "assignment_id");


--
-- Name: product_assignedvariantattribute product_assignedvariantattribute_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute"
    ADD CONSTRAINT "product_assignedvariantattribute_pkey" PRIMARY KEY ("id");


--
-- Name: product_assignedvariantattribute_values product_assignedvariantattribute_values_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute_values"
    ADD CONSTRAINT "product_assignedvariantattribute_values_pkey" PRIMARY KEY ("id");


--
-- Name: product_attribute product_attribute_slug_a2ba35f2_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attribute"
    ADD CONSTRAINT "product_attribute_slug_a2ba35f2_uniq" UNIQUE ("slug");


--
-- Name: product_attributevaluetranslation product_attributechoicev_language_code_attribute__9b58af18_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevaluetranslation"
    ADD CONSTRAINT "product_attributechoicev_language_code_attribute__9b58af18_uniq" UNIQUE ("language_code", "attribute_value_id");


--
-- Name: product_attributevalue product_attributechoicevalue_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevalue"
    ADD CONSTRAINT "product_attributechoicevalue_pkey" PRIMARY KEY ("id");


--
-- Name: product_attributevaluetranslation product_attributechoicevaluetranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevaluetranslation"
    ADD CONSTRAINT "product_attributechoicevaluetranslation_pkey" PRIMARY KEY ("id");


--
-- Name: product_attributeproduct product_attributeproduct_attribute_id_product_typ_85ea87be_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributeproduct"
    ADD CONSTRAINT "product_attributeproduct_attribute_id_product_typ_85ea87be_uniq" UNIQUE ("attribute_id", "product_type_id");


--
-- Name: product_attributeproduct product_attributeproduct_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributeproduct"
    ADD CONSTRAINT "product_attributeproduct_pkey" PRIMARY KEY ("id");


--
-- Name: product_attributevalue product_attributevalue_slug_attribute_id_a9b19472_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevalue"
    ADD CONSTRAINT "product_attributevalue_slug_attribute_id_a9b19472_uniq" UNIQUE ("slug", "attribute_id");


--
-- Name: product_attributevariant product_attributevariant_attribute_id_product_typ_304d6c95_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevariant"
    ADD CONSTRAINT "product_attributevariant_attribute_id_product_typ_304d6c95_uniq" UNIQUE ("attribute_id", "product_type_id");


--
-- Name: product_attributevariant product_attributevariant_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevariant"
    ADD CONSTRAINT "product_attributevariant_pkey" PRIMARY KEY ("id");


--
-- Name: product_category product_category_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_category"
    ADD CONSTRAINT "product_category_pkey" PRIMARY KEY ("id");


--
-- Name: product_category product_category_slug_e1f8ccc4_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_category"
    ADD CONSTRAINT "product_category_slug_e1f8ccc4_uniq" UNIQUE ("slug");


--
-- Name: product_categorytranslation product_categorytranslat_language_code_category_i_f71fd11d_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_categorytranslation"
    ADD CONSTRAINT "product_categorytranslat_language_code_category_i_f71fd11d_uniq" UNIQUE ("language_code", "category_id");


--
-- Name: product_categorytranslation product_categorytranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_categorytranslation"
    ADD CONSTRAINT "product_categorytranslation_pkey" PRIMARY KEY ("id");


--
-- Name: product_collection product_collection_name_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collection"
    ADD CONSTRAINT "product_collection_name_key" UNIQUE ("name");


--
-- Name: product_collection product_collection_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collection"
    ADD CONSTRAINT "product_collection_pkey" PRIMARY KEY ("id");


--
-- Name: product_collectionproduct product_collection_products_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectionproduct"
    ADD CONSTRAINT "product_collection_products_pkey" PRIMARY KEY ("id");


--
-- Name: product_collection product_collection_slug_ec186116_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collection"
    ADD CONSTRAINT "product_collection_slug_ec186116_uniq" UNIQUE ("slug");


--
-- Name: product_collectionproduct product_collectionproduc_collection_id_product_id_e582d799_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectionproduct"
    ADD CONSTRAINT "product_collectionproduc_collection_id_product_id_e582d799_uniq" UNIQUE ("collection_id", "product_id");


--
-- Name: product_collectiontranslation product_collectiontransl_language_code_collection_b1200cd5_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectiontranslation"
    ADD CONSTRAINT "product_collectiontransl_language_code_collection_b1200cd5_uniq" UNIQUE ("language_code", "collection_id");


--
-- Name: product_collectiontranslation product_collectiontranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectiontranslation"
    ADD CONSTRAINT "product_collectiontranslation_pkey" PRIMARY KEY ("id");


--
-- Name: product_digitalcontent product_digitalcontent_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontent"
    ADD CONSTRAINT "product_digitalcontent_pkey" PRIMARY KEY ("id");


--
-- Name: product_digitalcontent product_digitalcontent_product_variant_id_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontent"
    ADD CONSTRAINT "product_digitalcontent_product_variant_id_key" UNIQUE ("product_variant_id");


--
-- Name: product_digitalcontenturl product_digitalcontenturl_line_id_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontenturl"
    ADD CONSTRAINT "product_digitalcontenturl_line_id_key" UNIQUE ("line_id");


--
-- Name: product_digitalcontenturl product_digitalcontenturl_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontenturl"
    ADD CONSTRAINT "product_digitalcontenturl_pkey" PRIMARY KEY ("id");


--
-- Name: product_digitalcontenturl product_digitalcontenturl_token_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontenturl"
    ADD CONSTRAINT "product_digitalcontenturl_token_key" UNIQUE ("token");


--
-- Name: product_product product_product_default_variant_id_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_product"
    ADD CONSTRAINT "product_product_default_variant_id_key" UNIQUE ("default_variant_id");


--
-- Name: product_product product_product_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_product"
    ADD CONSTRAINT "product_product_pkey" PRIMARY KEY ("id");


--
-- Name: product_product product_product_slug_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_product"
    ADD CONSTRAINT "product_product_slug_key" UNIQUE ("slug");


--
-- Name: product_attributetranslation product_productattribute_language_code_product_at_58451db2_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributetranslation"
    ADD CONSTRAINT "product_productattribute_language_code_product_at_58451db2_uniq" UNIQUE ("language_code", "attribute_id");


--
-- Name: product_attribute product_productattribute_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attribute"
    ADD CONSTRAINT "product_productattribute_pkey" PRIMARY KEY ("id");


--
-- Name: product_attributetranslation product_productattributetranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributetranslation"
    ADD CONSTRAINT "product_productattributetranslation_pkey" PRIMARY KEY ("id");


--
-- Name: product_producttype product_productclass_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_producttype"
    ADD CONSTRAINT "product_productclass_pkey" PRIMARY KEY ("id");


--
-- Name: product_productimage product_productimage_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productimage"
    ADD CONSTRAINT "product_productimage_pkey" PRIMARY KEY ("id");


--
-- Name: product_producttranslation product_producttranslati_language_code_product_id_b06ba774_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_producttranslation"
    ADD CONSTRAINT "product_producttranslati_language_code_product_id_b06ba774_uniq" UNIQUE ("language_code", "product_id");


--
-- Name: product_producttranslation product_producttranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_producttranslation"
    ADD CONSTRAINT "product_producttranslation_pkey" PRIMARY KEY ("id");


--
-- Name: product_producttype product_producttype_slug_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_producttype"
    ADD CONSTRAINT "product_producttype_slug_key" UNIQUE ("slug");


--
-- Name: product_productvariant product_productvariant_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvariant"
    ADD CONSTRAINT "product_productvariant_pkey" PRIMARY KEY ("id");


--
-- Name: product_productvariant product_productvariant_sku_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvariant"
    ADD CONSTRAINT "product_productvariant_sku_key" UNIQUE ("sku");


--
-- Name: product_productvarianttranslation product_productvarianttr_language_code_product_va_cf16d8d0_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvarianttranslation"
    ADD CONSTRAINT "product_productvarianttr_language_code_product_va_cf16d8d0_uniq" UNIQUE ("language_code", "product_variant_id");


--
-- Name: product_productvarianttranslation product_productvarianttranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvarianttranslation"
    ADD CONSTRAINT "product_productvarianttranslation_pkey" PRIMARY KEY ("id");


--
-- Name: product_variantimage product_variantimage_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_variantimage"
    ADD CONSTRAINT "product_variantimage_pkey" PRIMARY KEY ("id");


--
-- Name: product_variantimage product_variantimage_variant_id_image_id_b19f327c_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_variantimage"
    ADD CONSTRAINT "product_variantimage_variant_id_image_id_b19f327c_uniq" UNIQUE ("variant_id", "image_id");


--
-- Name: shipping_shippingmethod shipping_shippingmethod_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingmethod"
    ADD CONSTRAINT "shipping_shippingmethod_pkey" PRIMARY KEY ("id");


--
-- Name: shipping_shippingmethodtranslation shipping_shippingmethodt_language_code_shipping_m_70e4f786_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingmethodtranslation"
    ADD CONSTRAINT "shipping_shippingmethodt_language_code_shipping_m_70e4f786_uniq" UNIQUE ("language_code", "shipping_method_id");


--
-- Name: shipping_shippingmethodtranslation shipping_shippingmethodtranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingmethodtranslation"
    ADD CONSTRAINT "shipping_shippingmethodtranslation_pkey" PRIMARY KEY ("id");


--
-- Name: shipping_shippingzone shipping_shippingzone_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingzone"
    ADD CONSTRAINT "shipping_shippingzone_pkey" PRIMARY KEY ("id");


--
-- Name: site_authorizationkey site_authorizationkey_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_authorizationkey"
    ADD CONSTRAINT "site_authorizationkey_pkey" PRIMARY KEY ("id");


--
-- Name: site_authorizationkey site_authorizationkey_site_settings_id_name_c5f8d1e6_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_authorizationkey"
    ADD CONSTRAINT "site_authorizationkey_site_settings_id_name_c5f8d1e6_uniq" UNIQUE ("site_settings_id", "name");


--
-- Name: site_sitesettings site_sitesettings_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings"
    ADD CONSTRAINT "site_sitesettings_pkey" PRIMARY KEY ("id");


--
-- Name: site_sitesettings site_sitesettings_site_id_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings"
    ADD CONSTRAINT "site_sitesettings_site_id_key" UNIQUE ("site_id");


--
-- Name: site_sitesettingstranslation site_sitesettingstransla_language_code_site_setti_e767d9e7_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettingstranslation"
    ADD CONSTRAINT "site_sitesettingstransla_language_code_site_setti_e767d9e7_uniq" UNIQUE ("language_code", "site_settings_id");


--
-- Name: site_sitesettingstranslation site_sitesettingstranslation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettingstranslation"
    ADD CONSTRAINT "site_sitesettingstranslation_pkey" PRIMARY KEY ("id");


--
-- Name: tests_book tests_book_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."tests_book"
    ADD CONSTRAINT "tests_book_pkey" PRIMARY KEY ("id");


--
-- Name: account_address userprofile_address_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_address"
    ADD CONSTRAINT "userprofile_address_pkey" PRIMARY KEY ("id");


--
-- Name: account_user_addresses userprofile_user_addresses_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_addresses"
    ADD CONSTRAINT "userprofile_user_addresses_pkey" PRIMARY KEY ("id");


--
-- Name: account_user_addresses userprofile_user_addresses_user_id_address_id_6cb87bcc_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_addresses"
    ADD CONSTRAINT "userprofile_user_addresses_user_id_address_id_6cb87bcc_uniq" UNIQUE ("user_id", "address_id");


--
-- Name: account_user userprofile_user_email_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user"
    ADD CONSTRAINT "userprofile_user_email_key" UNIQUE ("email");


--
-- Name: account_user_groups userprofile_user_groups_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_groups"
    ADD CONSTRAINT "userprofile_user_groups_pkey" PRIMARY KEY ("id");


--
-- Name: account_user_groups userprofile_user_groups_user_id_group_id_90ce1781_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_groups"
    ADD CONSTRAINT "userprofile_user_groups_user_id_group_id_90ce1781_uniq" UNIQUE ("user_id", "group_id");


--
-- Name: account_user userprofile_user_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user"
    ADD CONSTRAINT "userprofile_user_pkey" PRIMARY KEY ("id");


--
-- Name: account_user_user_permissions userprofile_user_user_pe_user_id_permission_id_706d65c8_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_user_permissions"
    ADD CONSTRAINT "userprofile_user_user_pe_user_id_permission_id_706d65c8_uniq" UNIQUE ("user_id", "permission_id");


--
-- Name: account_user_user_permissions userprofile_user_user_permissions_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_user_permissions"
    ADD CONSTRAINT "userprofile_user_user_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: warehouse_allocation warehouse_allocation_order_line_id_stock_id_aa103861_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_allocation"
    ADD CONSTRAINT "warehouse_allocation_order_line_id_stock_id_aa103861_uniq" UNIQUE ("order_line_id", "stock_id");


--
-- Name: warehouse_allocation warehouse_allocation_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_allocation"
    ADD CONSTRAINT "warehouse_allocation_pkey" PRIMARY KEY ("id");


--
-- Name: warehouse_stock warehouse_stock_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_stock"
    ADD CONSTRAINT "warehouse_stock_pkey" PRIMARY KEY ("id");


--
-- Name: warehouse_stock warehouse_stock_warehouse_id_product_variant_id_b04a0a40_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_stock"
    ADD CONSTRAINT "warehouse_stock_warehouse_id_product_variant_id_b04a0a40_uniq" UNIQUE ("warehouse_id", "product_variant_id");


--
-- Name: warehouse_warehouse warehouse_warehouse_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse"
    ADD CONSTRAINT "warehouse_warehouse_pkey" PRIMARY KEY ("id");


--
-- Name: warehouse_warehouse_shipping_zones warehouse_warehouse_ship_warehouse_id_shippingzon_e18400fa_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse_shipping_zones"
    ADD CONSTRAINT "warehouse_warehouse_ship_warehouse_id_shippingzon_e18400fa_uniq" UNIQUE ("warehouse_id", "shippingzone_id");


--
-- Name: warehouse_warehouse_shipping_zones warehouse_warehouse_shipping_zones_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse_shipping_zones"
    ADD CONSTRAINT "warehouse_warehouse_shipping_zones_pkey" PRIMARY KEY ("id");


--
-- Name: warehouse_warehouse warehouse_warehouse_slug_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse"
    ADD CONSTRAINT "warehouse_warehouse_slug_key" UNIQUE ("slug");


--
-- Name: webhook_webhook webhook_webhook_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."webhook_webhook"
    ADD CONSTRAINT "webhook_webhook_pkey" PRIMARY KEY ("id");


--
-- Name: webhook_webhookevent webhook_webhookevent_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."webhook_webhookevent"
    ADD CONSTRAINT "webhook_webhookevent_pkey" PRIMARY KEY ("id");


--
-- Name: wishlist_wishlist wishlist_wishlist_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlist"
    ADD CONSTRAINT "wishlist_wishlist_pkey" PRIMARY KEY ("id");


--
-- Name: wishlist_wishlist wishlist_wishlist_token_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlist"
    ADD CONSTRAINT "wishlist_wishlist_token_key" UNIQUE ("token");


--
-- Name: wishlist_wishlist wishlist_wishlist_user_id_key; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlist"
    ADD CONSTRAINT "wishlist_wishlist_user_id_key" UNIQUE ("user_id");


--
-- Name: wishlist_wishlistitem wishlist_wishlistitem_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem"
    ADD CONSTRAINT "wishlist_wishlistitem_pkey" PRIMARY KEY ("id");


--
-- Name: wishlist_wishlistitem_variants wishlist_wishlistitem_va_wishlistitem_id_productv_33a1ed29_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem_variants"
    ADD CONSTRAINT "wishlist_wishlistitem_va_wishlistitem_id_productv_33a1ed29_uniq" UNIQUE ("wishlistitem_id", "productvariant_id");


--
-- Name: wishlist_wishlistitem_variants wishlist_wishlistitem_variants_pkey; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem_variants"
    ADD CONSTRAINT "wishlist_wishlistitem_variants_pkey" PRIMARY KEY ("id");


--
-- Name: wishlist_wishlistitem wishlist_wishlistitem_wishlist_id_product_id_3b73b644_uniq; Type: CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem"
    ADD CONSTRAINT "wishlist_wishlistitem_wishlist_id_product_id_3b73b644_uniq" UNIQUE ("wishlist_id", "product_id");


--
-- Name: account_customerevent_order_id_2d6e2d20; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_customerevent_order_id_2d6e2d20" ON "mirumee"."account_customerevent" USING "btree" ("order_id");


--
-- Name: account_customerevent_user_id_b3d6ec36; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_customerevent_user_id_b3d6ec36" ON "mirumee"."account_customerevent" USING "btree" ("user_id");


--
-- Name: account_customernote_customer_id_ec50cbf6; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_customernote_customer_id_ec50cbf6" ON "mirumee"."account_customernote" USING "btree" ("customer_id");


--
-- Name: account_customernote_date_231c3474; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_customernote_date_231c3474" ON "mirumee"."account_customernote" USING "btree" ("date");


--
-- Name: account_customernote_user_id_b10a6c14; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_customernote_user_id_b10a6c14" ON "mirumee"."account_customernote" USING "btree" ("user_id");


--
-- Name: account_serviceaccount_permissions_permission_id_449791f0; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_serviceaccount_permissions_permission_id_449791f0" ON "mirumee"."app_app_permissions" USING "btree" ("permission_id");


--
-- Name: account_serviceaccount_permissions_serviceaccount_id_ec78f497; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_serviceaccount_permissions_serviceaccount_id_ec78f497" ON "mirumee"."app_app_permissions" USING "btree" ("app_id");


--
-- Name: account_serviceaccounttoken_auth_token_e4c38601_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_serviceaccounttoken_auth_token_e4c38601_like" ON "mirumee"."app_apptoken" USING "btree" ("auth_token" "varchar_pattern_ops");


--
-- Name: account_serviceaccounttoken_service_account_id_a8e6dee8; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_serviceaccounttoken_service_account_id_a8e6dee8" ON "mirumee"."app_apptoken" USING "btree" ("app_id");


--
-- Name: account_staffnotificationrecipient_staff_email_a309b82e_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "account_staffnotificationrecipient_staff_email_a309b82e_like" ON "mirumee"."account_staffnotificationrecipient" USING "btree" ("staff_email" "varchar_pattern_ops");


--
-- Name: app_appinstallation_permissions_appinstallation_id_f7fe0271; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "app_appinstallation_permissions_appinstallation_id_f7fe0271" ON "mirumee"."app_appinstallation_permissions" USING "btree" ("appinstallation_id");


--
-- Name: app_appinstallation_permissions_permission_id_4ee9f6c8; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "app_appinstallation_permissions_permission_id_4ee9f6c8" ON "mirumee"."app_appinstallation_permissions" USING "btree" ("permission_id");


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "auth_group_name_a6ea08ec_like" ON "mirumee"."auth_group" USING "btree" ("name" "varchar_pattern_ops");


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "auth_group_permissions_group_id_b120cbf9" ON "mirumee"."auth_group_permissions" USING "btree" ("group_id");


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "auth_group_permissions_permission_id_84c5c92e" ON "mirumee"."auth_group_permissions" USING "btree" ("permission_id");


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "auth_permission_content_type_id_2f476e4b" ON "mirumee"."auth_permission" USING "btree" ("content_type_id");


--
-- Name: cart_cart_billing_address_id_9eb62ddd; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "cart_cart_billing_address_id_9eb62ddd" ON "mirumee"."checkout_checkout" USING "btree" ("billing_address_id");


--
-- Name: cart_cart_shipping_address_id_adfddaf9; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "cart_cart_shipping_address_id_adfddaf9" ON "mirumee"."checkout_checkout" USING "btree" ("shipping_address_id");


--
-- Name: cart_cart_shipping_method_id_835c02e0; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "cart_cart_shipping_method_id_835c02e0" ON "mirumee"."checkout_checkout" USING "btree" ("shipping_method_id");


--
-- Name: cart_cart_user_id_9b4220b9; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "cart_cart_user_id_9b4220b9" ON "mirumee"."checkout_checkout" USING "btree" ("user_id");


--
-- Name: cart_cartline_cart_id_c7b9981e; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "cart_cartline_cart_id_c7b9981e" ON "mirumee"."checkout_checkoutline" USING "btree" ("checkout_id");


--
-- Name: cart_cartline_product_id_1a54130f; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "cart_cartline_product_id_1a54130f" ON "mirumee"."checkout_checkoutline" USING "btree" ("variant_id");


--
-- Name: checkout_checkout_gift_cards_checkout_id_e314728d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "checkout_checkout_gift_cards_checkout_id_e314728d" ON "mirumee"."checkout_checkout_gift_cards" USING "btree" ("checkout_id");


--
-- Name: checkout_checkout_gift_cards_giftcard_id_f5994462; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "checkout_checkout_gift_cards_giftcard_id_f5994462" ON "mirumee"."checkout_checkout_gift_cards" USING "btree" ("giftcard_id");


--
-- Name: csv_exportevent_app_id_8637fcc5; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "csv_exportevent_app_id_8637fcc5" ON "mirumee"."csv_exportevent" USING "btree" ("app_id");


--
-- Name: csv_exportevent_export_file_id_35f6c448; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "csv_exportevent_export_file_id_35f6c448" ON "mirumee"."csv_exportevent" USING "btree" ("export_file_id");


--
-- Name: csv_exportevent_user_id_6111f193; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "csv_exportevent_user_id_6111f193" ON "mirumee"."csv_exportevent" USING "btree" ("user_id");


--
-- Name: csv_exportfile_app_id_bc900999; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "csv_exportfile_app_id_bc900999" ON "mirumee"."csv_exportfile" USING "btree" ("app_id");


--
-- Name: csv_exportfile_user_id_2c9071e6; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "csv_exportfile_user_id_2c9071e6" ON "mirumee"."csv_exportfile" USING "btree" ("user_id");


--
-- Name: discount_sale_categories_category_id_64e132af; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_sale_categories_category_id_64e132af" ON "mirumee"."discount_sale_categories" USING "btree" ("category_id");


--
-- Name: discount_sale_categories_sale_id_2aeee4a7; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_sale_categories_sale_id_2aeee4a7" ON "mirumee"."discount_sale_categories" USING "btree" ("sale_id");


--
-- Name: discount_sale_collections_collection_id_f66df9d7; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_sale_collections_collection_id_f66df9d7" ON "mirumee"."discount_sale_collections" USING "btree" ("collection_id");


--
-- Name: discount_sale_collections_sale_id_a912da4a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_sale_collections_sale_id_a912da4a" ON "mirumee"."discount_sale_collections" USING "btree" ("sale_id");


--
-- Name: discount_sale_products_product_id_d42c9636; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_sale_products_product_id_d42c9636" ON "mirumee"."discount_sale_products" USING "btree" ("product_id");


--
-- Name: discount_sale_products_sale_id_10e3a20f; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_sale_products_sale_id_10e3a20f" ON "mirumee"."discount_sale_products" USING "btree" ("sale_id");


--
-- Name: discount_saletranslation_sale_id_36a69b0a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_saletranslation_sale_id_36a69b0a" ON "mirumee"."discount_saletranslation" USING "btree" ("sale_id");


--
-- Name: discount_voucher_categories_category_id_fc9d044a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_voucher_categories_category_id_fc9d044a" ON "mirumee"."discount_voucher_categories" USING "btree" ("category_id");


--
-- Name: discount_voucher_categories_voucher_id_19a56338; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_voucher_categories_voucher_id_19a56338" ON "mirumee"."discount_voucher_categories" USING "btree" ("voucher_id");


--
-- Name: discount_voucher_code_ff8dc52c_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_voucher_code_ff8dc52c_like" ON "mirumee"."discount_voucher" USING "btree" ("code" "varchar_pattern_ops");


--
-- Name: discount_voucher_collections_collection_id_b9de6b54; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_voucher_collections_collection_id_b9de6b54" ON "mirumee"."discount_voucher_collections" USING "btree" ("collection_id");


--
-- Name: discount_voucher_collections_voucher_id_4ce1fde3; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_voucher_collections_voucher_id_4ce1fde3" ON "mirumee"."discount_voucher_collections" USING "btree" ("voucher_id");


--
-- Name: discount_voucher_products_product_id_4a3131ff; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_voucher_products_product_id_4a3131ff" ON "mirumee"."discount_voucher_products" USING "btree" ("product_id");


--
-- Name: discount_voucher_products_voucher_id_8a2e6c3a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_voucher_products_voucher_id_8a2e6c3a" ON "mirumee"."discount_voucher_products" USING "btree" ("voucher_id");


--
-- Name: discount_vouchercustomer_voucher_id_bb55c04f; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_vouchercustomer_voucher_id_bb55c04f" ON "mirumee"."discount_vouchercustomer" USING "btree" ("voucher_id");


--
-- Name: discount_vouchertranslation_voucher_id_288246a9; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "discount_vouchertranslation_voucher_id_288246a9" ON "mirumee"."discount_vouchertranslation" USING "btree" ("voucher_id");


--
-- Name: django_prices_openexchan_to_currency_92c4a4e1_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "django_prices_openexchan_to_currency_92c4a4e1_like" ON "mirumee"."django_prices_openexchangerates_conversionrate" USING "btree" ("to_currency" "varchar_pattern_ops");


--
-- Name: django_prices_vatlayer_vat_country_code_858b2cc4; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "django_prices_vatlayer_vat_country_code_858b2cc4" ON "mirumee"."django_prices_vatlayer_vat" USING "btree" ("country_code");


--
-- Name: django_prices_vatlayer_vat_country_code_858b2cc4_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "django_prices_vatlayer_vat_country_code_858b2cc4_like" ON "mirumee"."django_prices_vatlayer_vat" USING "btree" ("country_code" "varchar_pattern_ops");


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "django_site_domain_a2e37b91_like" ON "mirumee"."django_site" USING "btree" ("domain" "varchar_pattern_ops");


--
-- Name: giftcard_giftcard_code_f6fb6be8_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "giftcard_giftcard_code_f6fb6be8_like" ON "mirumee"."giftcard_giftcard" USING "btree" ("code" "varchar_pattern_ops");


--
-- Name: giftcard_giftcard_user_id_ce2401b5; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "giftcard_giftcard_user_id_ce2401b5" ON "mirumee"."giftcard_giftcard" USING "btree" ("user_id");


--
-- Name: invoice_invoice_order_id_c5fc9ae9; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "invoice_invoice_order_id_c5fc9ae9" ON "mirumee"."invoice_invoice" USING "btree" ("order_id");


--
-- Name: invoice_invoiceevent_invoice_id_de0632ca; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "invoice_invoiceevent_invoice_id_de0632ca" ON "mirumee"."invoice_invoiceevent" USING "btree" ("invoice_id");


--
-- Name: invoice_invoiceevent_order_id_5a337f7a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "invoice_invoiceevent_order_id_5a337f7a" ON "mirumee"."invoice_invoiceevent" USING "btree" ("order_id");


--
-- Name: invoice_invoiceevent_user_id_cd599b8d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "invoice_invoiceevent_user_id_cd599b8d" ON "mirumee"."invoice_invoiceevent" USING "btree" ("user_id");


--
-- Name: menu_menuitem_category_id_af353a3b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitem_category_id_af353a3b" ON "mirumee"."menu_menuitem" USING "btree" ("category_id");


--
-- Name: menu_menuitem_collection_id_b913b19e; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitem_collection_id_b913b19e" ON "mirumee"."menu_menuitem" USING "btree" ("collection_id");


--
-- Name: menu_menuitem_menu_id_f466b139; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitem_menu_id_f466b139" ON "mirumee"."menu_menuitem" USING "btree" ("menu_id");


--
-- Name: menu_menuitem_page_id_a0c8f92d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitem_page_id_a0c8f92d" ON "mirumee"."menu_menuitem" USING "btree" ("page_id");


--
-- Name: menu_menuitem_parent_id_439f55a5; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitem_parent_id_439f55a5" ON "mirumee"."menu_menuitem" USING "btree" ("parent_id");


--
-- Name: menu_menuitem_sort_order_f96ed184; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitem_sort_order_f96ed184" ON "mirumee"."menu_menuitem" USING "btree" ("sort_order");


--
-- Name: menu_menuitem_tree_id_0d2e9c9a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitem_tree_id_0d2e9c9a" ON "mirumee"."menu_menuitem" USING "btree" ("tree_id");


--
-- Name: menu_menuitemtranslation_menu_item_id_3445926c; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "menu_menuitemtranslation_menu_item_id_3445926c" ON "mirumee"."menu_menuitemtranslation" USING "btree" ("menu_item_id");


--
-- Name: order_fulfillment_order_id_02695111; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_fulfillment_order_id_02695111" ON "mirumee"."order_fulfillment" USING "btree" ("order_id");


--
-- Name: order_fulfillmentline_fulfillment_id_68f3291d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_fulfillmentline_fulfillment_id_68f3291d" ON "mirumee"."order_fulfillmentline" USING "btree" ("fulfillment_id");


--
-- Name: order_fulfillmentline_order_line_id_7d40e054; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_fulfillmentline_order_line_id_7d40e054" ON "mirumee"."order_fulfillmentline" USING "btree" ("order_line_id");


--
-- Name: order_fulfillmentline_stock_id_da5a99fe; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_fulfillmentline_stock_id_da5a99fe" ON "mirumee"."order_fulfillmentline" USING "btree" ("stock_id");


--
-- Name: order_order_billing_address_id_8fe537cf; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_billing_address_id_8fe537cf" ON "mirumee"."order_order" USING "btree" ("billing_address_id");


--
-- Name: order_order_gift_cards_giftcard_id_f6844926; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_gift_cards_giftcard_id_f6844926" ON "mirumee"."order_order_gift_cards" USING "btree" ("giftcard_id");


--
-- Name: order_order_gift_cards_order_id_ce5608c4; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_gift_cards_order_id_ce5608c4" ON "mirumee"."order_order_gift_cards" USING "btree" ("order_id");


--
-- Name: order_order_shipping_address_id_57e64931; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_shipping_address_id_57e64931" ON "mirumee"."order_order" USING "btree" ("shipping_address_id");


--
-- Name: order_order_shipping_method_id_2a742834; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_shipping_method_id_2a742834" ON "mirumee"."order_order" USING "btree" ("shipping_method_id");


--
-- Name: order_order_token_ddb7fb7b_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_token_ddb7fb7b_like" ON "mirumee"."order_order" USING "btree" ("token" "varchar_pattern_ops");


--
-- Name: order_order_user_id_7cf9bc2b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_user_id_7cf9bc2b" ON "mirumee"."order_order" USING "btree" ("user_id");


--
-- Name: order_order_voucher_id_0748ca22; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_order_voucher_id_0748ca22" ON "mirumee"."order_order" USING "btree" ("voucher_id");


--
-- Name: order_orderevent_order_id_09aa7ccd; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_orderevent_order_id_09aa7ccd" ON "mirumee"."order_orderevent" USING "btree" ("order_id");


--
-- Name: order_orderevent_user_id_1056ac9c; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_orderevent_user_id_1056ac9c" ON "mirumee"."order_orderevent" USING "btree" ("user_id");


--
-- Name: order_orderline_order_id_eb04ec2d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_orderline_order_id_eb04ec2d" ON "mirumee"."order_orderline" USING "btree" ("order_id");


--
-- Name: order_orderline_variant_id_866774cb; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "order_orderline_variant_id_866774cb" ON "mirumee"."order_orderline" USING "btree" ("variant_id");


--
-- Name: page_page_slug_d6b7c8ed_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "page_page_slug_d6b7c8ed_like" ON "mirumee"."page_page" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: page_pagetranslation_page_id_60216ef5; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "page_pagetranslation_page_id_60216ef5" ON "mirumee"."page_pagetranslation" USING "btree" ("page_id");


--
-- Name: payment_paymentmethod_checkout_id_5c0aae3d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "payment_paymentmethod_checkout_id_5c0aae3d" ON "mirumee"."payment_payment" USING "btree" ("checkout_id");


--
-- Name: payment_paymentmethod_order_id_58acb979; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "payment_paymentmethod_order_id_58acb979" ON "mirumee"."payment_payment" USING "btree" ("order_id");


--
-- Name: payment_transaction_payment_method_id_d35e75c1; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "payment_transaction_payment_method_id_d35e75c1" ON "mirumee"."payment_transaction" USING "btree" ("payment_id");


--
-- Name: plugins_pluginconfiguration_identifier_3d7349fe_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "plugins_pluginconfiguration_identifier_3d7349fe_like" ON "mirumee"."plugins_pluginconfiguration" USING "btree" ("identifier" "varchar_pattern_ops");


--
-- Name: product_assignedproductatt_assignedproductattribute_i_6d497dfa; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedproductatt_assignedproductattribute_i_6d497dfa" ON "mirumee"."product_assignedproductattribute_values" USING "btree" ("assignedproductattribute_id");


--
-- Name: product_assignedproductatt_attributevalue_id_5bd29b24; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedproductatt_attributevalue_id_5bd29b24" ON "mirumee"."product_assignedproductattribute_values" USING "btree" ("attributevalue_id");


--
-- Name: product_assignedproductattribute_assignment_id_eb2f81a4; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedproductattribute_assignment_id_eb2f81a4" ON "mirumee"."product_assignedproductattribute" USING "btree" ("assignment_id");


--
-- Name: product_assignedproductattribute_product_id_68be10a3; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedproductattribute_product_id_68be10a3" ON "mirumee"."product_assignedproductattribute" USING "btree" ("product_id");


--
-- Name: product_assignedvariantatt_assignedvariantattribute_i_8d6d62ef; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedvariantatt_assignedvariantattribute_i_8d6d62ef" ON "mirumee"."product_assignedvariantattribute_values" USING "btree" ("assignedvariantattribute_id");


--
-- Name: product_assignedvariantatt_attributevalue_id_41cc2454; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedvariantatt_attributevalue_id_41cc2454" ON "mirumee"."product_assignedvariantattribute_values" USING "btree" ("attributevalue_id");


--
-- Name: product_assignedvariantattribute_assignment_id_8fdbffe8; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedvariantattribute_assignment_id_8fdbffe8" ON "mirumee"."product_assignedvariantattribute" USING "btree" ("assignment_id");


--
-- Name: product_assignedvariantattribute_variant_id_27483e6a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_assignedvariantattribute_variant_id_27483e6a" ON "mirumee"."product_assignedvariantattribute" USING "btree" ("variant_id");


--
-- Name: product_attribute_slug_a2ba35f2_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attribute_slug_a2ba35f2_like" ON "mirumee"."product_attribute" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: product_attributechoiceval_attribute_choice_value_id_71c4c0a7; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributechoiceval_attribute_choice_value_id_71c4c0a7" ON "mirumee"."product_attributevaluetranslation" USING "btree" ("attribute_value_id");


--
-- Name: product_attributechoicevalue_attribute_id_c28c6c92; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributechoicevalue_attribute_id_c28c6c92" ON "mirumee"."product_attributevalue" USING "btree" ("attribute_id");


--
-- Name: product_attributechoicevalue_slug_e0d2d25b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributechoicevalue_slug_e0d2d25b" ON "mirumee"."product_attributevalue" USING "btree" ("slug");


--
-- Name: product_attributechoicevalue_slug_e0d2d25b_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributechoicevalue_slug_e0d2d25b_like" ON "mirumee"."product_attributevalue" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: product_attributechoicevalue_sort_order_c4c071c4; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributechoicevalue_sort_order_c4c071c4" ON "mirumee"."product_attributevalue" USING "btree" ("sort_order");


--
-- Name: product_attributeproduct_attribute_id_0051c706; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributeproduct_attribute_id_0051c706" ON "mirumee"."product_attributeproduct" USING "btree" ("attribute_id");


--
-- Name: product_attributeproduct_product_type_id_54357b3b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributeproduct_product_type_id_54357b3b" ON "mirumee"."product_attributeproduct" USING "btree" ("product_type_id");


--
-- Name: product_attributeproduct_sort_order_cec8a8e2; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributeproduct_sort_order_cec8a8e2" ON "mirumee"."product_attributeproduct" USING "btree" ("sort_order");


--
-- Name: product_attributevariant_attribute_id_e47d3bc3; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributevariant_attribute_id_e47d3bc3" ON "mirumee"."product_attributevariant" USING "btree" ("attribute_id");


--
-- Name: product_attributevariant_product_type_id_ba95c6dd; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributevariant_product_type_id_ba95c6dd" ON "mirumee"."product_attributevariant" USING "btree" ("product_type_id");


--
-- Name: product_attributevariant_sort_order_cf4b00ef; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_attributevariant_sort_order_cf4b00ef" ON "mirumee"."product_attributevariant" USING "btree" ("sort_order");


--
-- Name: product_category_parent_id_f6860923; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_category_parent_id_f6860923" ON "mirumee"."product_category" USING "btree" ("parent_id");


--
-- Name: product_category_slug_e1f8ccc4_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_category_slug_e1f8ccc4_like" ON "mirumee"."product_category" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: product_category_tree_id_f3c46461; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_category_tree_id_f3c46461" ON "mirumee"."product_category" USING "btree" ("tree_id");


--
-- Name: product_categorytranslation_category_id_aa8d0917; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_categorytranslation_category_id_aa8d0917" ON "mirumee"."product_categorytranslation" USING "btree" ("category_id");


--
-- Name: product_collection_name_03bb818b_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_collection_name_03bb818b_like" ON "mirumee"."product_collection" USING "btree" ("name" "varchar_pattern_ops");


--
-- Name: product_collection_products_collection_id_0bc817dc; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_collection_products_collection_id_0bc817dc" ON "mirumee"."product_collectionproduct" USING "btree" ("collection_id");


--
-- Name: product_collection_products_product_id_a45a5b06; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_collection_products_product_id_a45a5b06" ON "mirumee"."product_collectionproduct" USING "btree" ("product_id");


--
-- Name: product_collection_slug_ec186116_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_collection_slug_ec186116_like" ON "mirumee"."product_collection" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: product_collectionproduct_sort_order_5e7b55bb; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_collectionproduct_sort_order_5e7b55bb" ON "mirumee"."product_collectionproduct" USING "btree" ("sort_order");


--
-- Name: product_collectiontranslation_collection_id_cfbbd453; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_collectiontranslation_collection_id_cfbbd453" ON "mirumee"."product_collectiontranslation" USING "btree" ("collection_id");


--
-- Name: product_digitalcontenturl_content_id_654197bd; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_digitalcontenturl_content_id_654197bd" ON "mirumee"."product_digitalcontenturl" USING "btree" ("content_id");


--
-- Name: product_product_category_id_0c725779; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_product_category_id_0c725779" ON "mirumee"."product_product" USING "btree" ("category_id");


--
-- Name: product_product_product_class_id_0547c998; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_product_product_class_id_0547c998" ON "mirumee"."product_product" USING "btree" ("product_type_id");


--
-- Name: product_product_slug_76cde0ae_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_product_slug_76cde0ae_like" ON "mirumee"."product_product" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: product_productattributetr_product_attribute_id_56b48511; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_productattributetr_product_attribute_id_56b48511" ON "mirumee"."product_attributetranslation" USING "btree" ("attribute_id");


--
-- Name: product_productimage_product_id_544084bb; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_productimage_product_id_544084bb" ON "mirumee"."product_productimage" USING "btree" ("product_id");


--
-- Name: product_productimage_sort_order_dfda9c19; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_productimage_sort_order_dfda9c19" ON "mirumee"."product_productimage" USING "btree" ("sort_order");


--
-- Name: product_producttranslation_product_id_2c2c7532; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_producttranslation_product_id_2c2c7532" ON "mirumee"."product_producttranslation" USING "btree" ("product_id");


--
-- Name: product_producttype_slug_6871faf2_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_producttype_slug_6871faf2_like" ON "mirumee"."product_producttype" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: product_productvariant_product_id_43c5a310; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_productvariant_product_id_43c5a310" ON "mirumee"."product_productvariant" USING "btree" ("product_id");


--
-- Name: product_productvariant_sku_50706818_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_productvariant_sku_50706818_like" ON "mirumee"."product_productvariant" USING "btree" ("sku" "varchar_pattern_ops");


--
-- Name: product_productvariant_sort_order_d4acf89b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_productvariant_sort_order_d4acf89b" ON "mirumee"."product_productvariant" USING "btree" ("sort_order");


--
-- Name: product_productvarianttranslation_product_variant_id_1b144a85; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_productvarianttranslation_product_variant_id_1b144a85" ON "mirumee"."product_productvarianttranslation" USING "btree" ("product_variant_id");


--
-- Name: product_variantimage_image_id_bef14106; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_variantimage_image_id_bef14106" ON "mirumee"."product_variantimage" USING "btree" ("image_id");


--
-- Name: product_variantimage_variant_id_81123814; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "product_variantimage_variant_id_81123814" ON "mirumee"."product_variantimage" USING "btree" ("variant_id");


--
-- Name: shipping_shippingmethod_shipping_zone_id_265b7413; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "shipping_shippingmethod_shipping_zone_id_265b7413" ON "mirumee"."shipping_shippingmethod" USING "btree" ("shipping_zone_id");


--
-- Name: shipping_shippingmethodtranslation_shipping_method_id_31d925d2; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "shipping_shippingmethodtranslation_shipping_method_id_31d925d2" ON "mirumee"."shipping_shippingmethodtranslation" USING "btree" ("shipping_method_id");


--
-- Name: site_authorizationkey_site_settings_id_d8397c0f; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "site_authorizationkey_site_settings_id_d8397c0f" ON "mirumee"."site_authorizationkey" USING "btree" ("site_settings_id");


--
-- Name: site_sitesettings_bottom_menu_id_e2a78098; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "site_sitesettings_bottom_menu_id_e2a78098" ON "mirumee"."site_sitesettings" USING "btree" ("bottom_menu_id");


--
-- Name: site_sitesettings_company_address_id_f0825427; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "site_sitesettings_company_address_id_f0825427" ON "mirumee"."site_sitesettings" USING "btree" ("company_address_id");


--
-- Name: site_sitesettings_homepage_collection_id_82f45d33; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "site_sitesettings_homepage_collection_id_82f45d33" ON "mirumee"."site_sitesettings" USING "btree" ("homepage_collection_id");


--
-- Name: site_sitesettings_top_menu_id_ab6f8c46; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "site_sitesettings_top_menu_id_ab6f8c46" ON "mirumee"."site_sitesettings" USING "btree" ("top_menu_id");


--
-- Name: site_sitesettingstranslation_site_settings_id_ca085ff6; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "site_sitesettingstranslation_site_settings_id_ca085ff6" ON "mirumee"."site_sitesettingstranslation" USING "btree" ("site_settings_id");


--
-- Name: userprofile_user_addresses_address_id_ad7646b4; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_addresses_address_id_ad7646b4" ON "mirumee"."account_user_addresses" USING "btree" ("address_id");


--
-- Name: userprofile_user_addresses_user_id_bb5aa55e; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_addresses_user_id_bb5aa55e" ON "mirumee"."account_user_addresses" USING "btree" ("user_id");


--
-- Name: userprofile_user_default_billing_address_id_0489abf1; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_default_billing_address_id_0489abf1" ON "mirumee"."account_user" USING "btree" ("default_billing_address_id");


--
-- Name: userprofile_user_default_shipping_address_id_aae7a203; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_default_shipping_address_id_aae7a203" ON "mirumee"."account_user" USING "btree" ("default_shipping_address_id");


--
-- Name: userprofile_user_email_b0fb0137_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_email_b0fb0137_like" ON "mirumee"."account_user" USING "btree" ("email" "varchar_pattern_ops");


--
-- Name: userprofile_user_groups_group_id_c7eec74e; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_groups_group_id_c7eec74e" ON "mirumee"."account_user_groups" USING "btree" ("group_id");


--
-- Name: userprofile_user_groups_user_id_5e712a24; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_groups_user_id_5e712a24" ON "mirumee"."account_user_groups" USING "btree" ("user_id");


--
-- Name: userprofile_user_user_permissions_permission_id_1caa8a71; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_user_permissions_permission_id_1caa8a71" ON "mirumee"."account_user_user_permissions" USING "btree" ("permission_id");


--
-- Name: userprofile_user_user_permissions_user_id_6d654469; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "userprofile_user_user_permissions_user_id_6d654469" ON "mirumee"."account_user_user_permissions" USING "btree" ("user_id");


--
-- Name: warehouse_allocation_order_line_id_693dcb84; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_allocation_order_line_id_693dcb84" ON "mirumee"."warehouse_allocation" USING "btree" ("order_line_id");


--
-- Name: warehouse_allocation_stock_id_73541542; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_allocation_stock_id_73541542" ON "mirumee"."warehouse_allocation" USING "btree" ("stock_id");


--
-- Name: warehouse_stock_product_variant_id_bea58a82; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_stock_product_variant_id_bea58a82" ON "mirumee"."warehouse_stock" USING "btree" ("product_variant_id");


--
-- Name: warehouse_stock_warehouse_id_cc9d4e5d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_stock_warehouse_id_cc9d4e5d" ON "mirumee"."warehouse_stock" USING "btree" ("warehouse_id");


--
-- Name: warehouse_warehouse_address_id_d46e1096; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_warehouse_address_id_d46e1096" ON "mirumee"."warehouse_warehouse" USING "btree" ("address_id");


--
-- Name: warehouse_warehouse_shipping_zones_shippingzone_id_aeee255b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_warehouse_shipping_zones_shippingzone_id_aeee255b" ON "mirumee"."warehouse_warehouse_shipping_zones" USING "btree" ("shippingzone_id");


--
-- Name: warehouse_warehouse_shipping_zones_warehouse_id_fccd6647; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_warehouse_shipping_zones_warehouse_id_fccd6647" ON "mirumee"."warehouse_warehouse_shipping_zones" USING "btree" ("warehouse_id");


--
-- Name: warehouse_warehouse_slug_5ca9c575_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "warehouse_warehouse_slug_5ca9c575_like" ON "mirumee"."warehouse_warehouse" USING "btree" ("slug" "varchar_pattern_ops");


--
-- Name: webhook_webhook_service_account_id_1073b057; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "webhook_webhook_service_account_id_1073b057" ON "mirumee"."webhook_webhook" USING "btree" ("app_id");


--
-- Name: webhook_webhookevent_event_type_cd6b8c13; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "webhook_webhookevent_event_type_cd6b8c13" ON "mirumee"."webhook_webhookevent" USING "btree" ("event_type");


--
-- Name: webhook_webhookevent_event_type_cd6b8c13_like; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "webhook_webhookevent_event_type_cd6b8c13_like" ON "mirumee"."webhook_webhookevent" USING "btree" ("event_type" "varchar_pattern_ops");


--
-- Name: webhook_webhookevent_webhook_id_73b5c9e1; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "webhook_webhookevent_webhook_id_73b5c9e1" ON "mirumee"."webhook_webhookevent" USING "btree" ("webhook_id");


--
-- Name: wishlist_wishlistitem_product_id_8309716a; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "wishlist_wishlistitem_product_id_8309716a" ON "mirumee"."wishlist_wishlistitem" USING "btree" ("product_id");


--
-- Name: wishlist_wishlistitem_variants_productvariant_id_819ee66b; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "wishlist_wishlistitem_variants_productvariant_id_819ee66b" ON "mirumee"."wishlist_wishlistitem_variants" USING "btree" ("productvariant_id");


--
-- Name: wishlist_wishlistitem_variants_wishlistitem_id_ee616761; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "wishlist_wishlistitem_variants_wishlistitem_id_ee616761" ON "mirumee"."wishlist_wishlistitem_variants" USING "btree" ("wishlistitem_id");


--
-- Name: wishlist_wishlistitem_wishlist_id_a052b63d; Type: INDEX; Schema: mirumee; Owner: saleor
--

CREATE INDEX "wishlist_wishlistitem_wishlist_id_a052b63d" ON "mirumee"."wishlist_wishlistitem" USING "btree" ("wishlist_id");


--
-- Name: account_customerevent account_customerevent_order_id_2d6e2d20_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customerevent"
    ADD CONSTRAINT "account_customerevent_order_id_2d6e2d20_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_customerevent account_customerevent_user_id_b3d6ec36_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customerevent"
    ADD CONSTRAINT "account_customerevent_user_id_b3d6ec36_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_customernote account_customernote_customer_id_ec50cbf6_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customernote"
    ADD CONSTRAINT "account_customernote_customer_id_ec50cbf6_fk_account_user_id" FOREIGN KEY ("customer_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_customernote account_customernote_user_id_b10a6c14_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_customernote"
    ADD CONSTRAINT "account_customernote_user_id_b10a6c14_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_staffnotificationrecipient account_staffnotific_user_id_538fa3a4_fk_account_u; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_staffnotificationrecipient"
    ADD CONSTRAINT "account_staffnotific_user_id_538fa3a4_fk_account_u" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_addresses account_user_address_address_id_d218822a_fk_account_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_addresses"
    ADD CONSTRAINT "account_user_address_address_id_d218822a_fk_account_a" FOREIGN KEY ("address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_addresses account_user_addresses_user_id_2fcc8301_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_addresses"
    ADD CONSTRAINT "account_user_addresses_user_id_2fcc8301_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: app_app_permissions app_app_permissions_app_id_5941597d_fk_app_app_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_app_permissions"
    ADD CONSTRAINT "app_app_permissions_app_id_5941597d_fk_app_app_id" FOREIGN KEY ("app_id") REFERENCES "mirumee"."app_app"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: app_app_permissions app_app_permissions_permission_id_defe4a88_fk_auth_perm; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_app_permissions"
    ADD CONSTRAINT "app_app_permissions_permission_id_defe4a88_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "mirumee"."auth_permission"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: app_appinstallation_permissions app_appinstallation__appinstallation_id_f7fe0271_fk_app_appin; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_appinstallation_permissions"
    ADD CONSTRAINT "app_appinstallation__appinstallation_id_f7fe0271_fk_app_appin" FOREIGN KEY ("appinstallation_id") REFERENCES "mirumee"."app_appinstallation"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: app_appinstallation_permissions app_appinstallation__permission_id_4ee9f6c8_fk_auth_perm; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_appinstallation_permissions"
    ADD CONSTRAINT "app_appinstallation__permission_id_4ee9f6c8_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "mirumee"."auth_permission"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: app_apptoken app_apptoken_app_id_68561141_fk_app_app_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."app_apptoken"
    ADD CONSTRAINT "app_apptoken_app_id_68561141_fk_app_app_id" FOREIGN KEY ("app_id") REFERENCES "mirumee"."app_app"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissio_permission_id_84c5c92e_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "mirumee"."auth_permission"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissions_group_id_b120cbf9_fk_auth_group_id" FOREIGN KEY ("group_id") REFERENCES "mirumee"."auth_group"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."auth_permission"
    ADD CONSTRAINT "auth_permission_content_type_id_2f476e4b_fk_django_co" FOREIGN KEY ("content_type_id") REFERENCES "mirumee"."django_content_type"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout cart_cart_billing_address_id_9eb62ddd_fk_account_address_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout"
    ADD CONSTRAINT "cart_cart_billing_address_id_9eb62ddd_fk_account_address_id" FOREIGN KEY ("billing_address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout cart_cart_shipping_address_id_adfddaf9_fk_account_address_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout"
    ADD CONSTRAINT "cart_cart_shipping_address_id_adfddaf9_fk_account_address_id" FOREIGN KEY ("shipping_address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkoutline cart_cartline_variant_id_dbca56c9_fk_product_productvariant_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkoutline"
    ADD CONSTRAINT "cart_cartline_variant_id_dbca56c9_fk_product_productvariant_id" FOREIGN KEY ("variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkoutline checkout_cartline_checkout_id_41d95a5d_fk_checkout_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkoutline"
    ADD CONSTRAINT "checkout_cartline_checkout_id_41d95a5d_fk_checkout_" FOREIGN KEY ("checkout_id") REFERENCES "mirumee"."checkout_checkout"("token") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gi_checkout_id_e314728d_fk_checkout_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout_gift_cards"
    ADD CONSTRAINT "checkout_checkout_gi_checkout_id_e314728d_fk_checkout_" FOREIGN KEY ("checkout_id") REFERENCES "mirumee"."checkout_checkout"("token") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout_gift_cards checkout_checkout_gi_giftcard_id_f5994462_fk_giftcard_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout_gift_cards"
    ADD CONSTRAINT "checkout_checkout_gi_giftcard_id_f5994462_fk_giftcard_" FOREIGN KEY ("giftcard_id") REFERENCES "mirumee"."giftcard_giftcard"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout checkout_checkout_shipping_method_id_8796abd0_fk_shipping_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout"
    ADD CONSTRAINT "checkout_checkout_shipping_method_id_8796abd0_fk_shipping_" FOREIGN KEY ("shipping_method_id") REFERENCES "mirumee"."shipping_shippingmethod"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: checkout_checkout checkout_checkout_user_id_8b2fe298_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."checkout_checkout"
    ADD CONSTRAINT "checkout_checkout_user_id_8b2fe298_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: csv_exportevent csv_exportevent_app_id_8637fcc5_fk_app_app_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportevent"
    ADD CONSTRAINT "csv_exportevent_app_id_8637fcc5_fk_app_app_id" FOREIGN KEY ("app_id") REFERENCES "mirumee"."app_app"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: csv_exportevent csv_exportevent_export_file_id_35f6c448_fk_csv_exportfile_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportevent"
    ADD CONSTRAINT "csv_exportevent_export_file_id_35f6c448_fk_csv_exportfile_id" FOREIGN KEY ("export_file_id") REFERENCES "mirumee"."csv_exportfile"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: csv_exportevent csv_exportevent_user_id_6111f193_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportevent"
    ADD CONSTRAINT "csv_exportevent_user_id_6111f193_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: csv_exportfile csv_exportfile_app_id_bc900999_fk_app_app_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportfile"
    ADD CONSTRAINT "csv_exportfile_app_id_bc900999_fk_app_app_id" FOREIGN KEY ("app_id") REFERENCES "mirumee"."app_app"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: csv_exportfile csv_exportfile_user_id_2c9071e6_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."csv_exportfile"
    ADD CONSTRAINT "csv_exportfile_user_id_2c9071e6_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_categories discount_sale_catego_category_id_64e132af_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_categories"
    ADD CONSTRAINT "discount_sale_catego_category_id_64e132af_fk_product_c" FOREIGN KEY ("category_id") REFERENCES "mirumee"."product_category"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_categories discount_sale_categories_sale_id_2aeee4a7_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_categories"
    ADD CONSTRAINT "discount_sale_categories_sale_id_2aeee4a7_fk_discount_sale_id" FOREIGN KEY ("sale_id") REFERENCES "mirumee"."discount_sale"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_collections discount_sale_collec_collection_id_f66df9d7_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_collections"
    ADD CONSTRAINT "discount_sale_collec_collection_id_f66df9d7_fk_product_c" FOREIGN KEY ("collection_id") REFERENCES "mirumee"."product_collection"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_collections discount_sale_collections_sale_id_a912da4a_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_collections"
    ADD CONSTRAINT "discount_sale_collections_sale_id_a912da4a_fk_discount_sale_id" FOREIGN KEY ("sale_id") REFERENCES "mirumee"."discount_sale"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_products discount_sale_produc_product_id_d42c9636_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_products"
    ADD CONSTRAINT "discount_sale_produc_product_id_d42c9636_fk_product_p" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_sale_products discount_sale_products_sale_id_10e3a20f_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_sale_products"
    ADD CONSTRAINT "discount_sale_products_sale_id_10e3a20f_fk_discount_sale_id" FOREIGN KEY ("sale_id") REFERENCES "mirumee"."discount_sale"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_saletranslation discount_saletranslation_sale_id_36a69b0a_fk_discount_sale_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_saletranslation"
    ADD CONSTRAINT "discount_saletranslation_sale_id_36a69b0a_fk_discount_sale_id" FOREIGN KEY ("sale_id") REFERENCES "mirumee"."discount_sale"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_categories discount_voucher_cat_category_id_fc9d044a_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_categories"
    ADD CONSTRAINT "discount_voucher_cat_category_id_fc9d044a_fk_product_c" FOREIGN KEY ("category_id") REFERENCES "mirumee"."product_category"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_categories discount_voucher_cat_voucher_id_19a56338_fk_discount_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_categories"
    ADD CONSTRAINT "discount_voucher_cat_voucher_id_19a56338_fk_discount_" FOREIGN KEY ("voucher_id") REFERENCES "mirumee"."discount_voucher"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_collections discount_voucher_col_collection_id_b9de6b54_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_collections"
    ADD CONSTRAINT "discount_voucher_col_collection_id_b9de6b54_fk_product_c" FOREIGN KEY ("collection_id") REFERENCES "mirumee"."product_collection"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_collections discount_voucher_col_voucher_id_4ce1fde3_fk_discount_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_collections"
    ADD CONSTRAINT "discount_voucher_col_voucher_id_4ce1fde3_fk_discount_" FOREIGN KEY ("voucher_id") REFERENCES "mirumee"."discount_voucher"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_products discount_voucher_pro_product_id_4a3131ff_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_products"
    ADD CONSTRAINT "discount_voucher_pro_product_id_4a3131ff_fk_product_p" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_voucher_products discount_voucher_pro_voucher_id_8a2e6c3a_fk_discount_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_voucher_products"
    ADD CONSTRAINT "discount_voucher_pro_voucher_id_8a2e6c3a_fk_discount_" FOREIGN KEY ("voucher_id") REFERENCES "mirumee"."discount_voucher"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_vouchercustomer discount_vouchercust_voucher_id_bb55c04f_fk_discount_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchercustomer"
    ADD CONSTRAINT "discount_vouchercust_voucher_id_bb55c04f_fk_discount_" FOREIGN KEY ("voucher_id") REFERENCES "mirumee"."discount_voucher"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discount_vouchertranslation discount_vouchertran_voucher_id_288246a9_fk_discount_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."discount_vouchertranslation"
    ADD CONSTRAINT "discount_vouchertran_voucher_id_288246a9_fk_discount_" FOREIGN KEY ("voucher_id") REFERENCES "mirumee"."discount_voucher"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: giftcard_giftcard giftcard_giftcard_user_id_ce2401b5_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."giftcard_giftcard"
    ADD CONSTRAINT "giftcard_giftcard_user_id_ce2401b5_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invoice_invoice invoice_invoice_order_id_c5fc9ae9_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoice"
    ADD CONSTRAINT "invoice_invoice_order_id_c5fc9ae9_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invoice_invoiceevent invoice_invoiceevent_invoice_id_de0632ca_fk_invoice_invoice_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoiceevent"
    ADD CONSTRAINT "invoice_invoiceevent_invoice_id_de0632ca_fk_invoice_invoice_id" FOREIGN KEY ("invoice_id") REFERENCES "mirumee"."invoice_invoice"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invoice_invoiceevent invoice_invoiceevent_order_id_5a337f7a_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoiceevent"
    ADD CONSTRAINT "invoice_invoiceevent_order_id_5a337f7a_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invoice_invoiceevent invoice_invoiceevent_user_id_cd599b8d_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."invoice_invoiceevent"
    ADD CONSTRAINT "invoice_invoiceevent_user_id_cd599b8d_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_category_id_af353a3b_fk_product_category_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitem"
    ADD CONSTRAINT "menu_menuitem_category_id_af353a3b_fk_product_category_id" FOREIGN KEY ("category_id") REFERENCES "mirumee"."product_category"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_collection_id_b913b19e_fk_product_collection_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitem"
    ADD CONSTRAINT "menu_menuitem_collection_id_b913b19e_fk_product_collection_id" FOREIGN KEY ("collection_id") REFERENCES "mirumee"."product_collection"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_menu_id_f466b139_fk_menu_menu_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitem"
    ADD CONSTRAINT "menu_menuitem_menu_id_f466b139_fk_menu_menu_id" FOREIGN KEY ("menu_id") REFERENCES "mirumee"."menu_menu"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_page_id_a0c8f92d_fk_page_page_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitem"
    ADD CONSTRAINT "menu_menuitem_page_id_a0c8f92d_fk_page_page_id" FOREIGN KEY ("page_id") REFERENCES "mirumee"."page_page"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitem menu_menuitem_parent_id_439f55a5_fk_menu_menuitem_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitem"
    ADD CONSTRAINT "menu_menuitem_parent_id_439f55a5_fk_menu_menuitem_id" FOREIGN KEY ("parent_id") REFERENCES "mirumee"."menu_menuitem"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: menu_menuitemtranslation menu_menuitemtransla_menu_item_id_3445926c_fk_menu_menu; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."menu_menuitemtranslation"
    ADD CONSTRAINT "menu_menuitemtransla_menu_item_id_3445926c_fk_menu_menu" FOREIGN KEY ("menu_item_id") REFERENCES "mirumee"."menu_menuitem"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_fulfillment order_fulfillment_order_id_02695111_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillment"
    ADD CONSTRAINT "order_fulfillment_order_id_02695111_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_fulfillmentline order_fulfillmentlin_fulfillment_id_68f3291d_fk_order_ful; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillmentline"
    ADD CONSTRAINT "order_fulfillmentlin_fulfillment_id_68f3291d_fk_order_ful" FOREIGN KEY ("fulfillment_id") REFERENCES "mirumee"."order_fulfillment"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_fulfillmentline order_fulfillmentlin_order_line_id_7d40e054_fk_order_ord; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillmentline"
    ADD CONSTRAINT "order_fulfillmentlin_order_line_id_7d40e054_fk_order_ord" FOREIGN KEY ("order_line_id") REFERENCES "mirumee"."order_orderline"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_fulfillmentline order_fulfillmentline_stock_id_da5a99fe_fk_warehouse_stock_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_fulfillmentline"
    ADD CONSTRAINT "order_fulfillmentline_stock_id_da5a99fe_fk_warehouse_stock_id" FOREIGN KEY ("stock_id") REFERENCES "mirumee"."warehouse_stock"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_billing_address_id_8fe537cf_fk_userprofi; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order"
    ADD CONSTRAINT "order_order_billing_address_id_8fe537cf_fk_userprofi" FOREIGN KEY ("billing_address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order_gift_cards order_order_gift_car_giftcard_id_f6844926_fk_giftcard_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order_gift_cards"
    ADD CONSTRAINT "order_order_gift_car_giftcard_id_f6844926_fk_giftcard_" FOREIGN KEY ("giftcard_id") REFERENCES "mirumee"."giftcard_giftcard"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order_gift_cards order_order_gift_cards_order_id_ce5608c4_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order_gift_cards"
    ADD CONSTRAINT "order_order_gift_cards_order_id_ce5608c4_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_shipping_address_id_57e64931_fk_userprofi; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order"
    ADD CONSTRAINT "order_order_shipping_address_id_57e64931_fk_userprofi" FOREIGN KEY ("shipping_address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_shipping_method_id_2a742834_fk_shipping_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order"
    ADD CONSTRAINT "order_order_shipping_method_id_2a742834_fk_shipping_" FOREIGN KEY ("shipping_method_id") REFERENCES "mirumee"."shipping_shippingmethod"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_user_id_7cf9bc2b_fk_userprofile_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order"
    ADD CONSTRAINT "order_order_user_id_7cf9bc2b_fk_userprofile_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_order order_order_voucher_id_0748ca22_fk_discount_voucher_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_order"
    ADD CONSTRAINT "order_order_voucher_id_0748ca22_fk_discount_voucher_id" FOREIGN KEY ("voucher_id") REFERENCES "mirumee"."discount_voucher"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderevent order_orderevent_order_id_09aa7ccd_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderevent"
    ADD CONSTRAINT "order_orderevent_order_id_09aa7ccd_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderevent order_orderevent_user_id_1056ac9c_fk_userprofile_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderevent"
    ADD CONSTRAINT "order_orderevent_user_id_1056ac9c_fk_userprofile_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderline order_orderline_order_id_eb04ec2d_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderline"
    ADD CONSTRAINT "order_orderline_order_id_eb04ec2d_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order_orderline order_orderline_variant_id_866774cb_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."order_orderline"
    ADD CONSTRAINT "order_orderline_variant_id_866774cb_fk_product_p" FOREIGN KEY ("variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_pagetranslation page_pagetranslation_page_id_60216ef5_fk_page_page_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."page_pagetranslation"
    ADD CONSTRAINT "page_pagetranslation_page_id_60216ef5_fk_page_page_id" FOREIGN KEY ("page_id") REFERENCES "mirumee"."page_page"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: payment_payment payment_payment_checkout_id_1f32e1ab_fk_checkout_checkout_token; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."payment_payment"
    ADD CONSTRAINT "payment_payment_checkout_id_1f32e1ab_fk_checkout_checkout_token" FOREIGN KEY ("checkout_id") REFERENCES "mirumee"."checkout_checkout"("token") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: payment_payment payment_payment_order_id_22b45881_fk_order_order_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."payment_payment"
    ADD CONSTRAINT "payment_payment_order_id_22b45881_fk_order_order_id" FOREIGN KEY ("order_id") REFERENCES "mirumee"."order_order"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: payment_transaction payment_transaction_payment_id_df9808d7_fk_payment_payment_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."payment_transaction"
    ADD CONSTRAINT "payment_transaction_payment_id_df9808d7_fk_payment_payment_id" FOREIGN KEY ("payment_id") REFERENCES "mirumee"."payment_payment"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedproductattribute_values product_assignedprod_assignedproductattri_6d497dfa_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute_values"
    ADD CONSTRAINT "product_assignedprod_assignedproductattri_6d497dfa_fk_product_a" FOREIGN KEY ("assignedproductattribute_id") REFERENCES "mirumee"."product_assignedproductattribute"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedproductattribute product_assignedprod_assignment_id_eb2f81a4_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute"
    ADD CONSTRAINT "product_assignedprod_assignment_id_eb2f81a4_fk_product_a" FOREIGN KEY ("assignment_id") REFERENCES "mirumee"."product_attributeproduct"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedproductattribute_values product_assignedprod_attributevalue_id_5bd29b24_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute_values"
    ADD CONSTRAINT "product_assignedprod_attributevalue_id_5bd29b24_fk_product_a" FOREIGN KEY ("attributevalue_id") REFERENCES "mirumee"."product_attributevalue"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedproductattribute product_assignedprod_product_id_68be10a3_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedproductattribute"
    ADD CONSTRAINT "product_assignedprod_product_id_68be10a3_fk_product_p" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedvariantattribute_values product_assignedvari_assignedvariantattri_8d6d62ef_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute_values"
    ADD CONSTRAINT "product_assignedvari_assignedvariantattri_8d6d62ef_fk_product_a" FOREIGN KEY ("assignedvariantattribute_id") REFERENCES "mirumee"."product_assignedvariantattribute"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedvariantattribute product_assignedvari_assignment_id_8fdbffe8_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute"
    ADD CONSTRAINT "product_assignedvari_assignment_id_8fdbffe8_fk_product_a" FOREIGN KEY ("assignment_id") REFERENCES "mirumee"."product_attributevariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedvariantattribute_values product_assignedvari_attributevalue_id_41cc2454_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute_values"
    ADD CONSTRAINT "product_assignedvari_attributevalue_id_41cc2454_fk_product_a" FOREIGN KEY ("attributevalue_id") REFERENCES "mirumee"."product_attributevalue"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_assignedvariantattribute product_assignedvari_variant_id_27483e6a_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_assignedvariantattribute"
    ADD CONSTRAINT "product_assignedvari_variant_id_27483e6a_fk_product_p" FOREIGN KEY ("variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributevalue product_attributecho_attribute_id_c28c6c92_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevalue"
    ADD CONSTRAINT "product_attributecho_attribute_id_c28c6c92_fk_product_a" FOREIGN KEY ("attribute_id") REFERENCES "mirumee"."product_attribute"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributeproduct product_attributepro_attribute_id_0051c706_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributeproduct"
    ADD CONSTRAINT "product_attributepro_attribute_id_0051c706_fk_product_a" FOREIGN KEY ("attribute_id") REFERENCES "mirumee"."product_attribute"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributeproduct product_attributepro_product_type_id_54357b3b_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributeproduct"
    ADD CONSTRAINT "product_attributepro_product_type_id_54357b3b_fk_product_p" FOREIGN KEY ("product_type_id") REFERENCES "mirumee"."product_producttype"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributetranslation product_attributetra_attribute_id_238dabfc_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributetranslation"
    ADD CONSTRAINT "product_attributetra_attribute_id_238dabfc_fk_product_a" FOREIGN KEY ("attribute_id") REFERENCES "mirumee"."product_attribute"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributevaluetranslation product_attributeval_attribute_value_id_8b2cb275_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevaluetranslation"
    ADD CONSTRAINT "product_attributeval_attribute_value_id_8b2cb275_fk_product_a" FOREIGN KEY ("attribute_value_id") REFERENCES "mirumee"."product_attributevalue"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributevariant product_attributevar_attribute_id_e47d3bc3_fk_product_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevariant"
    ADD CONSTRAINT "product_attributevar_attribute_id_e47d3bc3_fk_product_a" FOREIGN KEY ("attribute_id") REFERENCES "mirumee"."product_attribute"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_attributevariant product_attributevar_product_type_id_ba95c6dd_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_attributevariant"
    ADD CONSTRAINT "product_attributevar_product_type_id_ba95c6dd_fk_product_p" FOREIGN KEY ("product_type_id") REFERENCES "mirumee"."product_producttype"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_category product_category_parent_id_f6860923_fk_product_category_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_category"
    ADD CONSTRAINT "product_category_parent_id_f6860923_fk_product_category_id" FOREIGN KEY ("parent_id") REFERENCES "mirumee"."product_category"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_categorytranslation product_categorytran_category_id_aa8d0917_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_categorytranslation"
    ADD CONSTRAINT "product_categorytran_category_id_aa8d0917_fk_product_c" FOREIGN KEY ("category_id") REFERENCES "mirumee"."product_category"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_collectionproduct product_collection_p_collection_id_0bc817dc_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectionproduct"
    ADD CONSTRAINT "product_collection_p_collection_id_0bc817dc_fk_product_c" FOREIGN KEY ("collection_id") REFERENCES "mirumee"."product_collection"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_collectionproduct product_collection_p_product_id_a45a5b06_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectionproduct"
    ADD CONSTRAINT "product_collection_p_product_id_a45a5b06_fk_product_p" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_collectiontranslation product_collectiontr_collection_id_cfbbd453_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_collectiontranslation"
    ADD CONSTRAINT "product_collectiontr_collection_id_cfbbd453_fk_product_c" FOREIGN KEY ("collection_id") REFERENCES "mirumee"."product_collection"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_digitalcontenturl product_digitalconte_content_id_654197bd_fk_product_d; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontenturl"
    ADD CONSTRAINT "product_digitalconte_content_id_654197bd_fk_product_d" FOREIGN KEY ("content_id") REFERENCES "mirumee"."product_digitalcontent"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_digitalcontenturl product_digitalconte_line_id_82056694_fk_order_ord; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontenturl"
    ADD CONSTRAINT "product_digitalconte_line_id_82056694_fk_order_ord" FOREIGN KEY ("line_id") REFERENCES "mirumee"."order_orderline"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_digitalcontent product_digitalconte_product_variant_id_211462a5_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_digitalcontent"
    ADD CONSTRAINT "product_digitalconte_product_variant_id_211462a5_fk_product_p" FOREIGN KEY ("product_variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_product product_product_category_id_0c725779_fk_product_category_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_product"
    ADD CONSTRAINT "product_product_category_id_0c725779_fk_product_category_id" FOREIGN KEY ("category_id") REFERENCES "mirumee"."product_category"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_product product_product_default_variant_id_bce7dabb_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_product"
    ADD CONSTRAINT "product_product_default_variant_id_bce7dabb_fk_product_p" FOREIGN KEY ("default_variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_product product_product_product_type_id_4bfbbfda_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_product"
    ADD CONSTRAINT "product_product_product_type_id_4bfbbfda_fk_product_p" FOREIGN KEY ("product_type_id") REFERENCES "mirumee"."product_producttype"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_productimage product_productimage_product_id_544084bb_fk_product_product_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productimage"
    ADD CONSTRAINT "product_productimage_product_id_544084bb_fk_product_product_id" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_producttranslation product_producttrans_product_id_2c2c7532_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_producttranslation"
    ADD CONSTRAINT "product_producttrans_product_id_2c2c7532_fk_product_p" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_productvariant product_productvaria_product_id_43c5a310_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvariant"
    ADD CONSTRAINT "product_productvaria_product_id_43c5a310_fk_product_p" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_productvarianttranslation product_productvaria_product_variant_id_1b144a85_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_productvarianttranslation"
    ADD CONSTRAINT "product_productvaria_product_variant_id_1b144a85_fk_product_p" FOREIGN KEY ("product_variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_variantimage product_variantimage_image_id_bef14106_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_variantimage"
    ADD CONSTRAINT "product_variantimage_image_id_bef14106_fk_product_p" FOREIGN KEY ("image_id") REFERENCES "mirumee"."product_productimage"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_variantimage product_variantimage_variant_id_81123814_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."product_variantimage"
    ADD CONSTRAINT "product_variantimage_variant_id_81123814_fk_product_p" FOREIGN KEY ("variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_shippingmethodtranslation shipping_shippingmet_shipping_method_id_31d925d2_fk_shipping_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingmethodtranslation"
    ADD CONSTRAINT "shipping_shippingmet_shipping_method_id_31d925d2_fk_shipping_" FOREIGN KEY ("shipping_method_id") REFERENCES "mirumee"."shipping_shippingmethod"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shipping_shippingmethod shipping_shippingmet_shipping_zone_id_265b7413_fk_shipping_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."shipping_shippingmethod"
    ADD CONSTRAINT "shipping_shippingmet_shipping_zone_id_265b7413_fk_shipping_" FOREIGN KEY ("shipping_zone_id") REFERENCES "mirumee"."shipping_shippingzone"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_authorizationkey site_authorizationke_site_settings_id_d8397c0f_fk_site_site; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_authorizationkey"
    ADD CONSTRAINT "site_authorizationke_site_settings_id_d8397c0f_fk_site_site" FOREIGN KEY ("site_settings_id") REFERENCES "mirumee"."site_sitesettings"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_bottom_menu_id_e2a78098_fk_menu_menu_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings"
    ADD CONSTRAINT "site_sitesettings_bottom_menu_id_e2a78098_fk_menu_menu_id" FOREIGN KEY ("bottom_menu_id") REFERENCES "mirumee"."menu_menu"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_company_address_id_f0825427_fk_account_a; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings"
    ADD CONSTRAINT "site_sitesettings_company_address_id_f0825427_fk_account_a" FOREIGN KEY ("company_address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_homepage_collection__82f45d33_fk_product_c; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings"
    ADD CONSTRAINT "site_sitesettings_homepage_collection__82f45d33_fk_product_c" FOREIGN KEY ("homepage_collection_id") REFERENCES "mirumee"."product_collection"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_site_id_64dd8ff8_fk_django_site_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings"
    ADD CONSTRAINT "site_sitesettings_site_id_64dd8ff8_fk_django_site_id" FOREIGN KEY ("site_id") REFERENCES "mirumee"."django_site"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettings site_sitesettings_top_menu_id_ab6f8c46_fk_menu_menu_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettings"
    ADD CONSTRAINT "site_sitesettings_top_menu_id_ab6f8c46_fk_menu_menu_id" FOREIGN KEY ("top_menu_id") REFERENCES "mirumee"."menu_menu"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_sitesettingstranslation site_sitesettingstra_site_settings_id_ca085ff6_fk_site_site; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."site_sitesettingstranslation"
    ADD CONSTRAINT "site_sitesettingstra_site_settings_id_ca085ff6_fk_site_site" FOREIGN KEY ("site_settings_id") REFERENCES "mirumee"."site_sitesettings"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user userprofile_user_default_billing_addr_0489abf1_fk_userprofi; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user"
    ADD CONSTRAINT "userprofile_user_default_billing_addr_0489abf1_fk_userprofi" FOREIGN KEY ("default_billing_address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user userprofile_user_default_shipping_add_aae7a203_fk_userprofi; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user"
    ADD CONSTRAINT "userprofile_user_default_shipping_add_aae7a203_fk_userprofi" FOREIGN KEY ("default_shipping_address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_groups userprofile_user_groups_group_id_c7eec74e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_groups"
    ADD CONSTRAINT "userprofile_user_groups_group_id_c7eec74e_fk_auth_group_id" FOREIGN KEY ("group_id") REFERENCES "mirumee"."auth_group"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_groups userprofile_user_groups_user_id_5e712a24_fk_userprofile_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_groups"
    ADD CONSTRAINT "userprofile_user_groups_user_id_5e712a24_fk_userprofile_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_user_permissions userprofile_user_use_permission_id_1caa8a71_fk_auth_perm; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_user_permissions"
    ADD CONSTRAINT "userprofile_user_use_permission_id_1caa8a71_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "mirumee"."auth_permission"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_user_user_permissions userprofile_user_use_user_id_6d654469_fk_userprofi; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."account_user_user_permissions"
    ADD CONSTRAINT "userprofile_user_use_user_id_6d654469_fk_userprofi" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: warehouse_allocation warehouse_allocation_order_line_id_693dcb84_fk_order_ord; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_allocation"
    ADD CONSTRAINT "warehouse_allocation_order_line_id_693dcb84_fk_order_ord" FOREIGN KEY ("order_line_id") REFERENCES "mirumee"."order_orderline"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: warehouse_allocation warehouse_allocation_stock_id_73541542_fk_warehouse_stock_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_allocation"
    ADD CONSTRAINT "warehouse_allocation_stock_id_73541542_fk_warehouse_stock_id" FOREIGN KEY ("stock_id") REFERENCES "mirumee"."warehouse_stock"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: warehouse_stock warehouse_stock_product_variant_id_bea58a82_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_stock"
    ADD CONSTRAINT "warehouse_stock_product_variant_id_bea58a82_fk_product_p" FOREIGN KEY ("product_variant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: warehouse_stock warehouse_stock_warehouse_id_cc9d4e5d_fk_warehouse_warehouse_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_stock"
    ADD CONSTRAINT "warehouse_stock_warehouse_id_cc9d4e5d_fk_warehouse_warehouse_id" FOREIGN KEY ("warehouse_id") REFERENCES "mirumee"."warehouse_warehouse"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: warehouse_warehouse_shipping_zones warehouse_warehouse__shippingzone_id_aeee255b_fk_shipping_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse_shipping_zones"
    ADD CONSTRAINT "warehouse_warehouse__shippingzone_id_aeee255b_fk_shipping_" FOREIGN KEY ("shippingzone_id") REFERENCES "mirumee"."shipping_shippingzone"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: warehouse_warehouse_shipping_zones warehouse_warehouse__warehouse_id_fccd6647_fk_warehouse; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse_shipping_zones"
    ADD CONSTRAINT "warehouse_warehouse__warehouse_id_fccd6647_fk_warehouse" FOREIGN KEY ("warehouse_id") REFERENCES "mirumee"."warehouse_warehouse"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: warehouse_warehouse warehouse_warehouse_address_id_d46e1096_fk_account_address_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."warehouse_warehouse"
    ADD CONSTRAINT "warehouse_warehouse_address_id_d46e1096_fk_account_address_id" FOREIGN KEY ("address_id") REFERENCES "mirumee"."account_address"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: webhook_webhook webhook_webhook_app_id_604d7610_fk_app_app_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."webhook_webhook"
    ADD CONSTRAINT "webhook_webhook_app_id_604d7610_fk_app_app_id" FOREIGN KEY ("app_id") REFERENCES "mirumee"."app_app"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: webhook_webhookevent webhook_webhookevent_webhook_id_73b5c9e1_fk_webhook_webhook_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."webhook_webhookevent"
    ADD CONSTRAINT "webhook_webhookevent_webhook_id_73b5c9e1_fk_webhook_webhook_id" FOREIGN KEY ("webhook_id") REFERENCES "mirumee"."webhook_webhook"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wishlist_wishlist wishlist_wishlist_user_id_13f28b16_fk_account_user_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlist"
    ADD CONSTRAINT "wishlist_wishlist_user_id_13f28b16_fk_account_user_id" FOREIGN KEY ("user_id") REFERENCES "mirumee"."account_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wishlist_wishlistitem_variants wishlist_wishlistite_productvariant_id_819ee66b_fk_product_p; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem_variants"
    ADD CONSTRAINT "wishlist_wishlistite_productvariant_id_819ee66b_fk_product_p" FOREIGN KEY ("productvariant_id") REFERENCES "mirumee"."product_productvariant"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wishlist_wishlistitem wishlist_wishlistite_wishlist_id_a052b63d_fk_wishlist_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem"
    ADD CONSTRAINT "wishlist_wishlistite_wishlist_id_a052b63d_fk_wishlist_" FOREIGN KEY ("wishlist_id") REFERENCES "mirumee"."wishlist_wishlist"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wishlist_wishlistitem_variants wishlist_wishlistite_wishlistitem_id_ee616761_fk_wishlist_; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem_variants"
    ADD CONSTRAINT "wishlist_wishlistite_wishlistitem_id_ee616761_fk_wishlist_" FOREIGN KEY ("wishlistitem_id") REFERENCES "mirumee"."wishlist_wishlistitem"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wishlist_wishlistitem wishlist_wishlistitem_product_id_8309716a_fk_product_product_id; Type: FK CONSTRAINT; Schema: mirumee; Owner: saleor
--

ALTER TABLE ONLY "mirumee"."wishlist_wishlistitem"
    ADD CONSTRAINT "wishlist_wishlistitem_product_id_8309716a_fk_product_product_id" FOREIGN KEY ("product_id") REFERENCES "mirumee"."product_product"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

